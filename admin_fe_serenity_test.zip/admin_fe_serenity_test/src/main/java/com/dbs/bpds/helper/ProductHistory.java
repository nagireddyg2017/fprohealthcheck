package com.dbs.bpds.helper;

import java.util.Comparator;

public class ProductHistory implements Comparable<ProductHistory>  {
    private String recordStatus;
    private String maintenanceStatus;
    private String productName;
    private String ProductCode;
    private String insurerComponentCode;
    private String insurerName;
    private String insurerCode;
    private String PlanType;
    private String choiceofCover;
    private String coveragePeriodTravel;
    private String templateName;
    private String segmentMM;
    private String segmentTR;
    private String segmentTPC;
    private String segmentPB;
    private String policyCategory;
    private String coverageType;
    private String productCategory;
    private String remark;
    private String lastUpdatedBy;
    private String lastUpdatedDateTime;
    private String lastApprovedBy;
    private String lastApprovedDateTime;



    @Override
    public boolean equals(Object o) {

        if (o == this){
            return  true;
        }

        if (!(o instanceof  ProductHistory)) {
            return false;
        }
        ProductHistory obj = (ProductHistory) o;
        return this.recordStatus.equals(obj.recordStatus) &&
                this.maintenanceStatus.equals(obj.maintenanceStatus) &&
                this.productName.equals(obj.productName) &&
                this.ProductCode.equals(obj.ProductCode) &&
                this.insurerComponentCode.equals(obj.insurerComponentCode) &&
                this.insurerName.equals(obj.insurerName) &&
                this.insurerCode.equals(obj.insurerCode) &&
                this.PlanType.equals(obj.PlanType) &&
                this.choiceofCover.equals(obj.choiceofCover) &&
                this.coveragePeriodTravel.equals(obj.coveragePeriodTravel) &&
                this.templateName.equals(obj.templateName) &&
                this.segmentMM.equals(obj.segmentMM) &&
                this.segmentTR.equals(obj.segmentTR) &&
                this.segmentTPC.equals(obj.segmentTPC) &&
                this.segmentPB.equals(obj.segmentPB) &&
                this.policyCategory.equals(obj.policyCategory) &&
                this.coverageType.equals(obj.coverageType) &&
                this.productCategory.equals(obj.productCategory) &&
                this.remark.equals(obj.remark) &&
                this.lastUpdatedBy.equals(obj.lastUpdatedBy) &&
                this.lastUpdatedDateTime.equals(obj.lastUpdatedDateTime) &&
                this.lastApprovedBy.equals(obj.lastApprovedBy) &&
                this.lastApprovedDateTime.equals(obj.lastApprovedDateTime);
    }

    public String getRecordStatus() {
        return recordStatus;
    }

    public String getMaintenanceStatus() {
        return maintenanceStatus;
    }

    public void setMaintenanceStatus(String maintenanceStatus) {
        this.maintenanceStatus = maintenanceStatus;
    }

    public void setRecordStatus(String recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductCode() {
        return ProductCode;
    }

    public void setProductCode(String productCode) {
        ProductCode = productCode;
    }

    public String getInsurerComponentCode() {
        return insurerComponentCode;
    }

    public void setInsurerComponentCode(String insurerComponentCode) {
        this.insurerComponentCode = insurerComponentCode;
    }

    public String getInsurerName() {
        return insurerName;
    }

    public void setInsurerName(String insurerName) {
        this.insurerName = insurerName;
    }

    public String getInsurerCode() {
        return insurerCode;
    }

    public void setInsurerCode(String insurerCode) {
        this.insurerCode = insurerCode;
    }

    public String getPlanType() {
        return PlanType;
    }

    public void setPlanType(String planType) {
        PlanType = planType;
    }

    public String getChoiceofCover() {
        return choiceofCover;
    }

    public void setChoiceofCover(String choiceofCover) {
        this.choiceofCover = choiceofCover;
    }

    public String getCoveragePeriodTravel() {
        return coveragePeriodTravel;
    }

    public void setCoveragePeriodTravel(String coveragePeriodTravel) {
        this.coveragePeriodTravel = coveragePeriodTravel;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getSegmentMM() {
        return segmentMM;
    }

    public void setSegmentMM(String segmentMM) {
        this.segmentMM = segmentMM;
    }

    public String getSegmentTR() {
        return segmentTR;
    }

    public void setSegmentTR(String segmentTR) {
        this.segmentTR = segmentTR;
    }

    public String getSegmentTPC() {
        return segmentTPC;
    }

    public void setSegmentTPC(String segmentTPC) {
        this.segmentTPC = segmentTPC;
    }

    public String getSegmentPB() {
        return segmentPB;
    }

    public void setSegmentPB(String segmentPB) {
        this.segmentPB = segmentPB;
    }

    public String getPolicyCategory() {
        return policyCategory;
    }

    public void setPolicyCategory(String policyCategory) {
        this.policyCategory = policyCategory;
    }

    public String getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }

    public String getLastUpdatedDateTime() {
        return lastUpdatedDateTime;
    }

    public void setLastUpdatedDateTime(String lastUpdatedDateTime) {
        this.lastUpdatedDateTime = lastUpdatedDateTime;
    }

    public String getLastApprovedBy() {
        return lastApprovedBy;
    }

    public void setLastApprovedBy(String lastApprovedBy) {
        this.lastApprovedBy = lastApprovedBy;
    }

    public String getLastApprovedDateTime() {
        return lastApprovedDateTime;
    }

    public void setLastApprovedDateTime(String lastApprovedDateTime) {
        this.lastApprovedDateTime = lastApprovedDateTime;
    }

    public String toString(){
        return this.getRecordStatus()+this.getMaintenanceStatus()+this.getProductName()+
                this.getProductCode()+this.getInsurerComponentCode()+this.getInsurerName()+
                this.getInsurerCode()+this.getPlanType()+this.getChoiceofCover()+
                this.getCoveragePeriodTravel()+this.getTemplateName()+this.getSegmentMM()+
                this.getSegmentTR()+this.getSegmentTPC()+this.getSegmentPB()+
                this.getPolicyCategory()+this.getCoverageType()+this.getProductCategory()+
                this.getRemark()+this.getLastUpdatedBy()+this.getLastUpdatedDateTime()+
                this.getLastApprovedBy()+this.getLastApprovedDateTime();
    }


    @Override
    public int compareTo(ProductHistory o) {
        if(this.recordStatus != o.recordStatus) return 1;
        if(this.maintenanceStatus != o.maintenanceStatus) return 1;
        if(this.productName != o.productName) return 1;
        if(this.ProductCode != o.ProductCode) return 1;
        if(this.insurerComponentCode != o.insurerComponentCode) return 1;
        if(this.insurerName != o.insurerName) return 1;
        if(this.insurerCode != o.insurerCode) return 1;
        if(this.PlanType != o.PlanType) return 1;
        if(this.choiceofCover != o.choiceofCover) return 1;
        if(this.coveragePeriodTravel != o.coveragePeriodTravel) return 1;
        if(this.templateName != o.templateName) return 1;
        if(this.segmentMM != o.segmentMM) return 1;
        if(this.segmentTR != o.segmentTR) return 1;
        if(this.segmentTPC != o.segmentTPC) return 1;
        if(this.segmentPB != o.segmentPB) return 1;
        if(this.policyCategory != o.policyCategory) return 1;
        if(this.coverageType != o.coverageType) return 1;
        if(this.productCategory != o.productCategory) return 1;
        if(this.remark != o.remark) return 1;
        if(this.lastUpdatedBy != o.lastUpdatedBy) return 1;
        if(this.lastUpdatedDateTime != o.lastUpdatedDateTime) return 1;
        if(this.lastApprovedBy != o.lastApprovedBy) return 1;
        if(this.lastApprovedDateTime != o.lastApprovedDateTime) return 1;
        else                                                    return 0;
    }

    public static class CustomComparator implements Comparator<ProductHistory> {

        @Override
        public int compare(ProductHistory o1, ProductHistory o2) {
            if (o1.getRecordStatus().compareTo(o2.getRecordStatus()) !=0)
                return o1.getRecordStatus().compareTo(o2.getRecordStatus());
            if (o1.getMaintenanceStatus().compareTo(o2.getMaintenanceStatus())!=0)
                return o1.getMaintenanceStatus().compareTo(o2.getMaintenanceStatus());

            if(o1.getProductName().compareTo(o2.getProductName())!=0)
                return o1.getProductName().compareTo(o2.getProductName());

            if(o1.getProductCode().compareTo(o2.getProductCode())!=0)
                return o1.getProductCode().compareTo(o2.getProductCode());

            if(o1.getInsurerComponentCode().compareTo(o2.getInsurerComponentCode())!=0)
                return o1.getInsurerComponentCode().compareTo(o2.getInsurerComponentCode());

            if(o1.getInsurerName().compareTo(o2.getInsurerName())!=0)
                return o1.getInsurerName().compareTo(o2.getInsurerName());

            if(o1.getInsurerCode().compareTo(o2.getInsurerCode())!=0)
                return o1.getInsurerCode().compareTo(o2.getInsurerCode());

            if(o1.getPlanType().compareTo(o2.getPlanType())!=0)
                return o1.getPlanType().compareTo(o2.getPlanType());

            if(o1.getChoiceofCover().compareTo(o2.getChoiceofCover())!=0)
                return o1.getChoiceofCover().compareTo(o2.getChoiceofCover());

            if(o1.getCoveragePeriodTravel().compareTo(o2.getCoveragePeriodTravel())!=0)
                return o1.getCoveragePeriodTravel().compareTo(o2.getCoveragePeriodTravel());

            if(o1.getTemplateName().compareTo(o2.getTemplateName())!=0)
                return o1.getTemplateName().compareTo(o2.getTemplateName());

            if(o1.getSegmentMM().compareTo(o2.getSegmentMM())!=0)
                return o1.getSegmentMM().compareTo(o2.getSegmentMM());

            if(o1.getSegmentTR().compareTo(o2.getSegmentTR())!=0)
                return o1.getSegmentTR().compareTo(o2.getSegmentTR());

            if(o1.getSegmentTPC().compareTo(o2.getSegmentTPC())!=0)
                return o1.getSegmentTPC().compareTo(o2.getSegmentTPC());

            if(o1.getSegmentPB().compareTo(o2.getSegmentPB())!=0)
                return o1.getSegmentPB().compareTo(o2.getSegmentPB());

            if(o1.getPolicyCategory().compareTo(o2.getPolicyCategory())!=0)
                return o1.getPolicyCategory().compareTo(o2.getPolicyCategory());

            if(o1.getCoverageType().compareTo(o2.getCoverageType())!=0)
                return o1.getCoverageType().compareTo(o2.getCoverageType());

            if(o1.getProductCategory().compareTo(o2.getProductCategory())!=0)
                return o1.getProductCategory().compareTo(o2.getProductCategory());

            if(o1.getRemark().compareTo(o2.getRemark())!=0)
                return o1.getRemark().compareTo(o2.getRemark());
            if(o1.getLastUpdatedBy().compareTo(o2.getLastUpdatedBy())!=0)
                return o1.getLastUpdatedBy().compareTo(o2.getLastUpdatedBy());
            if(o1.getLastUpdatedDateTime().compareTo(o2.getLastUpdatedDateTime())!=0)
                return o1.getLastUpdatedDateTime().compareTo(o2.getLastUpdatedDateTime());

            if(o1.getLastApprovedBy().compareTo(o2.getLastApprovedBy())!=0)
                return o1.getLastApprovedBy().compareTo(o2.getLastApprovedBy());

            if(o1.getLastApprovedDateTime().compareTo(o2.getLastApprovedDateTime())!=0)
                return o1.getLastApprovedDateTime().compareTo(o2.getLastApprovedDateTime());

            else return 0;
        }
    }
}
