package com.dbs.bpds.pages;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.helper.AbstractCinExceptionChangeReport;
import com.dbs.bpds.helper.InvalidCINExceptionReportHelper;
import static org.assertj.core.api.Assertions.assertThat;

public class InvalidCinExceptionReportPage {
	
	WebDriver driver;
	private static String invalidCINReportLabeltext;
	private static String filtercriteriaStaticText;
	private static String reportFilter = null;
    private AbstractCinExceptionChangeReport abstractCinExceptionReports = new InvalidCINExceptionReportHelper();
	
	public InvalidCinExceptionReportPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.LINK_TEXT, using = "Cust Holding Reports")
	WebElement customerHoldingReports;
	
	@FindBy(how = How.LINK_TEXT, using = "Invalid CIN Report")
	WebElement InvalidCINReport;
	
	@FindBy(how = How.XPATH, using = "//h4[contains(text(),'Invalid CIN Report')]")
	WebElement labelInvalidCINReport;
	
	@FindBy(how = How.CSS, using = ".text-danger")
	WebElement txtFillCriteria;
	
	@FindBy(how = How.XPATH, using = "//button[@type='submit']")
	WebElement btnExport;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerName'] .cst-i-arrow-s")
	WebElement dropDownInsurerName;
	
	@FindBy(how = How.CSS, using = "cst-list [role] [role='option']:nth-of-type(2)")
	WebElement selectInsurerName;
	
	@FindBy(how = How.XPATH, using = "//div/input[1][@formcontrolname='productName']")
	WebElement enterProductName;
	
	@FindBy(how = How.XPATH, using = "//div/input[1][@formcontrolname='insurerOwnerCin']")
	WebElement enterInsurerOwnerCIN;
	
	@FindBy(how = How.XPATH, using = "//div/input[1][@formcontrolname='insurerOwnerName']")
	WebElement enterInsurerOwnerNme;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='channelId'] .cst-i-arrow-s")
	WebElement clickChannelID;
	
	@FindBy(how = How.XPATH, using = "//cst-root/cst-popup//cst-list[@class='ng-star-inserted']//ul[@role='listbox']/li[2]")
	WebElement selectChannelId;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerRecordDateFrom'] .cst-input")
	WebElement clickInsurerRecordDateFrom;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerRecordDateTo'] .cst-input")
	WebElement clickInsurerRecordDateTo;
	
	@FindBy(how = How.CSS, using = ".cst-toaster-main__title--warn")
	WebElement noRecordFoundwarningMsg;
	
	public void clkReports() {
		customerHoldingReports.click();
	}
	
	public void clkInvalidCINReport() {
		InvalidCINReport.click();
	}
	
	public void verifyInvaliCINReport(){
		invalidCINReportLabeltext = labelInvalidCINReport.getText();
		assertThat(invalidCINReportLabeltext.equalsIgnoreCase("Invalid CIN Report"));
	}
	
	public void verifyStaticFillCriteriaText() {
		filtercriteriaStaticText = txtFillCriteria.getText();
		assertThat(filtercriteriaStaticText.equalsIgnoreCase("Please fill in at least 1 criteria to proceed"));		
	}
	
	public void chkBtnExportIsDiabled() {
		assertThat(!btnExport.isEnabled());
	}
	
	public void slectInsurerName() {
		dropDownInsurerName.click();
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(selectInsurerName));
		selectInsurerName.click();		
	}
	
	public void chkBtnExportIsEnabled() {
		assertThat(btnExport.isEnabled());
	}
	
	public void clickBtnExport() throws InterruptedException {
		btnExport.click();
		Thread.sleep(3000);
	}
	
	public void verifyNoRecordErrorBanner(){
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(noRecordFoundwarningMsg));
		assertThat(noRecordFoundwarningMsg.getText().contains("No Records Found"));
	}
	
	 public void verifyFileisDownloaded(){
         File xFile = new File(Constants.DOWNLOAD_REPORT_PATH, Utils.getInvalidCinExceptionFileNameCurrentdate());
         assertThat(xFile).exists().hasName(Utils.getInvalidCinExceptionFileNameCurrentdate()).hasExtension("xlsx");
         
     }
	 
	 public void enterProductName(String productName){
		 
		 enterProductName.clear();
		 enterProductName.click();
		 enterProductName.sendKeys(productName);
		 
	 }
	 
	 public void enterInsurerOwnerCIN(String insurerOwnerCIN) {
		 enterInsurerOwnerCIN.clear();
		 enterInsurerOwnerCIN.click();
		 enterInsurerOwnerCIN.sendKeys(insurerOwnerCIN);
		 
	 }
	 
	 public void enterInsurerOwnerName(String insurerOwnerName) {
		 enterInsurerOwnerNme.clear();
		 enterInsurerOwnerNme.click();
		 enterInsurerOwnerNme.sendKeys(insurerOwnerName);
		 
	 }
	 
	 public void selectChannelID() throws InterruptedException {
		 clickChannelID.click();
		 Thread.sleep(3000);
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(selectChannelId));
		 selectChannelId.click();		 
	 }
	 
	 public void selectInsurerDateFrom(String insurerRecordReceivedDateFrom) {
		 clickInsurerRecordDateFrom.clear();
		 clickInsurerRecordDateFrom.click();
		 clickInsurerRecordDateFrom.sendKeys(insurerRecordReceivedDateFrom);		 
	 }
	 
	 public void selectInsurerDateTo(String insurerRecordReceivedDateTo) throws IOException {
		 clickInsurerRecordDateTo.clear();
		 clickInsurerRecordDateTo.click();
		 clickInsurerRecordDateTo.sendKeys(insurerRecordReceivedDateTo);
		 Utils.take_screenshot(driver);
		 
	 }
	 
	 public void verifyInvalidCinReportDBTestInsurerName() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerName";
	        abstractCinExceptionReports.invalidCINExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 
	 public void verifyInvalidCinReportDBTestProductName() throws ClassNotFoundException, SQLException {
	        reportFilter = "ProductName";
	        abstractCinExceptionReports.invalidCINExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyInvalidCinReportDBTestInsurerOwnerCIN() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerOwnerCIN";
	        abstractCinExceptionReports.invalidCINExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyInvalidCinReportDBTestInsurerOwnerName() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerOwnerName";
	        abstractCinExceptionReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyInvalidCinReportDBTestChannelID() throws ClassNotFoundException, SQLException {
	        reportFilter = "ChannelID";
	        abstractCinExceptionReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyInvalidCinReportDBTestInsurerRecordDate() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerRecordDate";
	        abstractCinExceptionReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyInvalidCinReportDBTestAllValidInput() throws ClassNotFoundException, SQLException {
	        reportFilter = "AllValidInput";
	        abstractCinExceptionReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }

}

