package com.dbs.bpds.configs;

public class Constants {
	public static final String CURRENT_DIR = System.getProperty("user.dir");
	public static final String DRIVER = "chrome";
	public static final String DEFAULT_URL = "https://bpds.dev.apps.cs.sgp.dbs.com/";
	public static final String USERNAME = "kavitha1";
	public static final String PASSWORD = "Welcome@sep";
	public static final String JIRA_URL = "https://jira2.sgp.dbs.com:8443/dcifjira";
	public static final String JIRA_USER = "kavitha1";
	public static final String JIRA_PASSWORD = "Welcome@sep";
	public static final String JIRA_PROJECT = "BPDS";
	public static final String DOWNLOAD_REPORT_PATH = CURRENT_DIR+"\\reports\\";	
}

