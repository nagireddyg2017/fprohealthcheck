package com.dbs.bpds.steps;

import java.sql.SQLException;

import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.ProductAuditTrailReportPage;

import net.thucydides.core.annotations.Step;

public class ProductAuditTrailReportPage_Steps {
	
	ProductAuditTrailReportPage productAuditTrailReportPage;
	PageObjectFactory pageObjectFactory;
	
	@Step
	public void launchProductAuditTrailReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.clkProductReports();
		productAuditTrailReportPage.clkProductAuditTrailReports();
		productAuditTrailReportPage.verifyProductAuditTrailReport();
	}
	
	@Step
	public void chkFillcriteriaStaticText() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyStaticFillCriteriaText();
	}
	
	@Step
	public void resetProductAuditTrailReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyProductAuditTrailReport();
	}
	
	@Step
	public void chkExportBtnISDisabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.chkBtnExportIsDiabled();
	}
	
	@Step
	public void enterProductAuditTrailReportProductCode(String productCode) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.enterProductCode(productCode);
	}
	
	@Step
	public void chkExportBtnISEnabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.chkBtnExportIsEnabled();
	}
	
	@Step
	public void verifyNoRecordFound(){
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyNoRecordErrorBanner();
	}
	
	@Step
	public void clickExportButtonReports() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.clickBtnExport();		
	}
	
	@Step
	public void verifyDownloadPrdtGroupExceptionReportFilename() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyPrdtAuditTrailFileIsDownloaded();
	}
	
	@Step
	public void enterProductAuditTrailReportInsurerComponentCode(String insurerComponentCode) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.enterInsurerComponentCode(insurerComponentCode);		
	}
	
	
	@Step
	public void selectProductAuditTrailReportInsurerName() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.selectInsurerName();
	}
	
	@Step
	public void enterProductAuditTrailReportProductName(String productName) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.enterProductName(productName);		
	}
	
	@Step
	public void enterProductAuditTrailReportInsurerRecordDate(String insurerRecordReceivedDateFrom, String insurerRecordReceivedDateTo){
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.selectInsurerDateFrom(insurerRecordReceivedDateFrom);
		productAuditTrailReportPage.selectInsurerDateTo(insurerRecordReceivedDateTo);
	}
	
	@Step
	public void validateExcelDBProductAuditTrailReportProductCode() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyPrdtAuditDBTestProductCode();
	}
	
	@Step
	public void validateExcelDBProductAuditTrailReportInsurerComponentCode() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyPrdtAuditDBTestComponentCode();
	}
	
	@Step
	public void validateExcelDBProductAuditTrailReportInsurerName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyPrdtAuditDBTestInsurerName();
	}
	
	@Step
	public void validateExcelDBProductAuditTrailReportProductName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyPrdtAuditDBTestProductName();
	}
	
	@Step
	public void validateExcelDBProductAuditTrailReportInsurerRecordDate() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyPrdtAuditDBTestInsurerRecordDate();
	}
	
	@Step
	public void validateExcelDBProductAuditTrailReportAllValidInput() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productAuditTrailReportPage = pageObjectFactory.getProductAuditTrailReportPage();
		productAuditTrailReportPage.verifyPrdtAuditDBTestAllValidInput();
	}

}

