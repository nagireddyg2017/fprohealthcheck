package com.dbs.bpds.helper;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import com.dbs.bpds.excelutility.ExcelHelperReports;

public class CisProductUpdateReportHelper extends AbstractCustomerProductReport {
	
	private static String reportFileName = "CisPrdtUpdateReport";

	@Override
	public void operationMethodAllValidInputOnFilters() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            	"select case B.MAINTENANCE_INDICATOR\n" +
                                "\t\t\twhen '01' then 'Create'\n" +
                                "\t\t\twhen '02' then 'Update'\n" +
                                "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
                                "B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,\n" +
                                "A.POLICY_OWNER_CIN,A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX,\n" +
                                "case B.PLAN_TYPE\n" +
                                "\twhen '00' then 'Basic'\n" +
                                "\twhen '01' then 'Rider'\n" +
                                "\twhen '02' then 'Subfund'\n" +
                                "\tend as PLAN_TYPE,\n" +
                                "B.PRODUCT_CODE,B.COMPONENT_CODE,B.PRODUCT_NAME,B.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS AS EXCEPTION_REMARKS\n" +
                                "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B\n" +
                                "where A.POLICY_NO = B.POLICY_NO and A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS is not null and B.INSURER_NAME='Manulife' and B.PRODUCT_CODE='ER03' and B.COMPONENT_CODE='EFSRA' and B.PRODUCT_NAME='WAIVER OF PREMIUM (WOP) ON TPD BENEFIT' and B.CHANNEL_ID='ADVSGSTP' and B.RECORD_DATE_TIMESTAMP between  '2018-08-29 00:00:00' and '2018-08-29 23:59:59';"
                );
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodInsurerName() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            				"select case B.MAINTENANCE_INDICATOR\n" +
                            "when '01' then 'Create'\n" +
                            "when '02' then 'Update'\n" +
                            "end as MAINTENANCE_INDICATOR,\n" +
                            "B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,\n" +
                            "A.POLICY_OWNER_CIN,A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX,\n" +
                            "case B.PLAN_TYPE\n" +
                            "when '00' then 'Basic'\n" +
                            "when '01' then 'Rider'\n" +
                            "when '02' then 'Subfund'\n" +
                            "end as PLAN_TYPE,\n" +
                            "B.PRODUCT_CODE,B.COMPONENT_CODE,B.PRODUCT_NAME,B.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS AS EXCEPTION_REMARKS\n" +
                            "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B\n" +
                            "where A.POLICY_NO = B.POLICY_NO and A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS is not null and B.INSURER_NAME='Manulife';"
                );
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodProductCode() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            				"select case B.MAINTENANCE_INDICATOR\n" +
                            "when '01' then 'Create'\n" +
                            "when '02' then 'Update'\n" +
                            "end as MAINTENANCE_INDICATOR,\n" +
                            "B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,\n" +
                            "A.POLICY_OWNER_CIN,A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX,\n" +
                            "case B.PLAN_TYPE\n" +
                            "when '00' then 'Basic'\n" +
                            "when '01' then 'Rider'\n" +
                            "when '02' then 'Subfund'\n" +
                            "end as PLAN_TYPE,\n" +
                            "B.PRODUCT_CODE,B.COMPONENT_CODE,B.PRODUCT_NAME,B.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS AS EXCEPTION_REMARKS\n" +
                            "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B\n" +
                            "where A.POLICY_NO = B.POLICY_NO and A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS is not null and B.PRODUCT_CODE='GUA1';"
                );
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodInsurerComponentCode() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            				"select case B.MAINTENANCE_INDICATOR\n" +
                            "when '01' then 'Create'\n" +
                            "when '02' then 'Update'\n" +
                            "end as MAINTENANCE_INDICATOR,\n" +
                            "B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,\n" +
                            "A.POLICY_OWNER_CIN,A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX,\n" +
                            "case B.PLAN_TYPE\n" +
                            "when '00' then 'Basic'\n" +
                            "when '01' then 'Rider'\n" +
                            "when '02' then 'Subfund'\n" +
                            "end as PLAN_TYPE,\n" +
                            "B.PRODUCT_CODE,B.COMPONENT_CODE,B.PRODUCT_NAME,B.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS AS EXCEPTION_REMARKS\n" +
                            "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B\n" +
                            "where A.POLICY_NO = B.POLICY_NO and A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS is not null and B.COMPONENT_CODE='EFSRA';"
                );
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodProductName() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            				"select case B.MAINTENANCE_INDICATOR\n" +
                            "when '01' then 'Create'\n" +
                            "when '02' then 'Update'\n" +
                            "end as MAINTENANCE_INDICATOR,\n" +
                            "B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,\n" +
                            "A.POLICY_OWNER_CIN,A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX,\n" +
                            "case B.PLAN_TYPE\n" +
                            "when '00' then 'Basic'\n" +
                            "when '01' then 'Rider'\n" +
                            "when '02' then 'Subfund'\n" +
                            "end as PLAN_TYPE,\n" +
                            "B.PRODUCT_CODE,B.COMPONENT_CODE,B.PRODUCT_NAME,B.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS AS EXCEPTION_REMARKS\n" +
                            "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B\n" +
                            "where A.POLICY_NO = B.POLICY_NO and A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS is not null and B.PRODUCT_NAME='WAIVER OF PREMIUM (WOP) ON TPD BENEFIT';"
                );
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodChannelID() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            				"select case B.MAINTENANCE_INDICATOR\n" +
                            "when '01' then 'Create'\n" +
                            "when '02' then 'Update'\n" +
                            "end as MAINTENANCE_INDICATOR,\n" +
                            "B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,\n" +
                            "A.POLICY_OWNER_CIN,A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX,\n" +
                            "case B.PLAN_TYPE\n" +
                            "when '00' then 'Basic'\n" +
                            "when '01' then 'Rider'\n" +
                            "when '02' then 'Subfund'\n" +
                            "end as PLAN_TYPE,\n" +
                            "B.PRODUCT_CODE,B.COMPONENT_CODE,B.PRODUCT_NAME,B.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS AS EXCEPTION_REMARKS\n" +
                            "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B\n" +
                            "where A.POLICY_NO = B.POLICY_NO and A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS is not null and B.CHANNEL_ID='ADVSGSTP';"
                );
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodInsurerRecordDate() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            				"select case B.MAINTENANCE_INDICATOR\n" +
                            "when '01' then 'Create'\n" +
                            "when '02' then 'Update'\n" +
                            "end as MAINTENANCE_INDICATOR,\n" +
                            "B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,\n" +
                            "A.POLICY_OWNER_CIN,A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX,\n" +
                            "case B.PLAN_TYPE\n" +
                            "when '00' then 'Basic'\n" +
                            "when '01' then 'Rider'\n" +
                            "when '02' then 'Subfund'\n" +
                            "end as PLAN_TYPE,\n" +
                            "B.PRODUCT_CODE,B.COMPONENT_CODE,B.PRODUCT_NAME,B.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS AS EXCEPTION_REMARKS\n" +
                            "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B\n" +
                            "where A.POLICY_NO = B.POLICY_NO and A.CIS_PRODUCT_UPDATE_EXCEPTION_REMARKS is not null and B.RECORD_DATE_TIMESTAMP between  '2018-08-29 00:00:00' and '2018-08-29 23:59:59';"
                );
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

}

