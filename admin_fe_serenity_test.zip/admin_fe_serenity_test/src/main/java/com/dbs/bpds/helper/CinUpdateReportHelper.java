package com.dbs.bpds.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.*;

import com.dbs.bpds.excelutility.ExcelHelperReports;

import static org.assertj.core.api.Assertions.*;

public class CinUpdateReportHelper extends AbstractCinExceptionChangeReport{
	
	private static String reportFileName = "cinChangeFileName";

	@Override
	public void OperationMethodInsurerName() {
		
		try {
		// Execute a query
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(
        		"select case B.MAINTENANCE_INDICATOR\n" +
                        "\t\t\twhen '01' then 'Create'\n" +
                        "\t\t\twhen '02' then 'Update'\n" +
                        "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
        		    "B.POLICY_NO,\tB.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN,\n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX, \n" +
                    "A.POLICY_OWNER_DOB,C.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY, \n" +
                    "case B.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "B.PRODUCT_CODE,B.COMPONENT_CODE,\n" +
                    "B.PRODUCT_NAME,A.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIN_CHANGE_UPDATED_DATE_TIME\n" +
                    "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B, bpds.dbs_li_nationality C\n" +
                    "where A.POLICY_NO = B.POLICY_NO and A.POLICY_OWNER_NATIONALITY = C.MLS_COUNTRY_CODE and A.CIN_CHANGE = 'YES' and B.INSURER_CODE = '005';"
        );

        // Get the all row of Excel Table

        HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
        System.out.println("Print Excel Data reports here");
        System.out.println(extractedExcelReportsRow);


        // Count of Matched Row
        int matchRowCount = 0;

        System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

        int columnCount = resultSet.getMetaData().getColumnCount();
        System.out.println("DB column count================>"+columnCount);

        while(resultSet.next()){

            String policyNo = resultSet.getString("POLICY_NO");
            ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

            if(excelRow == null){
                //assertTrue(true, "excel record not found, id = "+policyNo);
                //assertThat(excelRow.isEmpty());
                return;
            }

            int matchColumnCount = 0;
            for(int i=0;i<columnCount;i++){
                System.out.println("UI Cell Data => " + excelRow.get(i));
                String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                System.out.println("DB Cell Data => " + gridValue);
                if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                    matchColumnCount++;
                }
            }

            if (matchColumnCount == excelRow.size()) {
                System.out.println("==============================ROW MATCHED=====================================");
                matchRowCount++;
            }
        }

        //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
        assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());

    }
    catch (Exception e) {
        e.printStackTrace();
    }
		
	}

	@Override
	public void OperationMethodProductName() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"B.POLICY_NO,\tB.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN,\n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX, \n" +
                    "A.POLICY_OWNER_DOB,C.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY, \n" +
                    "case B.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "B.PRODUCT_CODE,B.COMPONENT_CODE,\n" +
                    "B.PRODUCT_NAME,A.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIN_CHANGE_UPDATED_DATE_TIME\n" +
                    "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B, bpds.dbs_li_nationality C\n" +
                    "where A.POLICY_NO = B.POLICY_NO and A.POLICY_OWNER_NATIONALITY = C.MLS_COUNTRY_CODE and A.CIN_CHANGE = 'YES' and B.PRODUCT_NAME = 'WAIVER OF PREMIUM (WOP) ON TPD BENEFIT';"
            );

            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);

            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

            //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());

        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
		
	

	@Override
	public void OperationMethodInsurerOwnerCIN() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"B.POLICY_NO,\tB.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN,\n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX, \n" +
                    "A.POLICY_OWNER_DOB,C.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY, \n" +
                    "case B.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "B.PRODUCT_CODE,B.COMPONENT_CODE,\n" +
                    "B.PRODUCT_NAME,A.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIN_CHANGE_UPDATED_DATE_TIME\n" +
                    "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B, bpds.dbs_li_nationality C\n" +
                    "where A.POLICY_NO = B.POLICY_NO and A.POLICY_OWNER_NATIONALITY = C.MLS_COUNTRY_CODE and A.CIN_CHANGE = 'YES' and A.POLICY_OWNER_CIN = 'P8246239B';"
            );

            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);

            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

            //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());

        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodInsurerOwnerName() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN,\n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX, \n" +
                    "A.POLICY_OWNER_DOB,C.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY, \n" +
                    "case B.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "B.PRODUCT_CODE,B.COMPONENT_CODE,\n" +
                    "B.PRODUCT_NAME,A.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIN_CHANGE_UPDATED_DATE_TIME\n" +
                    "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B, bpds.dbs_li_nationality C\n" +
                    "where A.POLICY_NO = B.POLICY_NO and A.POLICY_OWNER_NATIONALITY = C.MLS_COUNTRY_CODE and A.CIN_CHANGE = 'YES' and A.POLICY_OWNER_NAME = 'Owkqxtxqwoq';"
            );

            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);

            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

            //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());

        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodDBSOwnerCIN() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN,\n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX, \n" +
                    "A.POLICY_OWNER_DOB,C.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY, \n" +
                    "case B.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "B.PRODUCT_CODE,B.COMPONENT_CODE,\n" +
                    "B.PRODUCT_NAME,A.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIN_CHANGE_UPDATED_DATE_TIME\n" +
                    "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B, bpds.dbs_li_nationality C\n" +
                    "where A.POLICY_NO = B.POLICY_NO and A.POLICY_OWNER_NATIONALITY = C.MLS_COUNTRY_CODE and A.CIN_CHANGE = 'YES' and A.DBS_OWNER_CIN = 'S5555566I';"
            );

            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);

            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

            //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());

        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodChannelID() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN,\n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX, \n" +
                    "A.POLICY_OWNER_DOB,C.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY, \n" +
                    "case B.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "B.PRODUCT_CODE,B.COMPONENT_CODE,\n" +
                    "B.PRODUCT_NAME,A.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIN_CHANGE_UPDATED_DATE_TIME\n" +
                    "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B, bpds.dbs_li_nationality C\n" +
                    "where A.POLICY_NO = B.POLICY_NO and A.POLICY_OWNER_NATIONALITY = C.MLS_COUNTRY_CODE and A.CIN_CHANGE = 'YES' and B.CHANNEL_ID ='ADVSGSTP';"
            );

            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);

            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

            //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());

        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodInsurerRecordDate() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"B.POLICY_NO,\tB.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN,\n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX, \n" +
                    "A.POLICY_OWNER_DOB,C.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY, \n" +
                    "case B.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "B.PRODUCT_CODE,B.COMPONENT_CODE,\n" +
                    "B.PRODUCT_NAME,A.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIN_CHANGE_UPDATED_DATE_TIME\n" +
                    "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B, bpds.dbs_li_nationality C\n" +
                    "where A.POLICY_NO = B.POLICY_NO and A.POLICY_OWNER_NATIONALITY = C.MLS_COUNTRY_CODE and A.CIN_CHANGE = 'YES' and B.RECORD_DATE_TIMESTAMP between '2018-09-20 00:00:00' and '2018-09-21 23:59:59';"
            );

            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);

            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

            //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());

        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodAllValidInputOnFilters() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"B.POLICY_NO,B.INSURER_CODE, B.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN,\n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.DBS_OWNER_CIN, A.DBS_OWNER_CIN_SUFFIX, \n" +
                    "A.POLICY_OWNER_DOB,C.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY, \n" +
                    "case B.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "B.PRODUCT_CODE,B.COMPONENT_CODE,\n" +
                    "B.PRODUCT_NAME,A.RECORD_DATE_TIMESTAMP, B.CHANNEL_ID, B.CHANNEL_REFERENCE_NO, A.CIN_CHANGE_UPDATED_DATE_TIME\n" +
                    "from bpds.dbs_li_policy_owner_details A, bpds.dbs_li_customer_holdings B, bpds.dbs_li_nationality C\n" +
                    "where A.POLICY_NO = B.POLICY_NO and A.POLICY_OWNER_NATIONALITY = C.MLS_COUNTRY_CODE and A.CIN_CHANGE = 'YES' and B.INSURER_CODE = '005' and B.PRODUCT_NAME = 'MANULIFE BOOST 5' and A.POLICY_OWNER_CIN = 'S5555555I' and A.POLICY_OWNER_NAME = 'TESTING' and A.DBS_OWNER_CIN ='S5555566I' and B.CHANNEL_ID ='ADVSGSTP' and B.RECORD_DATE_TIMESTAMP between '2018-09-20 00:00:00' and '2018-09-21 23:59:59';"
            );

            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);

            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

            //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());

        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

}

