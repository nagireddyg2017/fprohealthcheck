package com.dbs.bpds.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.helper.DBConnection;

import net.serenitybdd.core.annotations.findby.By;

import static org.assertj.core.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CustomerHoldingEnquiryPage {
	
	WebDriver driver;
	private static String filtercriteriaStaticText;
    private static String customerHoldingsInquiryLabeltext;
    private List <WebElement> cols_searchTable;
	private List <WebElement> rows_searchTable;
	private int i,j;
	private boolean searchResults_MoreThan100=false;
	private String  policyNumber;
	String countryCode="";
	
	public CustomerHoldingEnquiryPage (WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//customer-holding-enquiry/div/div[1]/div/h4")
	WebElement customerHoldingInquiryHeader;
		
	@FindBy(xpath = "//customer-holding-enquiry/div/div[2]/div/h6")
	WebElement staticTextCustomerHoldingInquiry;
	
	@FindBy (xpath = "//label[contains(text(),'Plan Type')]")
	WebElement labelPlanType;
		
	@FindBy (xpath = "//label[contains(text(),'Product Code')]")
	WebElement labelProductCode;
	
	@FindBy (xpath = "//label[contains(text(),'Insurer Component Code')]")
	WebElement labelInsurerComponentCode;
	
	@FindBy (xpath = "//label[contains(text(),'Insurer Name')]")
	WebElement labelInsurerName;
	
	@FindBy (xpath = "//label[contains(text(),'Channel Ref Number')]")
	WebElement labelChannelRefNumber;
	
	@FindBy (xpath = "//label[contains(text(),'Product Name')]")
	WebElement labelProductName;
	
	@FindBy (xpath = "//label[contains(text(),'Policy Number')]")
	WebElement labelPolicyNumber;
	
	@FindBy (xpath = "//label[contains(text(),'Policy Commencement Date')]")
	WebElement labelPolicyCommencementDate;
	
	@FindBy (xpath = "//label[contains(text(),'DBS Owner CIN')]")
	WebElement labelDBSOwnerCIN;
	
	@FindBy (xpath = "//label[contains(text(),'Channel ID')]")
	WebElement labelChannelID;
	
	@FindBy (xpath = "//label[contains(text(),'Insurer Record Received Date From')]")
	WebElement labelInsurerRecordReceivedDateFrom;
	
	@FindBy (xpath = "//label[contains(text(),'Insurer Record Received Date To')]")
	WebElement labelInsurerRecordReceivedDateTo;
	
	@FindBy (xpath = "//form/div[1]/div[2]/cst-dropdownlist")
	WebElement dropdownInsurerName;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='policyCommecementDate'] .cst-input")
	WebElement clickPolicyCommencementDate;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerRecordDateFrom'] .cst-input")
	WebElement clickInsurerRecordReceivedDateFrom;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerRecordDateTo'] .cst-input")
	WebElement clickInsurerRecordReceivedDateTo;
	
	@FindBy (xpath = "//form/div[2]/div[2]/input")
	WebElement enterProductCode;
	
	@FindBy (xpath = "//form/div[3]/div[2]/input")
	WebElement enterInsurerComponentCode;
	
	@FindBy (xpath = "//form/div[4]/div[2]/cst-dropdownlist")
	WebElement dropdownPlanType;
	
	@FindBy (xpath = "//form/div[5]/div[2]/input")
	WebElement enterChannelRefNumber;
	
	@FindBy (xpath = "//form/div[6]/div[2]/input")
	WebElement enterProductName;
	
	@FindBy (xpath = "//form/div[7]/div[2]/input")
	WebElement enterPolicyNumber;
	
	@FindBy (xpath = "//form/div[9]/div[2]/input")
	WebElement enterDbsOwnerCin;
	
	@FindBy (xpath = "//form/div[10]/div[2]/cst-dropdownlist")
	WebElement dropDownChannelID;
		
	@FindBy (xpath = "//div[2]/div/p")
	WebElement dialogMoreThan100Records;
	
	@FindBy (xpath = "//cst-dialog-actions/button")
	WebElement btnOkay;
	
	@FindBy (xpath = "//div/h6")
	WebElement txtFillCriteria;
	
	@FindBy(xpath = "//tr/td")
	WebElement noRecordAvailableText;
	
	@FindBy(xpath = "//button[@type='submit']")
	WebElement btnSearch;
	
	@FindBy(xpath = "//table/thead/tr/th")
	List<WebElement> tableSearchHeader;
	
	@FindBy(xpath = "//table/tbody/tr")
	List<WebElement> tableSearchBody;
		
	@FindBy(xpath = "//table/tbody/tr/td")
	WebElement tableSearchBodyText;
		
	@FindBy(how = How.CSS, using = "cst-list [role] [role='option']:nth-of-type(2)")
	WebElement selectInsurerName;
		
	@FindBy(xpath = "//div[1]/div/h4")
    WebElement customerHoldingEnquiryHeader;
			
	@FindBy(xpath="//cst-pager-next-buttons/a[@class='cst-link cst-pager-nav']")
	WebElement nextPageButton_enabled;
	
	@FindBy(xpath="//cst-pager-next-buttons/a[@class='cst-link cst-pager-nav cst-state-disabled']")
	WebElement nextPageButton_disabled;
	
	@FindBy(xpath="//span[1]/text()")
	WebElement selectedText;
		
	public void verifyCustomerHoldingInquiryPage(){
		customerHoldingsInquiryLabeltext = customerHoldingEnquiryHeader.getText();
		assertThat(customerHoldingsInquiryLabeltext.equalsIgnoreCase("Customer Holdings Inquiry"));
	}
	
	public void verifyStaticFillCriteriaText() throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{	
			filtercriteriaStaticText = txtFillCriteria.getText();
			assertThat(filtercriteriaStaticText.equalsIgnoreCase("Please fill in at least 1 criteria to proceed"));
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	}
		
	public void chkBtnSearchIsDiabled() throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			assertThat(!btnSearch.isEnabled());
		}
		else
		{
			System.out.println("User country code is not SG");
		}	
		
	}
	
	public void selectInsurerName(String selectInsurerName) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{	
			Utils.wait(driver).until(ExpectedConditions.visibilityOf(dropdownInsurerName));
			dropdownInsurerName.click();
			Actions keyDown = new Actions(driver);
			while (!(dropdownInsurerName.getText().equalsIgnoreCase(selectInsurerName)))
			{
				keyDown.sendKeys(Keys.chord(Keys.DOWN)).perform();
				dropdownInsurerName.click();
			}
		    labelInsurerName.click();//to get the cursor back to active state
		    if ((dropdownInsurerName.getText().equalsIgnoreCase(selectInsurerName)))
		    	{
		    		System.out.println("Insurer name selected as "+selectInsurerName);
		    	}
		    else
		    {
		    	System.out.println("Insurer name selected as "+dropdownInsurerName.getText());
		    }		
		}
		else
		{
			System.out.println("User country code is not SG");
		}
			
	}
	
	public void selectPlanType(String selectPlanType) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			Utils.wait(driver).until(ExpectedConditions.visibilityOf(dropdownPlanType));
			dropdownPlanType.click();
			Actions keyDown = new Actions(driver);
			while (!(dropdownPlanType.getText().equalsIgnoreCase(selectPlanType)))
			{
				keyDown.sendKeys(Keys.chord(Keys.DOWN)).perform();
				dropdownPlanType.click();
			}
		    labelPlanType.click();//to get the cursor back to active state
		    if ((dropdownPlanType.getText().equalsIgnoreCase(selectPlanType)))
		    	{
		    		System.out.println("Plan type selected as "+selectPlanType);
		    	}
		    else
		    {
		    	System.out.println("Insurer name selected as "+dropdownPlanType.getText());
		    }
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	}
	
	public void selectChannelID(String selectChannelID) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			Utils.wait(driver).until(ExpectedConditions.visibilityOf(dropDownChannelID));
			dropDownChannelID.click();
			Actions keyDown = new Actions(driver);
			while (!(dropDownChannelID.getText().equalsIgnoreCase(selectChannelID)))
			{
				keyDown.sendKeys(Keys.chord(Keys.DOWN)).perform();
				dropDownChannelID.click();
			}
		    labelChannelID.click();//to get the cursor back to active state
		    if ((dropDownChannelID.getText().equalsIgnoreCase(selectChannelID)))
		    	{
		    		System.out.println("Plan type selected as "+selectChannelID);
		    	}
		    else
		    {
		    	System.out.println("Insurer name selected as "+dropDownChannelID.getText());
		    }			
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	}
		
	public void chkBtnSearchIsEnabled() throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			assertThat(btnSearch.isEnabled());
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	}
	
	public void clickBtnSearch() throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			btnSearch.click();
			Thread.sleep(3000);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	}
	
	public void verifyNoRecordErrorBanner(){
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(noRecordAvailableText));
		assertThat(noRecordAvailableText.getText().contains("No records available."));
	}
	 
	public void enterProductName(String productName) throws Exception{ 
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 enterProductName.clear();
			 enterProductName.click();
			 enterProductName.sendKeys(productName);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
		
	 }
	
	public void enterInsurerComponentCode(String InsurerComponentCode) throws Exception{ 
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 enterInsurerComponentCode.clear();
			 enterInsurerComponentCode.click();
			 enterInsurerComponentCode.sendKeys(InsurerComponentCode);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	 
	public void enterProductCode(String productCode) throws Exception{
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			enterProductCode.clear();
			enterProductCode.click();
			enterProductCode.sendKeys(productCode);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	
	public void enterChannelRefNumber(String channelRefNumber) throws Exception{
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			enterChannelRefNumber.clear();
			enterChannelRefNumber.click();
			enterChannelRefNumber.sendKeys(channelRefNumber);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
		
	public void enterPolicyNumber(String policyNumber) throws Exception{
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			enterPolicyNumber.clear();
			enterPolicyNumber.click();
			enterPolicyNumber.sendKeys(policyNumber);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	
	 public void enterDBSOwnerCIN(String dbsOwnerCIN) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			enterDbsOwnerCin.clear();
			enterDbsOwnerCin.click();
			enterDbsOwnerCin.sendKeys(dbsOwnerCIN);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	 
	 public void selectPolicyCommencementDate(String policyCommencementDate) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			labelPolicyCommencementDate.click();
			clickPolicyCommencementDate.clear();
			clickPolicyCommencementDate.sendKeys(policyCommencementDate);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	 	 	 
	 public void selectInsurerRecordReceivedDateFrom(String insurerRecordReceivedDateFrom) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			labelInsurerRecordReceivedDateFrom.click();
			clickInsurerRecordReceivedDateFrom.clear();
			clickInsurerRecordReceivedDateFrom.sendKeys(insurerRecordReceivedDateFrom);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	 
	 public void selectInsurerRecordReceivedDateTo(String insurerRecordReceivedDateTo) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			labelInsurerRecordReceivedDateTo.click();
			clickInsurerRecordReceivedDateTo.clear();
			clickInsurerRecordReceivedDateTo.sendKeys(insurerRecordReceivedDateTo);
			Utils.take_screenshot(driver);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	 
	 public void enterAllInputFieldValues(String selectInsurerName,String productCode,String insurerComponentCode,String selectPlanType,String channelRefNumber, String productName, String policyNumber,String policyCommencementDate,String dbsOwnerCIN, String selectChannelID,String insurerRecordReceivedDateFrom, String insurerRecordReceivedDateTo) throws Exception 
	 {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
		 //Select insurer name
		 selectInsurerName(selectInsurerName);
		  
		 //enter product code
		 enterProductCode(productCode);
			 
		 //enter insurer component code 
		 enterInsurerComponentCode(insurerComponentCode);
			 	 
		 //select plan type
		 selectPlanType(selectPlanType);
		 
		 //enter channel ref number
		 enterChannelRefNumber(channelRefNumber);
		 
		 //enter product name 
		 enterProductName(productName);
		 		 
		 //enter policy number
		 enterPolicyNumber(policyNumber);
		
		 //enter policy commencement date
		 selectPolicyCommencementDate(policyCommencementDate);
		 
		 //enter dbs owner cin
		 enterDBSOwnerCIN(dbsOwnerCIN);
		 
		 //select channel id
		 selectChannelID(selectChannelID);
		 
		 //enter insurer record received date from
		 selectInsurerRecordReceivedDateFrom(insurerRecordReceivedDateFrom);
		 		 
		 //enter insurer record received date to
		 selectInsurerRecordReceivedDateTo(insurerRecordReceivedDateTo);
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	 
	 public void readingValuesFromSearchResultsTable (String filterField, String inputParam) throws Exception
	 {	
		 try
		 {	
			countryCode = verifyUserCountryCode();
			assertThat(countryCode.equalsIgnoreCase("SG"));
			if (countryCode.equalsIgnoreCase("SG"))
			{
			 if (dialogMoreThan100Records.isDisplayed())
			 {
				 if (dialogMoreThan100Records.getText().equalsIgnoreCase("Your search has returned more than 100 records. Please refine your search."))
				 {	
					 searchResults_MoreThan100 = true;
					 btnOkay.click();
					 System.out.println("Search returns more than 100 values");
				 }
			 }
			}
			else
			{
				System.out.println("User country code is not SG");
			}
		 }
		 catch (Exception e) {
				
			}
		 
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
		 if(!searchResults_MoreThan100)
		 {
			 try
			 {
				 if (tableSearchHeader.size()>0)
				 {
					 cols_searchTable = tableSearchHeader;
					 rows_searchTable = tableSearchBody;
					 					 				 
					 for ( j=1; j<=rows_searchTable.size(); j++)
					 {
							 if(tableSearchBodyText.getText()!="No records available.")
							 {							
								 verifyFieldsInSearchResults();
								 switch (filterField) {
									case "InsurerName":
										verifyInsurerNameFromSearchResults(inputParam);
										break;
									case "ProductName":
										verifyProductNameFromSearchResults(inputParam);
										break;
									case "ProductCode":
										verifyProductCodeFromSearchResults(inputParam);
										break;
									case "InsurerComponentCode":
										verifyInsurerComponentCodeFromSearchResults(inputParam);
										break;
									case "DBSOwnerCIN":
										verifyDBSOwnerCINFromSearchResults(inputParam);
										break;
									case "ChannelID":
										verifyChannelIDFromSearchResults(inputParam);
										break;
									case "PlanType":
										verifyPlanTypeFromSearchResults(inputParam);
										break;
									case "PolicyNumber":
										verifyPolicyNumberFromSearchResults(inputParam);
										break;
									case "ChannelRefNumber":
										verifyChannelRefNumberFromSearchResults(inputParam);
										break;
									case "PolicyCommencementDate":
										verifyPolicyCommencementDateFromSearchResults(inputParam);
										break;
									case "InsurerRecordReceivedDateFrom":
										verifyInsurerRecordReceivedDateFromFromSearchResults(inputParam);
										break;
									case "InsurerRecordReceivedDateTo":
										verifyInsurerRecordReceivedDateToFromSearchResults(inputParam);
										break;	
									default:
										System.out.println("Invalid Filter criteria");
										break;
								 }
							 }
						else
						{
							System.out.println("No records found for the given Search criteria");
						}
						
						 if ((j-1)==rows_searchTable.size())
						 {
							 if (nextPageButton_enabled.isDisplayed())
							 {
								 nextPageButton_enabled.click();
								 j=1;
							 }
						 }
							 }			 
					 }		  
			 }
			 catch (Exception e) {
				
			}
		 }
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	 public void readingValuesFromSearchResultsTable (String filterField, String inputParam,String inputParam1,String inputParam2,String inputParam3,String inputParam4,String inputParam5,String inputParam6,String inputParam7,String inputParam8,String inputParam9,String inputParam10,String inputParam11) throws Exception
	 {	
		 try
		 {
			countryCode = verifyUserCountryCode();
			assertThat(countryCode.equalsIgnoreCase("SG"));
			if (countryCode.equalsIgnoreCase("SG"))
			{
				 if (dialogMoreThan100Records.isDisplayed())
				 {
					 if (dialogMoreThan100Records.getText().equalsIgnoreCase("Your search has returned more than 100 records. Please refine your search."))
					 {	
						 searchResults_MoreThan100 = true;
						 btnOkay.click();
						 System.out.println("Search returns more than 100 values");
					 }
				 }
			}
			else
			{
				System.out.println("User country code is not SG");
			}
		 }
		 catch (Exception e) {
				
			}
		 
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
		 if(!searchResults_MoreThan100)
		 {
			 try
			 {
				 if (tableSearchHeader.size()>0)
				 {
					 cols_searchTable = tableSearchHeader;
					 rows_searchTable = tableSearchBody;
					 					 				 
					 for ( j=1; j<=rows_searchTable.size(); j++)
					 {
							 if(tableSearchBodyText.getText()!="No records available.")
							 {									 
								 switch (filterField) {
									case "AllValidInput":
										verifyFieldsInSearchResults();
										verifyAllValuesFromSearchResults(inputParam,inputParam1,inputParam2,inputParam3,inputParam4,inputParam5,inputParam6,inputParam7,inputParam8,inputParam9,inputParam10,inputParam11);
										break;
									default:
										System.out.println("Invalid Filter criteria");
										break;
								 }
							 }
						else
						{
							System.out.println("No records found for the given Search criteria");
						}
						
						 if ((j-1)==rows_searchTable.size())
						 {
							 if (nextPageButton_enabled.isDisplayed())
							 {
								 nextPageButton_enabled.click();
								 j=1;
							 }
						 }
							 }			 
					 }		  
			 }
			 catch (Exception e) {
				
			}
		 }
		}
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	 
	 public void readingValuesFromSearchResultsTable (String filterField, String inputParam, String inputParam1) throws Exception
	 {	
		 try
		 {
			countryCode = verifyUserCountryCode();
			assertThat(countryCode.equalsIgnoreCase("SG"));
			if (countryCode.equalsIgnoreCase("SG"))
			{
				 if (dialogMoreThan100Records.isDisplayed())
					 {
						 if (dialogMoreThan100Records.getText().equalsIgnoreCase("Your search has returned more than 100 records. Please refine your search."))
						 {	
							 searchResults_MoreThan100 = true;
							 btnOkay.click();
							 System.out.println("Search returns more than 100 values");
						 }
					 }
			}
			else
			{
				System.out.println("User country code is not SG");
			}
		 }
		 catch (Exception e) {
				
			}
		 
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
		 if(!searchResults_MoreThan100)
		 {
			 try
			 {
				 if (tableSearchHeader.size()>0)
				 {
					 cols_searchTable = tableSearchHeader;				 
					 rows_searchTable = tableSearchBody;
					 				 
					 for ( j=1; j<=rows_searchTable.size(); j++)
					 {
							 if(tableSearchBodyText.getText()!="No records available.")
							 {									 
								 switch (filterField) {
								 case "InsurerRecordReceivedDates":
										verifyFieldsInSearchResults();
										verifyInsurerRecordReceivedDateToFromSearchResults(inputParam);
										break;	
								 default:
										System.out.println("Invalid Filter criteria");
										break;
								 }
							 }
						else
						{
							System.out.println("No records found for the given Search criteria");
						}
						
						 if ((j-1)==rows_searchTable.size())
						 {
							 if (nextPageButton_enabled.isDisplayed())
							 {
								 nextPageButton_enabled.click();
								 j=1;
							 }
						 }
							 }			 
					 }		  
			 }
			 catch (Exception e) {
				
			}
		 }
		}
		else
		{
			System.out.println("User country code is not SG");
		}
		 
	 }
	 
	 private void verifyFieldsInSearchResults() throws Exception {
		 
		try {
			countryCode = verifyUserCountryCode();
			assertThat(countryCode.equalsIgnoreCase("SG"));
			if (countryCode.equalsIgnoreCase("SG"))
			{		 
			 for (i=1; i<=cols_searchTable.size(); i++)
			 {   		 			 
				 WebElement  tableSearchHeader_column = driver.findElement(By.xpath("//table/thead/tr/th[@aria-colindex='"+i+"']"));
				 if (tableSearchHeader_column.getText().equals(""))
				 {	 
					 WebElement scroll_right = tableSearchHeader_column;
					 scrollIntoView(scroll_right);
				 }
			 	 
				 if (tableSearchHeader_column.getText().equalsIgnoreCase("iB/mB template name"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("iB/mB template name")); 
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Segment MM"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Segment MM"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Segment TR"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Segment TR"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Segment TPC"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Segment TPC"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Segment PB"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Segment PB"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Policy Category (L1)"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Policy Category (L1)"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Coverage Type (L2)"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Coverage Type (L2)"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Product Category 3 (L3)"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Product Category 3 (L3)"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Name"))
				 {	
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Name"));
			 		
				 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Product Code"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Product Code"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Component Code"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Component Code"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Code"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Code"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Product Name"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Product Name"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Plan Type"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Plan Type"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Channel Ref Number"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Channel Ref Number"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Policy Number"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Policy Number"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Policy Commencement Date"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Policy Commencement Date"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("DBS Owner CIN"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("DBS Owner CIN"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Owner Name"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Owner Name"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Channel ID"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Channel ID"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Choice of Cover"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Choice of Cover"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Coverage Period (travel)"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Coverage Period (travel)"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Policy Status"))
			 	 {
			 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Policy Status"));
			 		
			 	 }
			 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Update Error"))
			 	 {
			 		assertThat(tableSearchHeader.get(i).getText().equalsIgnoreCase("Update Error"));
			 	 }
			 	 
			 	 if (i==25)
			 	 {
			 		 break;
			 	}
			 }
			}
			else
			{
				System.out.println("User country code is not SG");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
 
	 private void verifyInsurerNameFromSearchResults(String inputParam) throws Exception {
		 
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
		 if (inputParam.equalsIgnoreCase("Manulife (Singapore) Pte. Ltd."))
		 {
			 inputParam = "Manulife";
		 }
		 
		 for (i=1; i<=cols_searchTable.size(); i++)
		 {	
			 if (tableSearchHeader.get(i).getText().equals(""))
			 {	 
				 WebElement scroll_right = driver.findElement(By.xpath("//table/thead/tr/th["+i+"]"));
				 scrollIntoView(scroll_right);
			 }
			 
		     if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Insurer Name"))
			 {	
				 for(j=1;j<=rows_searchTable.size(); j++)
				 {
				 WebElement tableSearchBodyText_insurerName = driver.findElement(By.xpath("//table/tbody/tr["+j+"]"+"/td["+(i+1)+"]"));
				 assertThat(tableSearchBodyText_insurerName.getText().equalsIgnoreCase(inputParam));
				 }
				 break;
			 }
		 }
		}
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyProductCodeFromSearchResults(String inputParam) throws Exception 
	 {	 
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
		 for (i=1; i<=cols_searchTable.size(); i++)
		 {		 	 		 	 
			 WebElement  tableSearchHeader_column = driver.findElement(By.xpath("//table/thead/tr/th[@aria-colindex='"+i+"']"));
			 if (tableSearchHeader_column.getText().equals(""))
			 {	
				 WebElement scroll_right = tableSearchHeader_column;
				 scrollIntoView(scroll_right);
			 }
		 	 
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Product Code"))
			 {	
				 for(j=1;j<=rows_searchTable.size(); j++)
				 {
				 WebElement tableSearchBodyText_productCode = driver.findElement(By.xpath("//table/tbody/tr["+j+"]"+"/td["+(i+1)+"]"));
				 assertThat(tableSearchBodyText_productCode.getText().equalsIgnoreCase(inputParam));
				 }
				 break;
			 }
		 }
		}
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyInsurerComponentCodeFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
		 for (i=1; i<=cols_searchTable.size(); i++)
		 {	
			 WebElement  tableSearchHeader_column = driver.findElement(By.xpath("//table/thead/tr/th[@aria-colindex='"+i+"']"));
			 if (tableSearchHeader_column.getText().equals(""))
			 {	
				 WebElement scroll_right = tableSearchHeader_column;
				 scrollIntoView(scroll_right);
			 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Component Code"))
			 {	
				 for(j=1;j<=rows_searchTable.size(); j++)
				 {
				 WebElement tableSearchBodyText_insurerComponentCode = driver.findElement(By.xpath("//table/tbody/tr["+j+"]"+"/td["+(i)+"]"));
				 assertThat(tableSearchBodyText_insurerComponentCode.getText().equalsIgnoreCase(inputParam));
				 }
				 break;
			 }
		 }
		}
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyPlanTypeFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Plan Type"))
			 {	
				 assertThat(tableSearchBodyText.getText().contains(inputParam));
			 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
	 }
	 
	 private void verifyChannelRefNumberFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Channel Ref Number"))
			 {	
				 assertThat(tableSearchBodyText.getText().contains(inputParam));
			 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyProductNameFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Product Name"))
			 {	
				 assertThat(tableSearchBodyText.getText().contains(inputParam));
			 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyPolicyNumberFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Policy Number"))
			 {	
				 assertThat(tableSearchBodyText.getText().contains(inputParam));
			 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyPolicyCommencementDateFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Policy Commencement Date"))
			 {	
				 assertThat(tableSearchBodyText.getText().contains(Utils.DateFormat(inputParam)));
			 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyDBSOwnerCINFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("DBS Owner CIN"))
			 {	
				 assertThat(tableSearchBodyText.getText().contains(inputParam));
			 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyChannelIDFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Channel ID"))
			 {	
				 assertThat(tableSearchBodyText.getText().contains(inputParam));
			 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyInsurerRecordReceivedDateFromFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Insurer Record Received Date From"))
			 {	
				 assertThat(tableSearchBodyText.getText().contains(Utils.DateFormat(inputParam)));
			 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 private void verifyInsurerRecordReceivedDateToFromSearchResults(String inputParam) throws Exception {
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
			 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Insurer Record Received Date To"))
			 {	
				 assertThat(tableSearchBodyText.getText().contains(Utils.DateFormat(inputParam)));
			 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
		}
	 
	 public void verifyAllValuesFromSearchResults(String inputParam, String inputParam1,String inputParam2,String inputParam3,String inputParam4,String inputParam5,String inputParam6,String inputParam7,String inputParam8,String inputParam9,String inputParam10,String inputParam11) throws Exception
	 {	
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Insurer Name"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Product Code"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam1));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Insurer Component code"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam2));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Plan Type"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam3));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Channel Ref Number"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam4));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Product Name"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam5));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Policy Number"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam6));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase(Utils.DateFormat("Policy Commencement Date")));
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam7));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("DBS Owner CIN"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam8));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("ChannelID"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(inputParam9));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Insurer Record Received Date From"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(Utils.DateFormat(inputParam10)));
		 }
		 if (tableSearchHeader.get(i).getText().equalsIgnoreCase("Insurer Record Received Date To"))
		 {	
			 assertThat(tableSearchBodyText.getText().contains(Utils.DateFormat(inputParam11)));
		 }
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
	}
	 
	public void resetCustomerHoldingsEnquiryPage ()
	 {
		 driver.navigate().refresh();
	 }
	 
//	private void verifyMoreThan100RecordsMessage() {
//		 if (dialogMoreThan100Records.getText().equalsIgnoreCase("Your search has returned more than 100 records. Please refine your search."))
//		 {	
//			 btnOkay.click();
//		 }
//	}
	
	 public void verifyExistingFiltersPresent () throws Exception
	 {	
		countryCode = verifyUserCountryCode();
		assertThat(countryCode.equalsIgnoreCase("SG"));
		if (countryCode.equalsIgnoreCase("SG"))
		{
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelInsurerName));
		 assertThat(labelInsurerName.getText().contains("Insurer Name"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelProductCode));
		 assertThat(labelProductCode.getText().contains("Product Code"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelInsurerComponentCode));
		 assertThat(labelInsurerComponentCode.getText().contains("Insurer Component Code"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelPlanType));
		 assertThat(labelPlanType.getText().contains("Plan Type"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelChannelRefNumber));
		 assertThat(labelChannelRefNumber.getText().contains("Channel Ref Number"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelProductName));
		 assertThat(labelProductName.getText().contains("Product Name"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelPolicyNumber));
		 assertThat(labelPolicyNumber.getText().contains("Policy Number"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelPolicyCommencementDate));
		 assertThat(labelPolicyCommencementDate.getText().contains("Policy Commencement Date"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelDBSOwnerCIN));
		 assertThat(labelDBSOwnerCIN.getText().contains("DBS Owner CIN"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelChannelID));
		 assertThat(labelChannelID.getText().contains("Channel ID"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelInsurerRecordReceivedDateFrom));
		 assertThat(labelInsurerRecordReceivedDateFrom.getText().contains("Insurer Record Received Date From"));
		 
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelInsurerRecordReceivedDateTo));
		 assertThat(labelInsurerRecordReceivedDateTo.getText().contains("Insurer Record Received Date To"));
		 
		}	
		else
		{
			System.out.println("User country code is not SG");
		}
		 
	 }
	 
	 public void scrollIntoView(WebElement element){
			try {
				JavascriptExecutor executor = (JavascriptExecutor)driver;
				executor.executeScript("arguments[0].scrollIntoView(false);", element);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} 
	 
	 public String clickOnRecordToDownload(int recordNumber){
			
			return policyNumber;
		}
	 
	 public void verifyPolicyDetailsFileisDownloaded(int recordNumber){
		 try {	
			 countryCode = verifyUserCountryCode();
				assertThat(countryCode.equalsIgnoreCase("SG"));
				if (countryCode.equalsIgnoreCase("SG"))
				{
				 	if (noRecordAvailableText.getText().contains("No records available."))
				 	{
				 		System.out.println("No records available for the search criteria");
				 	}
				 	else
				 	{
					 	WebElement record = driver.findElement(By.xpath("//table/tbody/tr["+recordNumber+"]"));
						policyNumber = driver.findElement(By.xpath("//table/tbody/tr["+recordNumber+"]/td[16]")).getText();
						System.out.println(policyNumber);
						record.click();
						Thread.sleep(3000);
					    File policyDetailsFile = new File(Constants.DOWNLOAD_REPORT_PATH, Utils.getPolicyDetailsFileName(policyNumber));
					    System.out.println(policyDetailsFile);
						assertThat(policyDetailsFile).exists().hasName(Utils.getPolicyDetailsFileName(policyNumber)).hasExtension("xlsx");
				 	}
				}
				else
				{
					System.out.println("User country code is not SG");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	        	        
	    }
	
	 public String verifyUserCountryCode() throws Exception
	 {
		 try {
			DBConnection conn = new DBConnection();
			ResultSet resultSet = null;
			String ExecuteQuery = "select country_code from dbs_user_master where email_id = '"+Constants.USERNAME+"@dbs.com'";
			resultSet = conn.readData(ExecuteQuery);
			Boolean nextRecAvailable =  resultSet.next();
			if(nextRecAvailable){
	  		 while(nextRecAvailable || resultSet.next()){
	  			 nextRecAvailable = false;
	  			 if (resultSet.getString("COUNTRY_CODE").trim().equalsIgnoreCase("SG"))
	  			 {
	  				 countryCode = "SG";
	  			 }
	  			 else
	  			 {
	  				countryCode =resultSet.getString("COUNTRY_CODE");
	  			 }
	  		 }
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return countryCode;
	 }
	 
	 public void enterProductCode()
	 {
		 
	 }

}
