package com.dbs.bpds.steps;

import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.LandingPage;
import com.dbs.bpds.pages.ProductApprovedPage;
import com.dbs.bpds.pages.ProductCancelledPage;

import net.thucydides.core.annotations.Step;

public class ProductApprovedPage_Steps {
	
	private static final String Case = null;
	ProductApprovedPage productApprovedPage;
	LandingPage landingPage;
	PageObjectFactory pageObjectFactory;
		
	@Step
	public void launchProductApprovedPage() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.clkProductApproved();
		productApprovedPage.verifyLabelApproved();
	}
	@Step
	public void chkFillcriteriaStaticText() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.verifyStaticFillCriteriaText();
	}
	
	@Step
	public void resetProductApprovedPage() throws InterruptedException{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		landingPage = pageObjectFactory.getLandingPage();
		landingPage.clickOnProductAdminModule();
		landingPage.verifyPendingAcitonPage();
		productApprovedPage.clkProductApproved();
		productApprovedPage.verifyLabelApproved();		
	}
	
	@Step
	public void chkUserOnProductApprovedPage() throws InterruptedException{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.verifyLabelApproved();		
	}
	@Step
	public void verifySearchButtonDisabled() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.chkBtnSearchIsDiabled();
	}
	
	@Step
	public void verifyToDateDisabled() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.chkBtnTodateIsDiabled();
	}
	
	@Step
	public void verifySearchFilterLabels(){
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.verifyFilterLabels();
	}
	
	@Step
	public void verifyUserCountryCode() throws Exception{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.verifyUserCountryCode();
	}
	
	@Step
	public void selectInsurerNameFromDropdown(String insurerName) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.selectInsurerName(insurerName);
		productApprovedPage.clickBtnSearch();
	}	
	
	@Step
	public void chkPopUpDisplayed () {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.chkPopUpDisplayedAndClickOK();
	}
	
	@Step
	public void enterProductCodeInApprovedPage(String productCode) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.enterProductCode(productCode);
	}
	
	@Step
	public void enterInsurerComponentCodeInApprovedPage(String insurerComponentCode) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.enterInsurerComponentCode(insurerComponentCode);
	}
	
	@Step
	public void enterProductNameInApprovedPage(String productName) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.enterProductName(productName);
	}
	@Step
	public void enterApprovedByInApprovedPage(String approvedBy) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.enterApprovedBy(approvedBy);
	}
		
	@Step
	public void VerifyRecordStatus(String searchText, String searchColName) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.verifyFieldsInSearchResults();
		productApprovedPage.verifySearchTextAndRecordStatusFromSearchResults(searchText, searchColName);
	}
	
	@Step
	public void VerifyWildCardSearchForProdName(String searchText, String searchColName) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.verifyWildCardSearchAndRecordStatusFromSearchResults(searchText, searchColName);
	}
	
	@Step
	public void verifyColumnLabelsByDefault() throws InterruptedException 
	{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.verifyFieldsInSearchResults();
	}
	@Step
	public void verifyRecordStatusByDefault() throws Exception
	{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		resetProductApprovedPage();
		productApprovedPage.verifyRecordStatus_ApprovedPage();
	}
	@Step
	public void verifyLastApprovedDateTimeByDefaultInDescending() throws Exception
	{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		resetProductApprovedPage();
		productApprovedPage.verifyLastApprovedDateTimeByDefaultInDescending();
	}
	
	@Step
	public void enterApprovedDateFromAndToInApprovedPage(String approvedDateFrom, String approvedDateTo) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.selectApprovedDateFrom(approvedDateFrom);
		productApprovedPage.selectApprovedDateTo(approvedDateTo);
	}	
	
	@Step
	public void verifyLastApprovedDateTimeForSpecifiedDates(String ApprovedDateFrom, String ApprovedDateTo) throws Exception
	{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productApprovedPage = pageObjectFactory.getProductApprovedPage();
		productApprovedPage.verifyLastApprovedDateTimeForSpecifiedDates(ApprovedDateFrom,ApprovedDateTo);
	}
	
}
