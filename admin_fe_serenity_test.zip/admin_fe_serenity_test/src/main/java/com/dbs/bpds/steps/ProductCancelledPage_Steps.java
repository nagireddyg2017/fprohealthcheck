package com.dbs.bpds.steps;

import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.LandingPage;
import com.dbs.bpds.pages.ProductApprovedPage;
import com.dbs.bpds.pages.ProductCancelledPage;

import net.thucydides.core.annotations.Step;

public class ProductCancelledPage_Steps {
	
	private static final String Case = null;
	ProductCancelledPage productCancelledPage;
	LandingPage landingPage;
	PageObjectFactory pageObjectFactory;
	
	@Step
	public void launchProductCancelledPage() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.clkProductCancelled();
		productCancelledPage.verifyLabelCancelled();
	}
	@Step
	public void chkFillcriteriaStaticText() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.verifyStaticFillCriteriaText();
	}
		
	@Step
	public void resetProductCancelledPage() throws InterruptedException{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		landingPage = pageObjectFactory.getLandingPage();
		landingPage.clickOnProductAdminModule();
		landingPage.verifyPendingAcitonPage();
		productCancelledPage.clkProductCancelled();
		productCancelledPage.verifyLabelCancelled();		
	}
	
	@Step
	public void chkUserOnProductCancelledPage() throws InterruptedException{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.verifyLabelCancelled();		
	}
	@Step
	public void verifySearchButtonDisabled() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.chkBtnSearchIsDiabled();
	}
	
	@Step
	public void verifyToDateDisabled() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.chkBtnTodateIsDiabled();
	}
	
	@Step
	public void verifySearchFilterLabels(){
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.verifyFilterLabels();
	}
	
	@Step
	public void verifyUserCountryCode() throws Exception{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.verifyUserCountryCode();
	}
	
	@Step
	public void selectInsurerNameFromDropdown(String insurerName) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.selectInsurerName(insurerName);
		productCancelledPage.clickBtnSearch();
	}	
	
	@Step
	public void chkPopUpDisplayed () {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.chkPopUpDisplayedAndClickOK();
	}
	@Step
	public void verifyColumnLabelsByDefault() throws InterruptedException 
	{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.verifyColumnLabelsInSearchResults();
	}
	@Step
	public void verifyRecordStatusByDefaultOnCancelledPage() throws Exception
	{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		resetProductCancelledPage();
		productCancelledPage.verifyRecordStatus_CancelledPage();
	}
	@Step
	public void verifyLastApprovedDateTimeByDefaultInDescendingOnCancelledPage() throws Exception
	{		
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		resetProductCancelledPage();
		productCancelledPage.verifyLastApprovedDateTimeByDefaultInDescendingOnCancelledPage();
	}
	
	@Step
	public void VerifyRecordStatusBasedonSearchText(String searchText, String searchColName) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.verifySearchTextAndRecordStatusFromSearchResults(searchText, searchColName);
	}
	@Step
	public void verifyLastApprovedDateTimeForSpecifiedDates(String ApprovedDateFrom, String ApprovedDateTo) throws Exception
	{
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		productCancelledPage = pageObjectFactory.getProductCancelledPage();
		productCancelledPage.verifyLastApprovedDateTimeForSpecifiedDates(ApprovedDateFrom,ApprovedDateTo);
	}
	
}
