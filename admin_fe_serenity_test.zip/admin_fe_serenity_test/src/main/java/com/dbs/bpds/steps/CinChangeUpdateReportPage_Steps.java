package com.dbs.bpds.steps;

import java.io.IOException;
import java.sql.SQLException;

import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.CinChangeUpdateReportPage;

import net.thucydides.core.annotations.Step;

public class CinChangeUpdateReportPage_Steps {

	CinChangeUpdateReportPage cinChangeUpdateReportPage;
	PageObjectFactory pageObjectFactory;

	@Step
	public void launchCINChangeUpdateReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.clkReports();
		cinChangeUpdateReportPage.clickCINChangeUpdateReport();
		cinChangeUpdateReportPage.verifyCINChangeUpdateReport();
	}

	@Step
	public void resetCINChangeUpdateReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCINChangeUpdateReport();
	}

	@Step
	public void chkFillcriteriaStaticText() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyStaticFillCriteriaText();
	}

	@Step
	public void chkExportBtnISDisabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.chkBtnExportIsDiabled();
	}

	@Step
	public void selectCinUpdateReportInsurerName() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.selectInsurerName();
	}

	@Step
	public void chkExportBtnISEnabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.chkBtnExportIsEnabled();
	}

	@Step
	public void verifyNoRecordFound() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyNoRecordErrorBanner();
	}

	@Step
	public void clickExportButtonReports() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.clickBtnExport();
	}

	@Step
	public void verifyDownloadCINChangeUpdateReportFilename() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCINChangeUpdateReportFileisDownloaded();
	}

	@Step
	public void enterCinUpdateReportProductName(String productName) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.enterProductName(productName);
	}

	@Step
	public void enterCinUpdateReportInsurerOwnerCIN(String insurerOwnerCIN) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.enterInsurerOwnerCIN(insurerOwnerCIN);
	}

	@Step
	public void enterCinUpdateReportInsurerOwnerName(String insurerOwnerName) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.enterInsurerOwnerName(insurerOwnerName);
	}

	@Step
	public void enterCinUpdateReportDBSOwnerCin(String dbsOwnerCin) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.enterDBSOwnerCin(dbsOwnerCin);
	}

	@Step
	public void selectCinUpdateReportChannelId() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.selectChannelID();
	}

	@Step
	public void selectCinUpdateReportInsurerRecordDate(String insurerRecordReceivedDateFrom,
			String insurerRecordReceivedDateTo) throws IOException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.selectInsurerDateFrom(insurerRecordReceivedDateFrom);
		cinChangeUpdateReportPage.selectInsurerDateTo(insurerRecordReceivedDateTo);
	}

	@Step
	public void validateExcelDBCinUpdateReportsInsurerName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCinChangeReportDBTestInsurerName();
	}

	@Step
	public void validateExcelDBCinUpdateReportsProductName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCinChangeReportDBTestProductName();
	}

	@Step
	public void validateExcelDBCinUpdateReportsInsurerOwnerCIN() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCinChangeReportDBTestInsurerOwnerCIN();
	}

	@Step
	public void validateExcelDBCinUpdateReportsInsurerOwnerName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCinChangeReportDBTestInsurerOwnerName();
	}

	@Step
	public void validateExcelDBCinUpdateReportsDBSOwnerCIN() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCinChangeReportDBTestDBSOwnerCIN();
	}

	@Step
	public void validateExcelDBCinUpdateReportsChannelID() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCinChangeReportDBTestChannelID();
	}

	@Step
	public void validateExcelDBCinUpdateReportsInsurerRecordDate() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCinChangeReportDBTestInsurerRecordDate();
	}

	@Step
	public void validateExcelDBCinUpdateReportsAllValidInput() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cinChangeUpdateReportPage = pageObjectFactory.getCINChangeUpdateReportPage();
		cinChangeUpdateReportPage.verifyCinChangeReportDBTestAllValidInput();
	}

}

