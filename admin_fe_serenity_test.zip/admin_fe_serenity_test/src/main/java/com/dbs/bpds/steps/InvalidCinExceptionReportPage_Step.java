package com.dbs.bpds.steps;

import java.io.IOException;
import java.sql.SQLException;

import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.InvalidCinExceptionReportPage;

import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;

public class InvalidCinExceptionReportPage_Step {

	InvalidCinExceptionReportPage invalidCinExceptionReportPage;
	PageObjectFactory pageObjectFactory;
	
	
	@Step
	public void chkInvalidCINReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.clkReports();
		invalidCinExceptionReportPage.clkInvalidCINReport();
		invalidCinExceptionReportPage.verifyInvaliCINReport();
		Serenity.takeScreenshot();
	}
	@Step
	public void chkFillcriteriaStaticText() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyStaticFillCriteriaText();
	}
	@Step
	public void resetInvalidCINReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyInvaliCINReport();		
	}
	@Step
	public void chkExportBtnISDisabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.chkBtnExportIsDiabled();
	}
	@Step
	public void selectInvalidCinInsurerNameReports() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.slectInsurerName();
	}
	@Step
	public void chkExportBtnISEnabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.chkBtnExportIsEnabled();
	}
	@Step
	public void clickExportButtonReports() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.clickBtnExport();		
	}
	
	@Step
	public void verifyDownloadInvalidCinReportFilename() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyFileisDownloaded();
	}
	
	@Step
	public void enterInvalidReportProductName(String productName) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.enterProductName(productName);		
	}
	
	@Step
	public void enterInvalidReportInsurerOwnerCIN(String insurerOwnerCIN) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.enterInsurerOwnerCIN(insurerOwnerCIN);
	}
	
	@Step
	public void enterInvalidReportInsurerOwnerName(String insurerOwnerName) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.enterInsurerOwnerName(insurerOwnerName);		
	}
	
	@Step
	public void selectInvalidReportChannelId() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.selectChannelID();		
	}
	
	@Step
	public void selectInvalidReportInsurerRecordDate(String insurerRecordReceivedDateFrom, String insurerRecordReceivedDateTo) throws IOException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.selectInsurerDateFrom(insurerRecordReceivedDateFrom);
		invalidCinExceptionReportPage.selectInsurerDateTo(insurerRecordReceivedDateTo);		
	}
	
	@Step
	public void verifyNoRecordFound(){
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyNoRecordErrorBanner();
	}
	
	@Step
	public void validateExcelDBInValidCINReportsInsurerName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyInvalidCinReportDBTestInsurerName();
	}
	@Step
	public void validateExcelDBInValidCINReportsProductName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyInvalidCinReportDBTestProductName();
	}
	@Step
	public void validateExcelDBInValidCINReportsInsurerOwnerCIN() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyInvalidCinReportDBTestInsurerOwnerCIN();
	}
	@Step
	public void validateExcelDBInValidCINReportsInsurerOwnerName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyInvalidCinReportDBTestInsurerOwnerName();
	}
	@Step
	public void validateExcelDBInValidCINReportsChannelID() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyInvalidCinReportDBTestChannelID();
	}
	@Step
	public void validateExcelDBInValidCINReportsInsurerRecordReceivedDate() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyInvalidCinReportDBTestInsurerRecordDate();
	}
	@Step
	public void validateExcelDBInValidCINReportAllValidInput() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		invalidCinExceptionReportPage = pageObjectFactory.getInvalidCinExceptionReportPage();
		invalidCinExceptionReportPage.verifyInvalidCinReportDBTestAllValidInput();
	}

}


