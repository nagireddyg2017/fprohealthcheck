package com.dbs.bpds.pages;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.helper.DBConnection;

import net.serenitybdd.core.annotations.findby.By;

public class ProductApprovedPage {
	
	WebDriver driver;
	String countryCode = null;
    private List <WebElement> cols_searchTable;
	private List <WebElement> rows_searchTable;
	private int i,j;
	//private List <String> Approved_DateTime;
	private List<String> dateTimeTable;
	
	
	public ProductApprovedPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
		dateTimeTable = new ArrayList<>();
	}
	
	@FindBy(how = How.LINK_TEXT, using = "Approved")
	WebElement clickApproved;
	
	@FindBy(xpath = "//div/div[1]/div/h4[contains(text(), 'Approved')]")
	WebElement labelApproved;
	
	@FindBy(how = How.XPATH, using = "//div[2]/div/p")
	WebElement dialogBoxPopUp;

	@FindBy(xpath = "//div[2]/div/p")
	WebElement dialogBoxPopUpMessage;

	@FindBy(how = How.XPATH, using = "//cst-dialog-actions/button")
	WebElement dialogBoxPopUp_OkayButton;
	
	@FindBy(xpath = "//div/div[2]/div/h6[contains(text(), 'Please fill in')]")
	WebElement txtFillCriteria;
	
	@FindBy(xpath = "//button[@type='submit']")
	WebElement btnSearch;
	
	@FindBy (xpath = "//label[contains(text(),'Product Code')]")
	WebElement labelProductCode;
	
	@FindBy (xpath = "//label[contains(text(),'Insurer Component Code')]")
	WebElement labelInsurerComponentCode;
	
	@FindBy (xpath = "//label[contains(text(),'Insurer Name')]")
	WebElement labelInsurerName;
	
	@FindBy (xpath = "//label[contains(text(),'Product Name')]")
	WebElement labelProductName;
	
	@FindBy (xpath = "//label[contains(text(),'Approved By')]")
	WebElement labelApprovedBy;
	
	@FindBy (xpath = "//label[contains(text(),'Approved Date From')]")
	WebElement labelApprovedDateFrom;
	
	@FindBy (xpath = "//label[contains(text(),'Approved Date To')]")
	WebElement labelApprovedDateTo;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='approvedDateFrom'] .cst-input")
	WebElement clickApprovedDateFrom;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='approvedDateTo'] .cst-input")
	WebElement clickApprovedDateTo;
	
	@FindBy (xpath = "//form/div[3]/div[2]/cst-dropdownlist")
	WebElement dropdownInsurerName;
	
	@FindBy (xpath = "//div[1]/div[2]/input[@formcontrolname='productCode']")
	WebElement enterProductCode;
	
	@FindBy (xpath = "//div[2]/div[2]/input[@formcontrolname='insurerComponentCode']")
	WebElement enterInsurerComponentCode;
	
	@FindBy (xpath = "//div[4]/div[2]/input[@formcontrolname='productName']")
	WebElement enterProductName;
	
	@FindBy (xpath = "//div[5]/div[2]/input[@formcontrolname='approvedBy']")
	WebElement enterApprovedBy;
	
	@FindBy(xpath = "//table/thead/tr/th")
	List<WebElement> tableSearchHeader;
	
	@FindBy(xpath = "//table/tbody/tr")
	List<WebElement> tableSearchBody;
	
	@FindBy(xpath = "//table/tbody/tr/td")
	List<WebElement> tableRowCount;	
		
	@FindBy(xpath = "//table/tbody/tr/td")
	WebElement tableSearchBodyText;
	
	@FindBy(xpath = "//form/div[7]/div[2]")
	WebElement LabelToDate_ByDefault;
	
	@FindBy(xpath="//cst-pager-next-buttons/a[@class='cst-link cst-pager-nav']")
	WebElement nextPageButton_enabled;
	
	@FindBy(xpath="//cst-pager-next-buttons/a[1]/span")	
	WebElement nextPageButton_disabled;		

	
	public void clkProductApproved() {		
		clickApproved.click();		
	}	

	public void verifyLabelApproved() throws InterruptedException{

		assertThat(labelApproved.getText().equalsIgnoreCase("Approved"));
		Thread.sleep(3000);
	}
	
	public void verifyStaticFillCriteriaText() {
		assertThat(txtFillCriteria.getText().equalsIgnoreCase("Please fill in at least 1 search criteria to proceed"));		
	}
	
	public void chkBtnSearchIsDiabled() throws Exception {
		
		assertThat(!btnSearch.isEnabled());			
	}
	
	public void chkBtnTodateIsDiabled() throws Exception {
		
		assertThat(!LabelToDate_ByDefault.isEnabled());			
	}
	
	public void verifyFilterLabels(){
		
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelProductCode));
		assertThat(labelInsurerName.getText().contains("Product Code"));
		
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelInsurerComponentCode));
		assertThat(labelInsurerName.getText().contains("Insurer Component Code"));
		
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelInsurerName));
		assertThat(labelInsurerName.getText().contains("Insurer Name"));
		
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelProductName));
		assertThat(labelInsurerName.getText().contains("Product Name"));
		
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelApprovedBy));
		assertThat(labelInsurerName.getText().contains("Approved By"));
		
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelApprovedDateFrom));
		assertThat(labelInsurerName.getText().contains("Approved Date From"));
		
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(labelApprovedDateTo));
		assertThat(labelInsurerName.getText().contains("Approved Date To"));			
	}
	
	public void verifyUserCountryCode() throws Exception
	 {
		 try {
			DBConnection conn = new DBConnection();
			ResultSet resultSet = null;
			String ExecuteQuery = "select country_code from dbs_user_master where email_id = '"+Constants.USERNAME+"@dbs.com'";
			resultSet = conn.readData(ExecuteQuery);
			Boolean nextRecAvailable =  resultSet.next();
			if(nextRecAvailable){
	  		 while(nextRecAvailable || resultSet.next()){
	  			 nextRecAvailable = false;
	  			 if (resultSet.getString("COUNTRY_CODE").trim().equalsIgnoreCase("SG"))
	  			 {
	  				countryCode = "SG";
	  				System.out.println("DB:"+resultSet.getString("COUNTRY_CODE"));
	  				assertThat(countryCode.equalsIgnoreCase("SG"));
	  			 }
	  			 else
	  			 {
	  				//countryCode = resultSet.getString("COUNTRY_CODE");
	  				System.out.println("User country code is not SG");
	  			 }
	  		 }
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
	
	public void selectInsurerName(String selectInsurerName) throws Exception
	{	
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(dropdownInsurerName));
		dropdownInsurerName.click();
		Actions keyDown = new Actions(driver);
		while (!(dropdownInsurerName.getText().equalsIgnoreCase(selectInsurerName)))
		{
			keyDown.sendKeys(Keys.chord(Keys.DOWN)).perform();
			dropdownInsurerName.click();
		}
	    labelInsurerName.click();//to get the cursor back to active state
	    if ((dropdownInsurerName.getText().equalsIgnoreCase(selectInsurerName)))
    	{
    		System.out.println("Insurer name selected as: "+selectInsurerName);
    	}
	    else
	    {
	    	System.out.println("Insurer name selected as: "+dropdownInsurerName.getText());
	    }				
	}	
	public void clickBtnSearch() throws Exception {
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(btnSearch));
		btnSearch.click();
		Thread.sleep(3000);
	}	
	public void chkPopUpDisplayedAndClickOK(){
		try {
			if (Utils.wait(driver).until(ExpectedConditions.visibilityOf(dialogBoxPopUp)).isDisplayed()) {
				//System.out.println("text--"+dialogBoxPopUpMessage.getText());
				//System.out.println("Your search has returned more than 100 records. Please refine your search.");
				assertThat(dialogBoxPopUpMessage.getText().equals("Your search has returned more than 100 records. Please refine your search."));
				dialogBoxPopUp_OkayButton.click();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	public void enterProductCode(String productCode){
			enterProductCode.clear();
			enterProductCode.click();
			enterProductCode.sendKeys(productCode);
	}	
	public void enterInsurerComponentCode(String insurerComponentCode){
		enterInsurerComponentCode.clear();
		enterInsurerComponentCode.click();
		enterInsurerComponentCode.sendKeys(insurerComponentCode);
}
	public void enterProductName(String productName){		 
			 enterProductName.clear();
			 enterProductName.click();
			 enterProductName.sendKeys(productName);		 
	}
	public void enterApprovedBy(String approvedBy){		 
			enterApprovedBy.clear();
			enterApprovedBy.click();
			enterApprovedBy.sendKeys(approvedBy);		 
	}
	
	public void selectApprovedDateFrom(String ApprovedDateFrom)  {
		//labelApprovedDateFrom.click();
		clickApprovedDateFrom.clear();
		clickApprovedDateFrom.sendKeys(ApprovedDateFrom);
	}

	public void selectApprovedDateTo(String ApprovedDateFrom)  {
		clickApprovedDateTo.clear();
		clickApprovedDateTo.sendKeys(ApprovedDateFrom);
	}
	public void verifyFieldsInSearchResults() throws InterruptedException{
		
		Thread.sleep(3000);
		 cols_searchTable = tableSearchHeader;
		 //System.out.println("No of Cols: "+cols_searchTable.size());
		 for (i=1; i<=cols_searchTable.size(); i++)
		 {   
			 WebElement  tableSearchHeader_column = driver.findElement(By.xpath("//table/thead/tr/th[@aria-colindex='"+i+"']"));
			 if (tableSearchHeader_column.getText().equals(""))
			 {	 
				 WebElement scroll_right = tableSearchHeader_column;
				 scrollIntoView(scroll_right);
			 }				 
	 
			 if (tableSearchHeader_column.getText().equalsIgnoreCase("Record Status"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Record Status")); 		 		
		 	 }
			 if (tableSearchHeader_column.getText().equalsIgnoreCase("Maintenance Status"))
			 {	
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Maintenance Status"));		 		
			 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Product Name"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Product Name"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Product Code"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Product Code"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Component Code"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Component Code"));		 		
		 	 }			 
			 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Name"))
			 {	
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Name"));		 		
			 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Code"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Code"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Country Code"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Country Code"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Plan Type"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Plan Type"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Group Policy Indicator"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Group Policy Indicator"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Group Policy No."))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Group Policy No."));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Product Tenure"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Product Tenure"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Launch Start Date"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Launch Start Date"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Launch End Date"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Launch End Date"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Bank Account no to credit"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Bank Account no to credit"));
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Main Currency Type"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Main Currency Type"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Choice of Cover"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Choice of Cover"));		 		
		 	 }
		 	 
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Coverage Period (travel)"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Coverage Period (travel)"));
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Record Received Date Timestamp"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Insurer Record Received Date Timestamp"));
		 	 }			 	 
			 if (tableSearchHeader_column.getText().equalsIgnoreCase("iB/mB template name"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("iB/mB template name"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Segment MM"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Segment MM"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Segment TR"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Segment TR"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Segment TPC"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Segment TPC"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Segment PB"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Segment PB"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Policy Category (L1)"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Policy Category (L1)"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Coverage Type (L2)"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Coverage Type (L2)"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Product Category 3 (L3))"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Product Category 3 (L3)"));		 		
		 	 }

		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Remarks"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Remarks"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Last Updated By"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Last Updated By"));		 		
		 	 }
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Last Updated Date/Time"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Last Updated Date/Time"));
		  	 } 

		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Last Approved By"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Last Approved By"));		 		
		 	 }
		 	 
		 	 if (tableSearchHeader_column.getText().equalsIgnoreCase("Last Approved Date/Time"))
		 	 {
		 		assertThat(tableSearchHeader_column.getText().equalsIgnoreCase("Last Approved Date/Time"));
		 	 }
		 }
	}		
	public void verifySearchTextAndRecordStatusFromSearchResults(String inputParam, String SearchColName) throws Exception {
		 Thread.sleep(3000);
		 cols_searchTable = tableSearchHeader;
		 rows_searchTable = tableSearchBody;
		 int ColNo;
		 int RecCol;
		 WebElement tableHeader_Searchcolumn = null;
				 
		 //Refresh the page to Reset column
		 clickBtnSearch();
		 
		 //To find Search column index 
		 for ( ColNo=1;ColNo<=cols_searchTable.size(); ColNo++)
		 {
			 tableHeader_Searchcolumn = driver.findElement(By.xpath("//table/thead/tr/th["+ColNo+"]"));
			 //System.out.println(tableHeader_Searchcolumn.getText());			 
			 if(tableHeader_Searchcolumn.getText().equals(""))
			 {
				 WebElement scroll_right = tableHeader_Searchcolumn;
				 scrollIntoView(scroll_right);
			 }
			 if (tableHeader_Searchcolumn.getText().equalsIgnoreCase(SearchColName))
			 {
				 System.out.println("SearchColName: "+SearchColName+",ColNo: "+ColNo);
				 break;
			 }
		 }	
		 if(tableHeader_Searchcolumn.getText().equalsIgnoreCase(SearchColName))
		 {
			 //Refresh the page to Reset column
			 clickBtnSearch();
		 }
		 for ( RecCol=1;RecCol<=cols_searchTable.size(); RecCol++)
		 {
			 WebElement tableHeader_RecStatuscolumn = driver.findElement(By.xpath("//table/thead/tr/th["+RecCol+"]"));
			 //System.out.println(tableHeader_RecStatuscolumn.getText());
			 if (tableHeader_RecStatuscolumn.getText().equalsIgnoreCase("Record Status"))
			 {
				 System.out.println("Record Status ColNo: "+RecCol);
				 break;
			 }
		 }		 
		 for(int i=1;i<=rows_searchTable.size(); i++)
		 {	 	 
			 WebElement Row_Data = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td["+ColNo+"]"));
	 	     
			 //verifying Input data in respective column 
		 	 if (Row_Data.getText().equalsIgnoreCase(inputParam))
		 	 {	
		 		 System.out.println("Tabledata: "+Row_Data.getText()+", InputSearchText:"+inputParam);
				 assertThat(Row_Data.getText().equalsIgnoreCase(inputParam));
			 }	
		 	//verifying Status is "Approved" for the displayed records with searched text 
		 	 WebElement Row_RecStatus = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td["+RecCol+"]"));
			 if (Row_RecStatus.getText().equalsIgnoreCase("Approved"))
			 {		
				 System.out.println("Tabledata-Record Status : "+Row_RecStatus.getText());
				 assertThat(Row_RecStatus.getText().equalsIgnoreCase("Approved")); 
			 }				 
		}
	}	
	
	public void verifyWildCardSearchAndRecordStatusFromSearchResults(String inputParam, String SearchColName) throws Exception {
		 Thread.sleep(3000);
		 cols_searchTable = tableSearchHeader;
		 rows_searchTable = tableSearchBody;
		 int ColNo;
		 int RecCol;
		 WebElement tableHeader_Searchcolumn = null;
				 
		 //Refresh the page to Reset column
		 clickBtnSearch();
		 
		 //To find Search column index for mentioned InputColumn
		 for ( ColNo=1;ColNo<=cols_searchTable.size(); ColNo++)
		 {
			 tableHeader_Searchcolumn = driver.findElement(By.xpath("//table/thead/tr/th["+ColNo+"]"));			 			 
			 if(tableHeader_Searchcolumn.getText().equals(""))
			 {
				 WebElement scroll_right = tableHeader_Searchcolumn;
				 scrollIntoView(scroll_right);
			 }
			 if (tableHeader_Searchcolumn.getText().equalsIgnoreCase(SearchColName))
			 {
				 System.out.println("SearchColName: "+SearchColName+",ColNo: "+ColNo);
				 break;
			 }
		 }	
		 if(tableHeader_Searchcolumn.getText().equalsIgnoreCase(SearchColName))
		 {
			 //Refresh the page to Reset column
			 clickBtnSearch();
		 }
		 for ( RecCol=1;RecCol<=cols_searchTable.size(); RecCol++)
		 {
			 WebElement tableHeader_RecStatuscolumn = driver.findElement(By.xpath("//table/thead/tr/th["+RecCol+"]"));
			 //System.out.println(tableHeader_RecStatuscolumn.getText());
			 if (tableHeader_RecStatuscolumn.getText().equalsIgnoreCase("Record Status"))
			 {
				 //System.out.println("Record Status ColNo: "+RecCol);
				 break;
			 }
		 }		 
		 for(int i=1;i<=rows_searchTable.size(); i++)
		 {	 	 
			 WebElement Row_Data = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td["+ColNo+"]"));
	 	     
			 //verifying Input data in respective column 
		 	 if (Row_Data.getText().contains(inputParam))
		 	 {	
		 		 assertThat(Row_Data.getText().equalsIgnoreCase(inputParam));
			 }	
		 	//verifying Status is "Approved" for the displayed records with searched text 
		 	 WebElement Row_RecStatus = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td["+RecCol+"]"));
			 if (Row_RecStatus.getText().equalsIgnoreCase("Approved"))
			 {		
				 System.out.println("Tabledata-Record Status : "+Row_RecStatus.getText());
				 assertThat(Row_RecStatus.getText().equalsIgnoreCase("Approved")); 
			 }				 
		}
	}
	public void scrollIntoView(WebElement element){
		try {
			JavascriptExecutor executor = (JavascriptExecutor)driver;
			executor.executeScript("arguments[0].scrollIntoView(false);", element);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public List<String> getDataFromTable_Approved_DateTime() throws Exception
	 {
		List<String> Approved_DateTime = new ArrayList<String>();
		
		 try {
			DBConnection conn = new DBConnection();
			ResultSet resultSet = null;
			String ExecuteQuery = "select * from dbs_li_product order By Approved_Date_Time desc";
			resultSet = conn.readData(ExecuteQuery);
			Boolean nextRecAvailable =  resultSet.next();
			
			int count = 0;

	  		 while(nextRecAvailable || resultSet.next()){
	  			 nextRecAvailable = false;
	  			String TableData_Approved_DateTime = resultSet.getString("APPROVED_DATE_TIME").trim();
  				Approved_DateTime.add(TableData_Approved_DateTime);
  				nextRecAvailable =  resultSet.next();
	  		 }
	  		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		return Approved_DateTime;
	 }
	
	public List<String> getDataFromTable_Approved_DateTime_SpecifiedDates(String ApprovedDateFrom, String ApprovedDateTo) throws Exception
	 {
		List<String> Approved_DateTime = new ArrayList<String>();
		
		 try {
			DBConnection conn = new DBConnection();
			ResultSet resultSet = null;
			String ExecuteQuery = "select * from dbs_li_product where Approved_Date_Time Between '"+DateFormatForSpecifiedDates(ApprovedDateFrom)+"' And '"+DateFormatForSpecifiedDates(ApprovedDateTo)+"' order by Approved_Date_Time desc";
			resultSet = conn.readData(ExecuteQuery);
			Boolean nextRecAvailable =  resultSet.next();
			
			int count = 0;

	  		 while(nextRecAvailable || resultSet.next()){
	  			 nextRecAvailable = false;
	  			String TableData_Approved_DateTime = resultSet.getString("APPROVED_DATE_TIME").trim();
 				Approved_DateTime.add(TableData_Approved_DateTime);
 				nextRecAvailable =  resultSet.next();
	  		 }
	  		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		return Approved_DateTime;
	 }
	
	public void verifyRecordStatus_ApprovedPage() throws Exception {
		 Thread.sleep(3000);
		 cols_searchTable = tableSearchHeader;
		 rows_searchTable = tableSearchBody;
		 int RecCol;
		 
		 for ( RecCol=1;RecCol<=cols_searchTable.size(); RecCol++)
		 {
			 WebElement  tableHeader_RecStatuscolumn = driver.findElement(By.xpath("//table/thead/tr/th["+RecCol+"]"));
			 if (tableHeader_RecStatuscolumn.getText().equalsIgnoreCase("Record Status"))
			 {
				 //System.out.println("Record Status Col No: "+RecCol);
				 break;
			 }
		 }
		 if (tableSearchBodyText.getText() !="No records available.")
		 {	
			 int i = 0;
			 int Count = 0;
			 do{
				 if((i-1)== rows_searchTable.size())
				 {	
					 nextPageButton_enabled.click();
				 }			 
				 //System.out.println("RowCountinPage: " +tableSearchBody.size());
				 for(i=1; i<=rows_searchTable.size(); i++)
				 {	 
					 ++Count;	 	 
				 	 WebElement Row_RecStatus = driver.findElement(By.xpath("//table/tbody/tr["+i+"]/td["+RecCol+"]"));
				 	 if (Row_RecStatus.getText().equalsIgnoreCase("Approved"))
					 {		
						 //System.out.println("Table Record Status: "+Row_RecStatus.getText());
						 assertThat(Row_RecStatus.getText().equalsIgnoreCase("Approved")); 
					 }				 	 
				 }				 
				 
			} while(driver.findElements(By.xpath("//cst-pager-next-buttons/a[@class='cst-link cst-pager-nav']")).size()>0);

		 }else
		 {
			 System.out.println("By Default No records available in Approved Page.");
		 }
		 
	}
	public void verifyLastApprovedDateTimeByDefaultInDescending() throws Exception
	{
		 Thread.sleep(3000);
		 cols_searchTable = tableSearchHeader;
		 rows_searchTable = tableSearchBody;
		 
		 List<String> dateTimeTable  = getDataFromTable_Approved_DateTime();
		 System.out.println("DB Size:"+dateTimeTable.size());		 
		 
		 int Col;
		 //Get Last Approved Date/Time Column Index details
		 for ( Col=1;Col<=cols_searchTable.size(); Col++)
		 {
			 WebElement  tableSearchHeader_column = driver.findElement(By.xpath("//table/thead/tr/th[@aria-colindex='"+Col+"']"));
			 if (tableSearchHeader_column.getText().equals(""))
			 {	 
				 WebElement scroll_right = tableSearchHeader_column;
				 scrollIntoView(scroll_right);
			 }
			 WebElement  tableHeader_LastAppDateStatuscol = driver.findElement(By.xpath("//table/thead/tr/th["+Col+"]"));
			 if (tableHeader_LastAppDateStatuscol.getText().equalsIgnoreCase("Last Approved Date/Time"))
			 {
				 //System.out.println("Record Status Col No: "+RecCol);
				 break;
			 }
		 }
		 if (tableSearchBodyText.getText() !="No records available.")
		 {	
			 int i = 0;
			 int Count = 0;
			 do{
				 if((i)== rows_searchTable.size())
				 {	
					 nextPageButton_enabled.click();
				 }			 
				 //System.out.println("RowCount: " +tableSearchBody.size());
				 for(i=0; i<rows_searchTable.size(); i++)
				 {	 
					 ++Count;	 	 
				 	 WebElement Row_LastApprovedDateTime = driver.findElement(By.xpath("//table/tbody/tr["+(i+1)+"]/td["+Col+"]"));
				 	 if (DateFormat(Row_LastApprovedDateTime.getText()).equalsIgnoreCase(DateFormat(dateTimeTable.get(Count-1))))
					 {		
						 //System.out.println("Table Record Status: "+Row_RecStatus.getText());
						 assertThat(Row_LastApprovedDateTime.getText().equalsIgnoreCase(dateTimeTable.get(Count-1))); 
					 }				 	 
				 }				 
				 
			} while(driver.findElements(By.xpath("//cst-pager-next-buttons/a[@class='cst-link cst-pager-nav']")).size()>0);
	 
		 }else
		 {
			 System.out.println("By Default No records available in Approved Page.");
		 }		
	}
	
	public void verifyLastApprovedDateTimeForSpecifiedDates(String ApprovedDateFrom, String ApprovedDateTo ) throws Exception
	{
		 Thread.sleep(3000);
		 cols_searchTable = tableSearchHeader;
		 rows_searchTable = tableSearchBody;
		 
		 List<String> dateTimeTable  = getDataFromTable_Approved_DateTime_SpecifiedDates(ApprovedDateFrom, ApprovedDateTo );
		 System.out.println("DB Size:"+dateTimeTable.size());		 
		 
		 int Col;
		 //Get Last Approved Date/Time Column Index details
		 for ( Col=1;Col<=cols_searchTable.size(); Col++)
		 {
			 WebElement  tableSearchHeader_column = driver.findElement(By.xpath("//table/thead/tr/th[@aria-colindex='"+Col+"']"));
			 if (tableSearchHeader_column.getText().equals(""))
			 {	 
				 WebElement scroll_right = tableSearchHeader_column;
				 scrollIntoView(scroll_right);
			 }
			 WebElement  tableHeader_LastAppDateStatuscol = driver.findElement(By.xpath("//table/thead/tr/th["+Col+"]"));
			 if (tableHeader_LastAppDateStatuscol.getText().equalsIgnoreCase("Last Approved Date/Time"))
			 {
				 //System.out.println("Record Status Col No: "+RecCol);
				 break;
			 }
		 }
		 if (tableSearchBodyText.getText() !="No records available.")
		 {	
			 int i = 0;
			 int Count = 0;
			 do{
				 if((i)== rows_searchTable.size())
				 {	
					 nextPageButton_enabled.click();
				 }			 
				 //System.out.println("RowCount: " +tableSearchBody.size());
				 for(i=0; i<rows_searchTable.size(); i++)
				 {	 
					 ++Count;	 	 
				 	 WebElement Row_LastApprovedDateTime = driver.findElement(By.xpath("//table/tbody/tr["+(i+1)+"]/td["+Col+"]"));
				 	 //Compare DB data and AdminUI data
				 	 if (DateFormat(Row_LastApprovedDateTime.getText()).equalsIgnoreCase(DateFormat(dateTimeTable.get(Count-1))))
					 {		
						 //System.out.println("Table Record Status: "+Row_RecStatus.getText());
						 assertThat(Row_LastApprovedDateTime.getText().equalsIgnoreCase(dateTimeTable.get(Count-1))); 
					 }				 	 
				 }				 
				 
			} while(driver.findElements(By.xpath("//cst-pager-next-buttons/a[@class='cst-link cst-pager-nav']")).size()>0);
	 
		 }else
		 {
			 System.out.println("By Default No records available in Approved Page.");
		 }
		
	}
	
	public String DateFormat(String InputDate) {
		
			Date s = null;
			//SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyyHHmmss");
			if (InputDate.length()==19)
			{
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
				try {
					s = sdf.parse(InputDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else
			{
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				try {
					s = sdf.parse(InputDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}		
			SimpleDateFormat requiredSdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String requiredDate=requiredSdf.format(s);
			return requiredDate;
		}
	public String DateFormatForSpecifiedDates(String InputDate) {
		
		Date s = null;
		if (InputDate.length()==19)
		{
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyyyy");
			try {
				s = sdf.parse(InputDate);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		SimpleDateFormat requiredSdf=new SimpleDateFormat("yyyy-MM-dd");
		String requiredDate=requiredSdf.format(s);
		return requiredDate;
	}
}
