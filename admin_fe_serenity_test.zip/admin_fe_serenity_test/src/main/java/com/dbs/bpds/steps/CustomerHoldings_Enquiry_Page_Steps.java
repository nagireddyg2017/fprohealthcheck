package com.dbs.bpds.steps;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.*;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class CustomerHoldings_Enquiry_Page_Steps extends ScenarioSteps {
	
	WebDriver driver;	
	LandingPage landingPage;
	CustomerHoldingEnquiryPage custHoldEnquiryPage;
	PageObjectFactory pageObjectFactory;
	
	private static final long serialVersionUID = 1L;
		
	@Step
	public void verifyCustomerHoldingsModule_landingPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		landingPage = pageObjectFactory.getLandingPage();
		landingPage.clickOncustomerHoldingsModule();
		landingPage.verifyCustomerHoldingsPage();
	}
	
	@Step
	public void chkFillcriteriaStaticText() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.verifyStaticFillCriteriaText();
	}
	
	@Step
	public void resetCustomerHoldingsEnquiryPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.resetCustomerHoldingsEnquiryPage();
	}
	
	@Step
	public void verifySearchButtonDisabled() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.chkBtnSearchIsDiabled();
	}
	
	@Step
	public void verifySearchFiltersPresent() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.verifyExistingFiltersPresent();
	}
	
	@Step
	public void selectInsurerNameFromDropdown(String insurerName) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.selectInsurerName(insurerName);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void enterPolicyNumber(String policyNumber) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.enterPolicyNumber(policyNumber);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void enterAllInputValues(String inputParam,String inputParam1,String inputParam2,String inputParam3,String inputParam4,String inputParam5,String inputParam6,String inputParam7,String inputParam8,String inputParam9,String inputParam10,String inputParam11 ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.enterAllInputFieldValues(inputParam, inputParam1, inputParam2, inputParam3, inputParam4, inputParam5, inputParam6, inputParam7, inputParam8, inputParam9, inputParam10, inputParam11);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void verifyAllValuesFromSearchResults(String filterField, String inputParam,String inputParam1,String inputParam2,String inputParam3,String inputParam4,String inputParam5,String inputParam6,String inputParam7,String inputParam8,String inputParam9,String inputParam10,String inputParam11 ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.readingValuesFromSearchResultsTable(filterField,inputParam, inputParam1, inputParam2, inputParam3, inputParam4, inputParam5, inputParam6, inputParam7, inputParam8, inputParam9, inputParam10, inputParam11);
	}
	
	@Step
	public void verifySearchResultsAsPerSearchCriteria(String filterField, String inputParam) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.readingValuesFromSearchResultsTable(filterField, inputParam);
	}
	
	@Step
	public void verifySearchResultsAsPerSearchCriteria(String filterField, String inputParam, String inputParam1) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.readingValuesFromSearchResultsTable(filterField, inputParam,inputParam1);
	}
	
	@Step
	public void enterProductCode(String productCode ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.enterProductCode(productCode);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void enterInsurerComponentCode(String componentCode ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.enterInsurerComponentCode(componentCode);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void enterProductName(String productName ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.enterProductName(productName);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void selectPlanType(String planType ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.selectPlanType(planType);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void enterChannelRefNumber(String channelRefNumber ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.enterChannelRefNumber(channelRefNumber);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void enterDBSOwnerCIN(String dbsOwnerCIN ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.enterDBSOwnerCIN(dbsOwnerCIN);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void selectChannelID(String channelID ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.selectChannelID(channelID);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void enterPolicyCommencementDate(String policyCommencementDate ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.selectPolicyCommencementDate(policyCommencementDate);
		custHoldEnquiryPage.clickBtnSearch();
	}
	
	@Step
	public void enterInsurerRecordReceivedDateFrom(String insurerRecordReceivedDateFrom ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.selectInsurerRecordReceivedDateFrom(insurerRecordReceivedDateFrom);
	}
	
	@Step
	public void enterInsurerRecordReceivedDateTo(String insurerRecordReceivedDateTo ) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.selectInsurerRecordReceivedDateTo(insurerRecordReceivedDateTo);
	}
	
	@Step
	public void checkSearchButtonDisabled() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.chkBtnSearchIsDiabled();
	}
	
	@Step
	public void checkSearchButtonEnabled() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.chkBtnSearchIsEnabled();
	}
	
	@Step
	public void verifyFileDownloadedWithExpectedFileName(int recordNumber) throws IOException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.verifyPolicyDetailsFileisDownloaded(recordNumber);
	}
	
	@Step
	public void clickOnSearchButton() throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		custHoldEnquiryPage = pageObjectFactory.getCustomerHoldingEnquiryPage();
		custHoldEnquiryPage.clickBtnSearch();
	}
}
