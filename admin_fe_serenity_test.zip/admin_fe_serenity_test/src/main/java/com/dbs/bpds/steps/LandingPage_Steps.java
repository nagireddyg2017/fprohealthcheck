package com.dbs.bpds.steps;

import org.openqa.selenium.WebDriver;

import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.LandingPage;

import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class LandingPage_Steps extends ScenarioSteps {
	
	WebDriver driver;	
	LandingPage landingPage;
	PageObjectFactory pageObjectFactory;
	
	private static final long serialVersionUID = 1L;
	
	@Step
	public void verifyProductModule_landingPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		landingPage = pageObjectFactory.getLandingPage();
		landingPage.clickOnProductAdminModule();
		//landingPage.verifyPendingAcitonPage();
	}
	
	@Step
	public void verifyCustomerHoldingsModule_landingPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		landingPage = pageObjectFactory.getLandingPage();
		landingPage.clickOncustomerHoldingsModule();
		landingPage.verifyCustomerHoldingsPage();
	}
}