package com.dbs.bpds.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 
public class DBConnection {
 
    enum TestTableColumns{
        id,TEXT;
    }
 
    private final String jdbcDriverStr;
    private final String jdbcURL;
 
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    private static DBConnection mysqlInstance;
    
    public DBConnection(){
        this.jdbcDriverStr = "org.mariadb.jdbc.Driver";
        //this.jdbcURL = "jdbc:mariadb://10.91.138.100:6603/test?"
          //    + "user=bpds_db&password=Bpdsmariadb18@";
        /*this.jdbcURL = "jdbc:mariadb://10.91.138.3:6603/bpds?"
               + "user=bpds_db&password=Bpdsmariadb18@";*/
        this.jdbcURL = "jdbc:mariadb://10.91.138.100:6603/bpds?"
                + "user=bpds_db&password=Bpdsmariadb18@";
    }
    
    protected Connection SetUpConnection() throws SQLException, ClassNotFoundException {
		// Register JDBC driver (JDBC driver name and Database URL)
		Class.forName("com.mysql.jdbc.Driver");

		return connection = DriverManager.getConnection("jdbc:mysql://10.91.138.100:6603/bpds", "bpds_db", "Bpdsmariadb18@");

	}

	protected void CloseTheConnection() {
		// Code to close each and all Object related to Database connection
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (Exception e) {
			}
		}

		if (statement != null) {
			try {
				statement.close();
			} catch (Exception e) {
			}
		}

		if (connection != null) {
			try {
				connection.close();
			} catch (Exception e) {
			}
		}
	}

    public static DBConnection getInstance(){
    	if (mysqlInstance == null)
    		{
    			mysqlInstance = new DBConnection();
    		}
		return mysqlInstance;
    			
    }
    
    private Connection getConnection() {
    	
    	try{
    		if (connection != null) return connection;
	       	Class.forName(jdbcDriverStr);
	        connection = DriverManager.getConnection(jdbcURL);
	       
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return connection;
    }
    
    
    public ResultSet readData(String ExecuteQuery) throws Exception{
    	//System.out.println("ExecuteQuery: " + ExecuteQuery);
    	Class.forName("com.mysql.jdbc.Driver");
        connection = SetUpConnection();
        statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(ExecuteQuery);
        return resultSet;
    }
    public void close(){
        try {
           // if(resultSet!=null) resultSet.close();
            if(statement!=null) statement.close();
            if(connection!=null) connection.close();
        } catch(Exception e){}
    }
}