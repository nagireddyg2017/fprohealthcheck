package com.dbs.bpds.helper;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import com.dbs.bpds.excelutility.ExcelHelperReports;

public class InvalidCINExceptionReportHelper extends AbstractCinExceptionChangeReport{
	
	private static String reportFileName = "invalidCinFileName";

	@Override
	public void OperationMethodInsurerName() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"A.POLICY_NO, A.INSURER_CODE,A.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN, \n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.POLICY_OWNER_DOB, B.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY,A.POLICY_OWNER_MOBILE_NO,A.POLICY_OWNER_EMAILADDRESS,A.POLICY_OWNER_RES_POSTCODE,\n" +
                    "case A.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "A.PRODUCT_CODE,A.COMPONENT_CODE,A.PRODUCT_NAME, A.RECORD_DATE_TIMESTAMP, A.CHANNEL_ID, A.CHANNEL_REFERENCE_NO\n" +
                    "from bpds.dbs_li_cin_exception A, bpds.dbs_li_nationality B \n" +
                    "where A.POLICY_OWNER_NATIONALITY = B.MLS_COUNTRY_CODE and A.INSURER_CODE = '005';");
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);

            // Count of Matched Column


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                   // assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

         
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodProductName() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"A.POLICY_NO, A.INSURER_CODE,A.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN, \n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.POLICY_OWNER_DOB, B.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY,A.POLICY_OWNER_MOBILE_NO,A.POLICY_OWNER_EMAILADDRESS,A.POLICY_OWNER_RES_POSTCODE,\n" +
                    "case A.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "A.PRODUCT_CODE,A.COMPONENT_CODE,A.PRODUCT_NAME, A.RECORD_DATE_TIMESTAMP, A.CHANNEL_ID, A.CHANNEL_REFERENCE_NO\n" +
                    "from bpds.dbs_li_cin_exception A, bpds.dbs_li_nationality B \n" +
                    "where A.POLICY_OWNER_NATIONALITY = B.MLS_COUNTRY_CODE and A.product_name = 'LOSS OF INDEPENDENCE (LOI) INCOME BENEFIT';");
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);

            // Count of Matched Column


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodInsurerOwnerCIN() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"A.POLICY_NO, A.INSURER_CODE,A.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN, \n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.POLICY_OWNER_DOB, B.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY,A.POLICY_OWNER_MOBILE_NO,A.POLICY_OWNER_EMAILADDRESS,A.POLICY_OWNER_RES_POSTCODE,\n" +
                    "case A.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "A.PRODUCT_CODE,A.COMPONENT_CODE,A.PRODUCT_NAME, A.RECORD_DATE_TIMESTAMP, A.CHANNEL_ID, A.CHANNEL_REFERENCE_NO\n" +
                    "from bpds.dbs_li_cin_exception A, bpds.dbs_li_nationality B \n" +
                    "where A.POLICY_OWNER_NATIONALITY = B.MLS_COUNTRY_CODE and A.policy_owner_cin = '9123456A';");
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);



            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodInsurerOwnerName() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"A.POLICY_NO, A.INSURER_CODE,A.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN, \n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.POLICY_OWNER_DOB, B.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY,A.POLICY_OWNER_MOBILE_NO,A.POLICY_OWNER_EMAILADDRESS,A.POLICY_OWNER_RES_POSTCODE,\n" +
                    "case A.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "A.PRODUCT_CODE,A.COMPONENT_CODE,A.PRODUCT_NAME, A.RECORD_DATE_TIMESTAMP, A.CHANNEL_ID, A.CHANNEL_REFERENCE_NO\n" +
                    "from bpds.dbs_li_cin_exception A, bpds.dbs_li_nationality B \n" +
                    "where A.POLICY_OWNER_NATIONALITY = B.MLS_COUNTRY_CODE and A.policy_owner_name = 'Oww Vvswovsq';");
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodChannelID() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"A.POLICY_NO, A.INSURER_CODE,A.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN, \n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.POLICY_OWNER_DOB, B.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY,A.POLICY_OWNER_MOBILE_NO,A.POLICY_OWNER_EMAILADDRESS,A.POLICY_OWNER_RES_POSTCODE,\n" +
                    "case A.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "A.PRODUCT_CODE,A.COMPONENT_CODE,A.PRODUCT_NAME, A.RECORD_DATE_TIMESTAMP, A.CHANNEL_ID, A.CHANNEL_REFERENCE_NO\n" +
                    "from bpds.dbs_li_cin_exception A, bpds.dbs_li_nationality B \n" +
                    "where A.POLICY_OWNER_NATIONALITY = B.MLS_COUNTRY_CODE and A.channel_id ='IBSG';");
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodInsurerRecordDate() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"A.POLICY_NO, A.INSURER_CODE,A.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN, \n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.POLICY_OWNER_DOB, B.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY,A.POLICY_OWNER_MOBILE_NO,A.POLICY_OWNER_EMAILADDRESS,A.POLICY_OWNER_RES_POSTCODE,\n" +
                    "case A.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "A.PRODUCT_CODE,A.COMPONENT_CODE,A.PRODUCT_NAME, A.RECORD_DATE_TIMESTAMP, A.CHANNEL_ID, A.CHANNEL_REFERENCE_NO\n" +
                    "from bpds.dbs_li_cin_exception A, bpds.dbs_li_nationality B \n" +
                    "where A.POLICY_OWNER_NATIONALITY = B.MLS_COUNTRY_CODE and A.record_date_timestamp between  '2018-09-20 00:00:00' and '2018-09-28 23:59:59';");
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}
	
	@Override
	public void OperationMethodAllValidInputOnFilters() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery(
            		"select case B.MAINTENANCE_INDICATOR\n" +
                            "\t\t\twhen '01' then 'Create'\n" +
                            "\t\t\twhen '02' then 'Update'\n" +
                            "\t\t\tend as MAINTENANCE_INDICATOR,\n" +
            		"A.POLICY_NO, A.INSURER_CODE,A.INSURER_NAME,A.POLICY_OWNER_CIN_PREFIX,A.POLICY_OWNER_CIN, \n" +
                    "A.POLICY_OWNER_CIN_SUFFIX, A.POLICY_OWNER_NAME, A.POLICY_OWNER_DOB, B.CIS_DESCRIPTION AS POLICY_OWNER_NATIONALITY,A.POLICY_OWNER_MOBILE_NO,A.POLICY_OWNER_EMAILADDRESS,A.POLICY_OWNER_RES_POSTCODE,\n" +
                    "case A.PLAN_TYPE\n" +
                    "\twhen '00' then 'Basic'\n" +
                    "\twhen '01' then 'Rider'\n" +
                    "\twhen '02' then 'Subfund'\n" +
                    "\tend as PLAN_TYPE,\n" +
                    "A.PRODUCT_CODE,A.COMPONENT_CODE,A.PRODUCT_NAME, A.RECORD_DATE_TIMESTAMP, A.CHANNEL_ID, A.CHANNEL_REFERENCE_NO\n" +
                    "from bpds.dbs_li_cin_exception A, bpds.dbs_li_nationality B \n" +
                    "where A.POLICY_OWNER_NATIONALITY = B.MLS_COUNTRY_CODE and A.INSURER_CODE = '005' and A.product_name = 'MANULIFE INCOMEGUARD' and A.policy_owner_cin = '6437325J' and A.policy_owner_name = 'Kqsjx  Vxowwksxk Qokwttqkw' and A.channel_id ='IBSG' and A.record_date_timestamp between  '2018-09-20 00:00:00' and '2018-09-28 23:59:59';");
            
            // Get the all row of Excel Table

            HashMap<String, ArrayList<String>> extractedExcelReportsRow = ExcelHelperReports.excelReports(reportFileName);
            System.out.println("Print Excel Data reports here");
            System.out.println(extractedExcelReportsRow);


            // Count of Matched Row
            int matchRowCount = 0;

            System.out.println("Excel Row Count => " + extractedExcelReportsRow.size());

            int columnCount = resultSet.getMetaData().getColumnCount();
            System.out.println("DB column count================>"+columnCount);
            
            while(resultSet.next()){

                String policyNo = resultSet.getString("POLICY_NO");
                ArrayList<String> excelRow = extractedExcelReportsRow.get(policyNo);

                if(excelRow == null){
                    //assertTrue(true, "excel record not found, id = "+policyNo);
                    //assertThat(excelRow.isEmpty());
                    return;
                }

                int matchColumnCount = 0;
                for(int i=0;i<columnCount;i++){
                    System.out.println("UI Cell Data => " + excelRow.get(i));
                    String gridValue = Objects.toString(resultSet.getString(i + 1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(i + 1);
                    System.out.println("DB Cell Data => " + gridValue);
                    if(excelRow.get(i).equalsIgnoreCase(gridValue)){
                        matchColumnCount++;
                    }
                }

                if (matchColumnCount == excelRow.size()) {
                    System.out.println("==============================ROW MATCHED=====================================");
                    matchRowCount++;
                }
            }

           //assertEquals(matchRowCount, extractedExcelReportsRow.size(), "UI Table is not the exact copy of Database Table");
            assertThat(matchRowCount).isEqualTo(extractedExcelReportsRow.size());
        
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void OperationMethodDBSOwnerCIN() {
		// TODO Auto-generated method stub
		
	}


}
