package com.dbs.bpds.helper;

import java.sql.*;

public abstract class AbstractCinExceptionChangeReport {

	// Object of Connection from the Database
		Connection conn = null;

		// Object of Statement. It is used to create a Statement to execute the
		// query
		Statement stmt = null;

		// Object of ResultSet => 'It maintains a cursor that points to the current
		// row in the result set'
		ResultSet resultSet = null;

		public abstract void OperationMethodInsurerName();

		public abstract void OperationMethodProductName();

		public abstract void OperationMethodInsurerOwnerCIN();

		public abstract void OperationMethodInsurerOwnerName();

		public abstract void OperationMethodDBSOwnerCIN();

		public abstract void OperationMethodChannelID();

		public abstract void OperationMethodInsurerRecordDate();
		
		public abstract void OperationMethodAllValidInputOnFilters();

		public final void cinUpdateReport(String reportFilter) throws SQLException, ClassNotFoundException {
			SetUpConnection();

			String cinChangereportFilter = reportFilter;

			switch (cinChangereportFilter) {
			case "InsurerName":
				OperationMethodInsurerName();
				break;
			case "ProductName":
				OperationMethodProductName();
				break;
			case "InsurerOwnerCIN":
				OperationMethodInsurerOwnerCIN();
				break;
			case "InsurerOwnerName":
				OperationMethodInsurerOwnerName();
				break;
			case "DBSOwnerCIN":
				OperationMethodDBSOwnerCIN();
				break;
			case "ChannelID":
				OperationMethodChannelID();
				break;
			case "InsurerRecordDate":
				OperationMethodInsurerRecordDate();
				break;
			case "AllValidInput":
				OperationMethodAllValidInputOnFilters();
				break;
			default:
				System.out.println("Invalid Filter criteria");
				break;
			}

			CloseTheConnection();

		}

		public final void invalidCINExceptionReport(String reportFilter) throws SQLException, ClassNotFoundException {
			SetUpConnection();

			String invalidCinreportFilter = reportFilter;

			switch (invalidCinreportFilter) {
			case "InsurerName":
				OperationMethodInsurerName();
				break;
			case "ProductName":
				OperationMethodProductName();
				break;
			case "InsurerOwnerCIN":
				OperationMethodInsurerOwnerCIN();
				break;
			case "InsurerOwnerName":
				OperationMethodInsurerOwnerName();
				break;
			case "ChannelID":
				OperationMethodChannelID();
				break;
			case "InsurerRecordDate":
				OperationMethodInsurerRecordDate();
				break;
			case "AllValidInput":
				OperationMethodAllValidInputOnFilters();
				break;
			default:
				System.out.println("Invalid Filter criteria");
				break;
			}

			CloseTheConnection();

		}

		private void SetUpConnection() throws SQLException, ClassNotFoundException {
			// Register JDBC driver (JDBC driver name and Database URL)
			Class.forName("com.mysql.jdbc.Driver");

			// Open a connection
			conn = DriverManager.getConnection("jdbc:mysql://10.91.138.100:6603/bpds", "bpds_db", "Bpdsmariadb18@");

		}

		private void CloseTheConnection() {
			// Code to close each and all Object related to Database connection
			if (resultSet != null) {
				try {
					resultSet.close();
				} catch (Exception e) {
				}
			}

			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
				}
			}

			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
				}
			}
		}

	}
