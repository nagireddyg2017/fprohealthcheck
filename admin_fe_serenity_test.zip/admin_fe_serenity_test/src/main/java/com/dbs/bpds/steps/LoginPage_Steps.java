package com.dbs.bpds.steps;

import org.openqa.selenium.WebDriver;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.LandingPage;
import com.dbs.bpds.pages.LoginPage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

public class LoginPage_Steps extends ScenarioSteps {
	
	LoginPage loginPage;
	LandingPage landingPage;
	public String actual_message;
	WebDriver driver;
	PageObjectFactory pageObjectFactory;
	
	private static final long serialVersionUID = 1L;
	
	
	@Step
	public void launchApplication() throws Exception {
	
		Utils.selectBrowser(Constants.DRIVER);
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		loginPage = pageObjectFactory.getLoginPage();
		loginPage.launchApplication();
	}
	
	@Step
	public void login(String username, String password) throws Exception {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		loginPage = pageObjectFactory.getLoginPage();
		loginPage.userName(username);
		loginPage.password(password);
		loginPage.loginBtn();
	}
	
	@Step
	public void verifyLandingPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		loginPage = pageObjectFactory.getLoginPage();
		loginPage.verifyUserNameInHomePage();
	}
	
	@Step
	public void logOutFromApplication() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		landingPage = pageObjectFactory.getLandingPage();
		landingPage.logoutFromApplication();
	}
	
	@Step
	public void closeApplication() {
		Utils.driver.quit();
	}
	
	@Step
	public String getErrorMessageText() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		loginPage = pageObjectFactory.getLoginPage();
		actual_message = loginPage.errorMessageText();
		return actual_message;
	}
}

