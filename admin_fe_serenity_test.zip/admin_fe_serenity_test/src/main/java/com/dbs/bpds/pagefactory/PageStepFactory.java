package com.dbs.bpds.pagefactory;

import com.dbs.bpds.steps.CinChangeUpdateReportPage_Steps;
import com.dbs.bpds.steps.CisProductUpdateReport_Steps;
import com.dbs.bpds.steps.InvalidCinExceptionReportPage_Step;
import com.dbs.bpds.steps.LandingPage_Steps;
import com.dbs.bpds.steps.LoginPage_Steps;
import com.dbs.bpds.steps.ProductApprovedPage_Steps;
import com.dbs.bpds.steps.ProductAuditTrailReportPage_Steps;
import com.dbs.bpds.steps.ProductCancelledPage_Steps;
import com.dbs.bpds.steps.ProductGroupExceptionReportPage_Steps;
import com.dbs.bpds.steps.CustomerHoldings_Enquiry_Page_Steps;

public class PageStepFactory {
	
	private static PageStepFactory pageStepFactory = new PageStepFactory();
	private static LoginPage_Steps loginPageSteps;
	private static LandingPage_Steps landingPageSteps;
	private static InvalidCinExceptionReportPage_Step invalidCinExceptionReportPage_Steps;
	private static CinChangeUpdateReportPage_Steps cinChangeUpdateReportPage_Steps;
	private static CisProductUpdateReport_Steps cisProductUpdateReport_Steps;
	private static ProductGroupExceptionReportPage_Steps prdtGroupExecutionReportPage_Steps;
	private static ProductAuditTrailReportPage_Steps productAuditTrailReportPage_Steps;
	private static CustomerHoldings_Enquiry_Page_Steps customerHoldingEnquiryPage_Steps;
	private static ProductApprovedPage_Steps productApprovedPage_Steps;
	private static ProductCancelledPage_Steps productCancelledPage_Steps;

	
	private PageStepFactory() {
	}
	
	 public static PageStepFactory getInstance( ) {
	      return pageStepFactory;
	 }
	
	public LoginPage_Steps getLoginPageSteps(){
		return (loginPageSteps == null) ? new LoginPage_Steps() : loginPageSteps;
	}
	
	public LandingPage_Steps getLandingPageSteps(){
		return (landingPageSteps == null) ? new LandingPage_Steps() : landingPageSteps;
	}
	
	public InvalidCinExceptionReportPage_Step getInvalidCinExceptionReportPage() {
		return (invalidCinExceptionReportPage_Steps == null) ? new InvalidCinExceptionReportPage_Step() : invalidCinExceptionReportPage_Steps;		
	}
	
	public CinChangeUpdateReportPage_Steps getCINChangeUpdateReportsPage() {
		return (cinChangeUpdateReportPage_Steps == null) ? new CinChangeUpdateReportPage_Steps() : cinChangeUpdateReportPage_Steps;		
	}
	
	public CisProductUpdateReport_Steps getCisProductUpdateReportSteps(){
		return (cisProductUpdateReport_Steps == null) ? new CisProductUpdateReport_Steps() : cisProductUpdateReport_Steps;
	}
	
	public ProductGroupExceptionReportPage_Steps getPrdtGroupExceptionReportSteps(){
		return (prdtGroupExecutionReportPage_Steps == null) ? new ProductGroupExceptionReportPage_Steps() : prdtGroupExecutionReportPage_Steps;
	}
	

	public ProductAuditTrailReportPage_Steps getProductAuditTrailReportPage_Steps(){
		return (productAuditTrailReportPage_Steps == null) ? new ProductAuditTrailReportPage_Steps() : productAuditTrailReportPage_Steps;
	}

	public CustomerHoldings_Enquiry_Page_Steps getCusotmerHoldingEnquiryPage() {
		return (customerHoldingEnquiryPage_Steps == null) ? new CustomerHoldings_Enquiry_Page_Steps() : customerHoldingEnquiryPage_Steps;		

	}

	public ProductApprovedPage_Steps getProductApprovedPage() {		
		return (productApprovedPage_Steps == null) ? new ProductApprovedPage_Steps() : productApprovedPage_Steps;

	}
	
	public ProductCancelledPage_Steps getProductCancelledPage() {
		return (productCancelledPage_Steps == null) ? new ProductCancelledPage_Steps() : productCancelledPage_Steps;

	}

}