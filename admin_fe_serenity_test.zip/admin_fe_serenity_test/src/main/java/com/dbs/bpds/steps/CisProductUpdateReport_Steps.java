package com.dbs.bpds.steps;

import java.sql.SQLException;

import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.CisProductUpdateExceptionReportPage;

import net.thucydides.core.annotations.Step;

public class CisProductUpdateReport_Steps {
	
	CisProductUpdateExceptionReportPage cisProductUpdateExceptionReportPage;
	PageObjectFactory pageObjectFactory;
	
	@Step
	public void launchCisPrdtUpdateReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.clkCusHoldReports();
		cisProductUpdateExceptionReportPage.clkCisPrdtUpdateReport();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateReport();
	}
	
	@Step
	public void chkFillcriteriaStaticText() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyStaticFillCriteriaText();
	}
	
	@Step
	public void resetCisPrdtUpdateReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateReport();
	}
	
	@Step
	public void chkExportBtnISDisabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.chkBtnExportIsDiabled();
	}
	
	@Step
	public void selectCisPrdtUpdateReportInsurerName() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.selectInsurerName();
	}
	
	@Step
	public void chkExportBtnISEnabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.chkBtnExportIsEnabled();
	}
	
	@Step
	public void verifyNoRecordFound(){
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyNoRecordErrorBanner();
	}
	
	@Step
	public void clickExportButtonReports() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.clickBtnExport();		
	}
	
	@Step
	public void verifyDownloadCisPrdtUpdateReportFilename() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateFileisDownloaded();
	}
	
	@Step
	public void enterCisPrdtUpdateReportProductCode(String productCode) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.enterProductCode(productCode);		
	}
	
	@Step
	public void enterCisPrdtUpdateReportInsurerComponentCode(String insurerComponentCode) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.enterInsurerComponentCode(insurerComponentCode);		
	}
	
	@Step
	public void enterCisPrdtUpdateReportProductName(String productName) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.enterProductName(productName);		
	}
	
	@Step
	public void enterCisPrdtUpdateReportChannelId() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.selectChannelID();		
	}
	
	@Step
	public void enterCisPrdtUpdateReportInsurerRecordDate(String insurerRecordReceivedDateFrom, String insurerRecordReceivedDateTo){
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.selectInsurerDateFrom(insurerRecordReceivedDateFrom);
		cisProductUpdateExceptionReportPage.selectInsurerDateTo(insurerRecordReceivedDateTo);
	}
	
	@Step
	public void validateExcelDBCisPrdtUpdateReportInsurerName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateDBTestInsurerName();
	}
	
	@Step
	public void validateExcelDBCisPrdtUpdateReportProductCode() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateDBTestProductCode();
	}
	
	@Step
	public void validateExcelDBCisPrdtUpdateReportInsurerComponentCode() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateDBTestInsurerComponentCode();
	}
	
	@Step
	public void validateExcelDBCisPrdtUpdateReportProductName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateDBTestInsurerProductName();
	}
	
	@Step
	public void validateExcelDBCisPrdtUpdateReportChannelId() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateDBTestChannelId();
	}
	
	@Step
	public void validateExcelDBCisPrdtUpdateReportInsurerRecordDate() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateDBTestInsurerRecordDate();
	}
	
	@Step
	public void validateExcelDBCisPrdtUpdateReportAllValidInput() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		cisProductUpdateExceptionReportPage = pageObjectFactory.getCisProductExceptionReportPage();
		cisProductUpdateExceptionReportPage.verifyCisPrdtUpdateDBTestAllValidInput();
	}	

}

