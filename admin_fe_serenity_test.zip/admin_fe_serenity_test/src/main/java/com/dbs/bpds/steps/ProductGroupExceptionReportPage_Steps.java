package com.dbs.bpds.steps;

import java.sql.SQLException;

import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.pagefactory.PageObjectFactory;
import com.dbs.bpds.pages.ProductGroupingExceptionReportPage;

import net.thucydides.core.annotations.Step;


public class ProductGroupExceptionReportPage_Steps {
	
	ProductGroupingExceptionReportPage prdtGroupExceptionReportPage;
	PageObjectFactory pageObjectFactory;
	
	@Step
	public void launchPrdtGroupExceptionReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.clkCusHoldReports();
		prdtGroupExceptionReportPage.clkPrdtGroupingExceptionReport();
		prdtGroupExceptionReportPage.verifyPrdtGroupingExceptionReport();
	}
	
	@Step
	public void chkFillcriteriaStaticText() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyStaticFillCriteriaText();
	}
	
	@Step
	public void resetPrdtGroupExceptionReportPage() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyPrdtGroupingExceptionReport();
	}
	
	@Step
	public void chkExportBtnISDisabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.chkBtnExportIsDiabled();
	}
	
	@Step
	public void selectPrdtGroupExceptionReportInsurerName() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.selectInsurerName();
	}
	
	@Step
	public void chkExportBtnISEnabled() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.chkBtnExportIsEnabled();
	}
	
	@Step
	public void verifyNoRecordFound(){
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyNoRecordErrorBanner();
	}
	
	@Step
	public void clickExportButtonReports() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.clickBtnExport();		
	}
	
	@Step
	public void verifyDownloadPrdtGroupExceptionReportFilename() {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyPrdtGroupingFileisDownloaded();
	}
	
	@Step
	public void enterPrdtGroupExceptionReportProductCode(String productCode) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.enterProductCode(productCode);		
	}
	
	@Step
	public void enterPrdtGroupExceptionReportInsurerComponentCode(String insurerComponentCode) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.enterInsurerComponentCode(insurerComponentCode);		
	}
	
	@Step
	public void enterPrdtGroupExceptionReportProductName(String productName) {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.enterProductName(productName);		
	}
	
	@Step
	public void enterPrdtGroupExceptionReportChannelId() throws InterruptedException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.selectChannelID();		
	}
	
	@Step
	public void enterPrdtGroupExceptionReportInsurerRecordDate(String insurerRecordReceivedDateFrom, String insurerRecordReceivedDateTo){
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.selectInsurerDateFrom(insurerRecordReceivedDateFrom);
		prdtGroupExceptionReportPage.selectInsurerDateTo(insurerRecordReceivedDateTo);
	}
	
	@Step
	public void validateExcelDBPrdtGroupExceptionReportInsurerName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyPrdtGroupingDBTestInsurerName();
	}
	
	@Step
	public void validateExcelDBPrdtGroupExceptionReportProductCode() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyPrdtGroupingDBTestProductCode();
	}
	
	@Step
	public void validateExcelDBPrdtGroupExceptionReportInsurerComponentCode() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyPrdtGroupingDBTestInsurerComponentCode();
	}
	
	@Step
	public void validateExcelDBPrdtGroupExceptionReportProductName() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyPrdtGroupingDBTestInsurerProductName();
	}
	
	@Step
	public void validateExcelDBPrdtGroupExceptionReportChannelId() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyPrdtGroupingDBTestChannelId();
	}
	@Step
	public void validateExcelDBPrdtGroupExceptionReportInsurerRecordDate() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyPrdtGroupingDBTestInsurerRecordDate();
	}
	@Step
	public void validateExcelDBPrdtGroupExceptionReportAllValidInput() throws ClassNotFoundException, SQLException {
		pageObjectFactory = new PageObjectFactory(Utils.driver);
		prdtGroupExceptionReportPage = pageObjectFactory.getProductGroupingExceptionReportPage();
		prdtGroupExceptionReportPage.verifyPrdtGroupingDBTestAllValidInput();
	}
}

