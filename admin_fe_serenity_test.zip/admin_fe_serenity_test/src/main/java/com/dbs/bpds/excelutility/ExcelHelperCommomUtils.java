package com.dbs.bpds.excelutility;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExcelHelperCommomUtils {
	
	public static List<ArrayList<String>> excelReports(String reportFileName){
		
		String currentExcelReportName = null;
        if (reportFileName == "ProductAuditTrialReport")
        	currentExcelReportName = Utils.getPrdtAuditTrailReportFileNameCurrentDate();

        List<ArrayList<String>> excelDataList = new ArrayList();


        try {
            FileInputStream excelFile = new FileInputStream(new File(Constants.DOWNLOAD_REPORT_PATH+currentExcelReportName));
            Workbook workBookExcel = new XSSFWorkbook(excelFile);
            Sheet dataTypeSheet = workBookExcel.getSheetAt(0);

            int maxRowIndex = dataTypeSheet.getLastRowNum();
            int maxCellIndex = 0;
            for(int i=0; i< maxRowIndex+1;i++){
                Row currentRow = dataTypeSheet.getRow(i);

                if(maxCellIndex == 0){
                    maxCellIndex = currentRow.getLastCellNum();
                }

                ArrayList<String> columnList = new ArrayList();
                for(int j=0; j< maxCellIndex;j++){
                    if(currentRow.getCell(j) != null){
                        columnList.add(currentRow.getCell(j).getStringCellValue());
                    }else{
                        columnList.add("");
                    }
                }
                excelDataList.add(columnList);
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e){
            e.printStackTrace();
        }

        excelDataList.remove(0);



        return excelDataList;
    }
}