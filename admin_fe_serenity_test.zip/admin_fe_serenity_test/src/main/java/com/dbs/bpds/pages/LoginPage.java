package com.dbs.bpds.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;
import static org.assertj.core.api.Assertions.*;

public class LoginPage {
	
	WebDriver driver;
	
	public LoginPage (WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	

    @FindBy(xpath="//div/input[1][@type='text']")                           
	WebElement userName;
     
    @FindBy(xpath="//div/input[1][@type='password']")
    WebElement passWord;
    
    @FindBy(how = How.CSS, using = ".btn-primary")
    WebElement loginButton;
    
    @FindBy(how = How.CSS, using = ".mdi-account")
    WebElement userName_title;
    
    @FindBy(xpath="//div[2]/p")
    WebElement error_message;
        
    public void launchApplication() 
    {
		driver.get(Constants.DEFAULT_URL);
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(userName));
	}
    
	public void userName(String username) throws Exception 
	{	
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(userName));
		userName.clear();
		userName.click();
		userName.sendKeys(username);
	}

	public void password(String password) throws Exception 
	{
		passWord.clear();
		passWord.click();
		passWord.sendKeys(password);    		
	}
	
	public void loginBtn() throws Exception 
	{
		loginButton.click();
	}
	
	public void verifyUserNameInHomePage()  
	{	
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(userName_title));
		assertThat(userName_title.getText().contains(Constants.USERNAME));		
	}
	
	public String errorMessageText()
	{	
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(error_message));
		return Utils.getErrorMessageText(error_message);
	}
}
