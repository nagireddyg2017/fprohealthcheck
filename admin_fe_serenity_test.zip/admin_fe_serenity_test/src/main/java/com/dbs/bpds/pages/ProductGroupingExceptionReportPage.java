package com.dbs.bpds.pages;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.helper.AbstractCustomerProductReport;
import com.dbs.bpds.helper.ProductGroupingExceptionReportHelper;

public class ProductGroupingExceptionReportPage {
	
	WebDriver driver;
	private static String reportFilter = null;
	
	private AbstractCustomerProductReport abstractCustomerProductReports = new ProductGroupingExceptionReportHelper();
	
	public ProductGroupingExceptionReportPage(WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.LINK_TEXT, using = "Cust Holding Reports")
	WebElement customerHoldingReports;
	
	@FindBy(how = How.LINK_TEXT, using = "Product Grouping Exception Report")
	WebElement prdtGroupingExceptionReport;
	
	@FindBy(how = How.XPATH, using = "//h4[contains(text(),'Product Grouping Exception Report')]")
	WebElement labelPrdtGroupExceptionReport;
	
	@FindBy(how = How.CSS, using = ".text-danger")
	WebElement txtFillCriteria;
	
	@FindBy(how = How.XPATH, using = "//button[@type='submit']")
	WebElement btnExport;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerName'] .cst-i-arrow-s")
	WebElement dropDownInsurerName;
	
	@FindBy(how = How.CSS, using = "cst-list [role] [role='option']:nth-of-type(2)")
	WebElement selectInsurerName;
	
	@FindBy(how = How.XPATH, using ="//div/input[1][@formcontrolname='productCode']")
	WebElement enterProductCode;
	
	@FindBy(how = How.XPATH, using ="//div/input[1][@formcontrolname='insurerComponentCode']")
	WebElement enterInsurerComponentCode;
	
	@FindBy(how = How.XPATH, using ="//div/input[1][@formcontrolname='productName']")
	WebElement enterProductName;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='channelId'] .cst-i-arrow-s")
	WebElement clickChannelID;
	
	@FindBy(how = How.CSS, using = "cst-list [role] [role='option']:nth-of-type(6)")
	WebElement selectChannelId;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerRecordDateFrom'] .cst-input")
	WebElement clickInsurerRecordDateFrom;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerRecordDateTo'] .cst-input")
	WebElement clickInsurerRecordDateTo;
	
	@FindBy(how = How.CSS, using = ".cst-toaster-main__title--warn")
	WebElement noRecordFoundwarningMsg;
	
	public void clkCusHoldReports() {
		customerHoldingReports.click();
	}
	
	public void clkPrdtGroupingExceptionReport() {
		prdtGroupingExceptionReport.click();
	}
	
	public void verifyPrdtGroupingExceptionReport(){
		assertThat(labelPrdtGroupExceptionReport.getText().equalsIgnoreCase("Product Grouping Exception Report"));
	}
	
	public void verifyStaticFillCriteriaText() {
		assertThat(txtFillCriteria.getText().equalsIgnoreCase("Please fill in at least 1 criteria to proceed"));		
	}
	
	public void chkBtnExportIsDiabled() {
		assertThat(!btnExport.isEnabled());
	}
	
	public void selectInsurerName() {
		dropDownInsurerName.click();
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(selectInsurerName));
		selectInsurerName.click();		
	}
	
	public void chkBtnExportIsEnabled() {
		assertThat(btnExport.isEnabled());
	}
	
	public void clickBtnExport() throws InterruptedException {
		btnExport.click();
		Thread.sleep(3000);
	}
	
	public void verifyNoRecordErrorBanner(){
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(noRecordFoundwarningMsg));
		assertThat(noRecordFoundwarningMsg.getText().contains("No Records Found"));
	}
	
	public void verifyPrdtGroupingFileisDownloaded(){
        File xFile = new File(Constants.DOWNLOAD_REPORT_PATH, Utils.getPrdtGroupingExceptionReportFileNameCurrentDate());
        assertThat(xFile).exists().hasName(Utils.getPrdtGroupingExceptionReportFileNameCurrentDate()).hasExtension("xlsx");
        
    }
	
	public void enterProductCode(String productCode){		 
		 enterProductCode.clear();
		 enterProductCode.click();
		 enterProductCode.sendKeys(productCode);		 
	 }
	
	public void enterInsurerComponentCode(String insurerComponentCode){		 
		enterInsurerComponentCode.clear();
		enterInsurerComponentCode.click();
		enterInsurerComponentCode.sendKeys(insurerComponentCode);		 
	 }
	
	public void enterProductName(String productName){		 
		 enterProductName.clear();
		 enterProductName.click();
		 enterProductName.sendKeys(productName);		 
	 }
	
	public void selectChannelID() throws InterruptedException {
		 clickChannelID.click();
		 Thread.sleep(3000);
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(selectChannelId));
		 selectChannelId.click();		 
	 }
	
	public void selectInsurerDateFrom(String insurerRecordReceivedDateFrom) {
		 clickInsurerRecordDateFrom.clear();
		 clickInsurerRecordDateFrom.click();
		 clickInsurerRecordDateFrom.sendKeys(insurerRecordReceivedDateFrom);		 
	 }
	 
	 public void selectInsurerDateTo(String insurerRecordReceivedDateTo) {
		 clickInsurerRecordDateTo.clear();
		 clickInsurerRecordDateTo.click();
		 clickInsurerRecordDateTo.sendKeys(insurerRecordReceivedDateTo);		 
	 }
	 
	 public void verifyPrdtGroupingDBTestInsurerName() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerName";
	        abstractCustomerProductReports.prdtGroupingExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 
	 public void verifyPrdtGroupingDBTestProductCode() throws ClassNotFoundException, SQLException {
	        reportFilter = "ProductCode";
	        abstractCustomerProductReports.prdtGroupingExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 
	 public void verifyPrdtGroupingDBTestInsurerComponentCode() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerComponentCode";
	        abstractCustomerProductReports.prdtGroupingExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 
	 public void verifyPrdtGroupingDBTestInsurerProductName() throws ClassNotFoundException, SQLException {
	        reportFilter = "ProductName";
	        abstractCustomerProductReports.prdtGroupingExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 
	 public void verifyPrdtGroupingDBTestChannelId() throws ClassNotFoundException, SQLException {
	        reportFilter = "ChannelID";
	        abstractCustomerProductReports.prdtGroupingExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 
	 public void verifyPrdtGroupingDBTestInsurerRecordDate() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerRecordDate";
	        abstractCustomerProductReports.prdtGroupingExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 
	 public void verifyPrdtGroupingDBTestAllValidInput() throws ClassNotFoundException, SQLException {
	        reportFilter = "AllValidInput";
	        abstractCustomerProductReports.prdtGroupingExceptionReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
}

