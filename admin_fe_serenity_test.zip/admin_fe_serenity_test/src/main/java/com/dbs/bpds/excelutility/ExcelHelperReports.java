package com.dbs.bpds.excelutility;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExcelHelperReports {

	public static HashMap<String, ArrayList<String>> excelReports(String reportFileName) {

		String currentExcelReportName = null;
		if (reportFileName == "cinChangeFileName")
			currentExcelReportName = Utils.getCINUpdateReportFileNameCurrentdate();
		else if (reportFileName == "invalidCinFileName")
			currentExcelReportName = Utils.getInvalidCinExceptionFileNameCurrentdate();
		else if (reportFileName == "CisPrdtUpdateReport")
        	currentExcelReportName = Utils.getCisPrdtUpdateExceptionReportFileNameCurrentDate();
		else if (reportFileName == "PrdtGroupingExceptionReport")
        	currentExcelReportName = Utils.getPrdtGroupingExceptionReportFileNameCurrentDate();
		
		List<ArrayList<String>> excelDataList = new ArrayList();

		try {
			FileInputStream excelFile = new FileInputStream(new File(Constants.DOWNLOAD_REPORT_PATH + currentExcelReportName));
			Workbook workBookExcel = new XSSFWorkbook(excelFile);
			Sheet dataTypeSheet = workBookExcel.getSheetAt(0);

			int maxRowIndex = dataTypeSheet.getLastRowNum();
			int maxCellIndex = 0;
			for (int i = 0; i < maxRowIndex + 1; i++) {
				Row currentRow = dataTypeSheet.getRow(i);

				if (maxCellIndex == 0) {
					maxCellIndex = currentRow.getLastCellNum();
				}

				ArrayList<String> columnList = new ArrayList();
				for (int j = 0; j < maxCellIndex; j++) {
					if (currentRow.getCell(j) != null) {
						columnList.add(currentRow.getCell(j).getStringCellValue());
					} else {
						columnList.add("");
					}
				}
				excelDataList.add(columnList);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

		excelDataList.remove(0);

		HashMap<String, ArrayList<String>> map = new HashMap<String, ArrayList<String>>();
		for (ArrayList<String> row : excelDataList) {
			String policyNo = row.get(1);
			map.put(policyNo, row);
		}
		return map;

	}
}

