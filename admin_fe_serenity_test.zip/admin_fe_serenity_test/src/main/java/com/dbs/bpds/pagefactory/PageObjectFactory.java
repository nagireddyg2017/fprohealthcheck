package com.dbs.bpds.pagefactory;

import org.openqa.selenium.WebDriver;

import com.dbs.bpds.pages.CinChangeUpdateReportPage;
import com.dbs.bpds.pages.CisProductUpdateExceptionReportPage;
import com.dbs.bpds.pages.InvalidCinExceptionReportPage;
import com.dbs.bpds.pages.LandingPage;
import com.dbs.bpds.pages.LoginPage;
import com.dbs.bpds.pages.ProductApprovedPage;
import com.dbs.bpds.pages.ProductAuditTrailReportPage;
import com.dbs.bpds.pages.ProductCancelledPage;
import com.dbs.bpds.pages.ProductGroupingExceptionReportPage;
import com.dbs.bpds.pages.CustomerHoldingEnquiryPage;

public class PageObjectFactory {
	
	private WebDriver driver;
	
	private LoginPage loginPage;
	private LandingPage landingPage;
	private InvalidCinExceptionReportPage invalidCinExceptionReportPage;
	private CinChangeUpdateReportPage cinChangeUpdateReportPage;
	private CisProductUpdateExceptionReportPage cisProductUpdateExceptionReportPage;
	private ProductGroupingExceptionReportPage prdtGroupExceptionReportPage;
	private ProductAuditTrailReportPage productAuditTrailReportPage;
	private CustomerHoldingEnquiryPage customerHoldingEnquiryPage;
	private ProductApprovedPage productApprovedPage;
	private ProductCancelledPage productCancelledPage;
	
	public PageObjectFactory(WebDriver driver) {
		 
		this.driver = driver;
 
	}
	
	public LoginPage getLoginPage() {
		return (loginPage == null) ? loginPage = new LoginPage(driver) : loginPage;
	}
	
	public LandingPage getLandingPage() {
		return (landingPage == null) ? landingPage = new LandingPage(driver) : landingPage;
	}
	
	public InvalidCinExceptionReportPage getInvalidCinExceptionReportPage() {
		return (invalidCinExceptionReportPage == null) ? invalidCinExceptionReportPage = new InvalidCinExceptionReportPage(driver) : invalidCinExceptionReportPage;
	}
	
	public CinChangeUpdateReportPage getCINChangeUpdateReportPage() {
		return (cinChangeUpdateReportPage == null) ? cinChangeUpdateReportPage = new CinChangeUpdateReportPage(driver) : cinChangeUpdateReportPage;
	}
	
	public ProductGroupingExceptionReportPage getProductGroupingExceptionReportPage() {
		return (prdtGroupExceptionReportPage == null) ? prdtGroupExceptionReportPage = new ProductGroupingExceptionReportPage(driver) : prdtGroupExceptionReportPage;
	}
	
	public CisProductUpdateExceptionReportPage getCisProductExceptionReportPage() {
		return (cisProductUpdateExceptionReportPage == null) ? cisProductUpdateExceptionReportPage = new CisProductUpdateExceptionReportPage(driver) : cisProductUpdateExceptionReportPage;
	}
	

	public ProductAuditTrailReportPage getProductAuditTrailReportPage() {
		return (productAuditTrailReportPage == null) ? productAuditTrailReportPage = new ProductAuditTrailReportPage(driver) : productAuditTrailReportPage;
	}

	public CustomerHoldingEnquiryPage getCustomerHoldingEnquiryPage() {
			
			return (customerHoldingEnquiryPage == null) ? customerHoldingEnquiryPage = new CustomerHoldingEnquiryPage(driver) : customerHoldingEnquiryPage;
		}
	
	public ProductApprovedPage getProductApprovedPage() {
		
		return (productApprovedPage == null) ? productApprovedPage = new ProductApprovedPage(driver) : productApprovedPage;
	}
	public ProductCancelledPage getProductCancelledPage() {
		
		return (productCancelledPage == null) ? productCancelledPage = new ProductCancelledPage(driver) : productCancelledPage;
	}
	
}