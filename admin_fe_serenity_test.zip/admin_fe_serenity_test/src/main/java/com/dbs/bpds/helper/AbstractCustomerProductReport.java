package com.dbs.bpds.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public abstract class AbstractCustomerProductReport {

	// Object of Connection from the Database
	Connection conn = null;

	// Object of Statement. It is used to create a Statement to execute the
	// query
	Statement stmt = null;

	// Object of ResultSet => 'It maintains a cursor that points to the current
	// row in the result set'
	ResultSet resultSet = null;

	public abstract void operationMethodAllValidInputOnFilters();

	public abstract void operationMethodInsurerName();

	public abstract void operationMethodProductCode();

	public abstract void operationMethodInsurerComponentCode();

	public abstract void operationMethodProductName();

	public abstract void operationMethodChannelID();

	public abstract void operationMethodInsurerRecordDate();

	public final void cisProductUpdateExceptionReport(String reportFilter) throws SQLException, ClassNotFoundException {
		SetUpConnection();

		String cisProductUpdateExceptionReportFilter = reportFilter;

		switch (cisProductUpdateExceptionReportFilter) {
		case "InsurerName":
			operationMethodInsurerName();
			break;
		case "ProductCode":
			operationMethodProductCode();
			break;
		case "InsurerComponentCode":
			operationMethodInsurerComponentCode();
			break;
		case "ProductName":
			operationMethodProductName();
			break;
		case "ChannelID":
			operationMethodChannelID();
			break;
		case "InsurerRecordDate":
			operationMethodInsurerRecordDate();
			break;
		case "AllValidInput":
			operationMethodAllValidInputOnFilters();
			break;
		default:
			System.out.println("Invalid Filter criteria");
			break;
		}
		CloseTheConnection();
	}
	
	public final void prdtGroupingExceptionReport(String reportFilter) throws SQLException, ClassNotFoundException {
		SetUpConnection();

		String prdtGroupingExceptionReportFilter = reportFilter;

		switch (prdtGroupingExceptionReportFilter) {
		case "InsurerName":
			operationMethodInsurerName();
			break;
		case "ProductCode":
			operationMethodProductCode();
			break;
		case "InsurerComponentCode":
			operationMethodInsurerComponentCode();
			break;
		case "ProductName":
			operationMethodProductName();
			break;
		case "ChannelID":
			operationMethodChannelID();
			break;
		case "InsurerRecordDate":
			operationMethodInsurerRecordDate();
			break;
		case "AllValidInput":
			operationMethodAllValidInputOnFilters();
			break;
		default:
			System.out.println("Invalid Filter criteria");
			break;
		}
		CloseTheConnection();
	}
	
	public final void prdtAuditTrailReport(String reportFilter) throws SQLException, ClassNotFoundException {
		SetUpConnection();

		String prdtAuditTrailReport = reportFilter;

		switch (prdtAuditTrailReport) {
		case "InsurerName":
			operationMethodInsurerName();
			break;
		case "ProductCode":
			operationMethodProductCode();
			break;
		case "InsurerComponentCode":
			operationMethodInsurerComponentCode();
			break;
		case "ProductName":
			operationMethodProductName();
			break;
		case "ChannelID":
			operationMethodChannelID();
			break;
		case "InsurerRecordDate":
			operationMethodInsurerRecordDate();
			break;
		case "AllValidInput":
			operationMethodAllValidInputOnFilters();
			break;
		default:
			System.out.println("Invalid Filter criteria");
			break;
		}
		CloseTheConnection();
	}

	private void SetUpConnection() throws SQLException, ClassNotFoundException {
		// Register JDBC driver (JDBC driver name and Database URL)
		Class.forName("com.mysql.jdbc.Driver");

		// Open a connection
		conn = DriverManager.getConnection("jdbc:mysql://10.91.138.100:6603/bpds", "bpds_db", "Bpdsmariadb18@");

	}

	private void CloseTheConnection() {
		// Code to close each and all Object related to Database connection
		if (resultSet != null) {
			try {
				resultSet.close();
			} catch (Exception e) {
			}
		}

		if (stmt != null) {
			try {
				stmt.close();
			} catch (Exception e) {
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

}

