package com.dbs.bpds.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.helper.AbstractCinExceptionChangeReport;
import com.dbs.bpds.helper.CinUpdateReportHelper;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

public class CinChangeUpdateReportPage {
	
	WebDriver driver;
	private static String cinChangeUpdateReportLabeltext;
	private static String cinUpdateFilterCriteriaStaticText;
	private static String reportFilter = null;
    private AbstractCinExceptionChangeReport abstractReports = new CinUpdateReportHelper();
	
	public CinChangeUpdateReportPage (WebDriver driver){
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.LINK_TEXT, using = "Cust Holding Reports")
	WebElement customerHoldingReports;
	
	@FindBy(how = How.LINK_TEXT, using = "CIN Change Update Report")
	WebElement linkCINChangeUpdateReport;
	
	@FindBy(how = How.XPATH, using = "//h4[contains(text(),'CIN Change Update Report')]")
	WebElement labelCINChangeUpdateReport;
	
	@FindBy(how = How.CSS, using = ".text-danger")
	WebElement txtFillCriteria;
	
	@FindBy(how = How.XPATH, using = "//button[@type='submit']")
	WebElement btnExport;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerName'] .cst-i-arrow-s")
	WebElement dropDownInsurerName;
	
	@FindBy(how = How.CSS, using = "cst-list [role] [role='option']:nth-of-type(2)")
	WebElement selectInsurerName;
	
	@FindBy(how = How.XPATH, using = "//div/input[1][@formcontrolname='productName']")
	WebElement enterProductName;
	
	@FindBy(how = How.XPATH, using = "//div/input[1][@formcontrolname='insurerOwnerCin']")
	WebElement enterInsurerOwnerCIN;
	
	@FindBy(how = How.XPATH, using = "//div/input[1][@formcontrolname='insurerOwnerName']")
	WebElement enterInsurerOwnerNme;
	
	@FindBy(how = How.XPATH, using = "//input[@formcontrolname='dbsOwnerCin']")
	WebElement enterDbsOwnerCin;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='channelId']")
	WebElement clickChannelID;
	
	@FindBy(how = How.CSS, using = "cst-list [role] [role='option']:nth-of-type(6)")
	WebElement selectChannelId;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerRecordDateFrom'] .cst-input")
	WebElement clickInsurerRecordDateFrom;
	
	@FindBy(how = How.CSS, using = "[formcontrolname='insurerRecordDateTo'] .cst-input")
	WebElement clickInsurerRecordDateTo;
	
	@FindBy(how = How.CSS, using = ".cst-toaster-main__title--warn")
	WebElement noRecordFoundwarningMsg;
	
	public void clkReports() {
		customerHoldingReports.click();
	}
	public void clickCINChangeUpdateReport() {
		linkCINChangeUpdateReport.click();		
	}
	
	public void verifyCINChangeUpdateReport(){
		cinChangeUpdateReportLabeltext = labelCINChangeUpdateReport.getText();
		assertThat(cinChangeUpdateReportLabeltext.equalsIgnoreCase("CIN Change Update Report"));
	}
	
	public void verifyCINChangeUpdateReportFileisDownloaded(){
        File cinChangeFile = new File(Constants.DOWNLOAD_REPORT_PATH, Utils.getCINUpdateReportFileNameCurrentdate());
        assertThat(cinChangeFile).exists().hasName(Utils.getCINUpdateReportFileNameCurrentdate()).hasExtension("xlsx");
        
    }
	
	public void verifyStaticFillCriteriaText() {
		cinUpdateFilterCriteriaStaticText = txtFillCriteria.getText();
		assertThat(cinUpdateFilterCriteriaStaticText.equalsIgnoreCase("Please fill in at least 1 criteria to proceed"));		
	}
	
	public void chkBtnExportIsDiabled() {
		assertThat(!btnExport.isEnabled());
	}
	
	public void selectInsurerName() {
		dropDownInsurerName.click();
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(selectInsurerName));
		selectInsurerName.click();		
	}
	
	public void chkBtnExportIsEnabled() {
		assertThat(btnExport.isEnabled());
	}
	
	public void verifyNoRecordErrorBanner(){
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(noRecordFoundwarningMsg));
		assertThat(noRecordFoundwarningMsg.getText().contains("No Records Found"));
	}
	
	public void clickBtnExport() throws InterruptedException {
		btnExport.click();
		Thread.sleep(3000);
	}
	
	public void enterProductName(String productName){
		 
		 enterProductName.clear();
		 enterProductName.click();
		 enterProductName.sendKeys(productName);
		 
	 }
	 
	 public void enterInsurerOwnerCIN(String insurerOwnerCIN) {
		 enterInsurerOwnerCIN.clear();
		 enterInsurerOwnerCIN.click();
		 enterInsurerOwnerCIN.sendKeys(insurerOwnerCIN);
		 
	 }
	 
	 public void enterInsurerOwnerName(String insurerOwnerName) {
		 enterInsurerOwnerNme.clear();
		 enterInsurerOwnerNme.click();
		 enterInsurerOwnerNme.sendKeys(insurerOwnerName);
		 
	 }
	 
	 public void enterDBSOwnerCin(String dbsOwnerCin) {
		 enterDbsOwnerCin.clear();
		 enterDbsOwnerCin.click();
		 enterDbsOwnerCin.sendKeys(dbsOwnerCin);
	 }
	 
	 public void selectChannelID() {
		 clickChannelID.click();
		 Utils.wait(driver).until(ExpectedConditions.visibilityOf(selectChannelId));
		 selectChannelId.click();		 
	 }
	 
	 public void selectInsurerDateFrom(String insurerRecordReceivedDateFrom) {
		 clickInsurerRecordDateFrom.clear();
		 clickInsurerRecordDateFrom.click();
		 clickInsurerRecordDateFrom.sendKeys(insurerRecordReceivedDateFrom);		 
	 }
	 
	 public void selectInsurerDateTo(String insurerRecordReceivedDateTo) throws IOException {
		 clickInsurerRecordDateTo.clear();
		 clickInsurerRecordDateTo.click();
		 clickInsurerRecordDateTo.sendKeys(insurerRecordReceivedDateTo);
		 Utils.take_screenshot(driver);
		 
	 }
	 
	 public void verifyCinChangeReportDBTestInsurerName() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerName";
	        abstractReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 
	 public void verifyCinChangeReportDBTestProductName() throws ClassNotFoundException, SQLException {
	        reportFilter = "ProductName";
	        abstractReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyCinChangeReportDBTestInsurerOwnerCIN() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerOwnerCIN";
	        abstractReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyCinChangeReportDBTestInsurerOwnerName() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerOwnerName";
	        abstractReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyCinChangeReportDBTestDBSOwnerCIN() throws ClassNotFoundException, SQLException {
	        reportFilter = "DBSOwnerCIN";
	        abstractReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyCinChangeReportDBTestChannelID() throws ClassNotFoundException, SQLException {
	        reportFilter = "ChannelID";
	        abstractReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyCinChangeReportDBTestInsurerRecordDate() throws ClassNotFoundException, SQLException {
	        reportFilter = "InsurerRecordDate";
	        abstractReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }
	 public void verifyCinChangeReportDBTestAllValidInput() throws ClassNotFoundException, SQLException {
	        reportFilter = "AllValidInput";
	        abstractReports.cinUpdateReport(reportFilter);
	        Utils.cleanDirectory(new File(Constants.DOWNLOAD_REPORT_PATH));
	 }

}
