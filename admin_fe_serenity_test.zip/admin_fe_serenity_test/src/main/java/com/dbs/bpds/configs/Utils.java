package com.dbs.bpds.configs;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Utils {

	public static WebDriver driver = null;
	public static String actual_message;

	public static WebDriver selectBrowser(String browser) {

		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", Constants.DOWNLOAD_REPORT_PATH);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", chromePrefs);
		DesiredCapabilities cap = DesiredCapabilities.chrome();
		cap.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		cap.setCapability(ChromeOptions.CAPABILITY, options);

		try {
			if ((Constants.DRIVER).equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "resources\\chromedriver.exe");
				driver = new ChromeDriver(cap);
				driver.manage().deleteAllCookies();
				driver.manage().window().maximize();
			} else if (browser.equalsIgnoreCase("ie")) {
				driver = new InternetExplorerDriver();
				System.setProperty("webdriver.ie.driver", "src/test/resources/IEDriver");
				driver.manage().window().maximize();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return driver;
	}

	public static WebDriverWait wait(WebDriver driver) {
		return new WebDriverWait(driver, 60);
	}

	public static String getErrorMessageText(WebElement e) {
		actual_message = e.getText();
		return actual_message;
	}
	
public static String DateFormat(String dateFromInputSheet){
		
		SimpleDateFormat sdf=new SimpleDateFormat("ddmmyyyy");
		Date s = null;
		try {
			s = sdf.parse(dateFromInputSheet);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SimpleDateFormat requiredSdf=new SimpleDateFormat("yyyy-mm-dd");
		String requiredDate=requiredSdf.format(s);
		return requiredDate;
	}

	public static String getPolicyDetailsFileName(String policyNumber) {
		System.out.println("policy no "+policyNumber);
		String policyDetails_FileName = String.format("Cust Holding "+policyNumber+".xlsx");
		System.out.println(policyDetails_FileName);
		return policyDetails_FileName;
	
	}

	public static void verifyErrorMessage(String actual_message, String expected_message) {

		assertThat(actual_message.equals(expected_message));
	}

	public static void cleanDirectory(File directory) {
		try {
			FileUtils.cleanDirectory(directory);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static String getInvalidCinExceptionFileNameCurrentdate() {
		Calendar cal = Calendar.getInstance();
		String result = String.format("INVALID CIN %1$ty%1$tm%1$td.xlsx", cal);
		return result;
	}

	public static String getCINUpdateReportFileNameCurrentdate() {
		Calendar cale = Calendar.getInstance();
		String cinChangeResult = String.format("CIN CHANGE UPDATE %1$ty%1$tm%1$td.xlsx", cale);
		return cinChangeResult;
	}
	
	public static String getCisPrdtUpdateExceptionReportFileNameCurrentDate() {
		Calendar cal = Calendar.getInstance();
		String cisPrdtUpdateExceptionResult = String.format("CIS PRDT UPDATE EXCEPTION %1$ty%1$tm%1$td.xlsx", cal);
		return cisPrdtUpdateExceptionResult;
	}
	
	public static String getPrdtGroupingExceptionReportFileNameCurrentDate() {
		Calendar cal = Calendar.getInstance();
		String prdtGroupingExceptionResult = String.format("PRODUCT GROUPING EXCEPTION %1$ty%1$tm%1$td.xlsx", cal);
		return prdtGroupingExceptionResult;
	}
	
	public static String getPrdtAuditTrailReportFileNameCurrentDate() {
		Calendar cal = Calendar.getInstance();
		String prdtAuditTrailResult = String.format("Product Audit Trail Report %1$ty%1$tm%1$td.xlsx", cal);
		return prdtAuditTrailResult;		
	}

	public static void take_screenshot(WebDriver driver) throws IOException {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd-HHmmss");
		String dateTime = sdf2.format(cal.getTime());
		File actualScreenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		System.out.println("Working Directory = " + System.getProperty("user.dir"));
		String CurrentPath = System.getProperty("user.dir");
		String filepath = CurrentPath + "/" + "Screenshots" + "/";
		File currentScreenshotPath = new File(filepath + dateTime + ".jpg");
		System.out.println("Actual Screenshot Captured : Location -> " + actualScreenshot);
		System.out.println("Copy Screenshot in to : Location -> " + currentScreenshotPath);
		FileUtils.copyFile(actualScreenshot, currentScreenshotPath);
	}
}
