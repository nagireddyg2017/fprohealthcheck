package com.dbs.bpds.pages;

import static org.assertj.core.api.Assertions.*;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.dbs.bpds.configs.Utils;

import net.thucydides.core.pages.PageObject;

public class LandingPage extends PageObject {

	WebDriver driver;

	public LandingPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.LINK_TEXT, using = "Product Admin Module")
	WebElement productAdminModule;

	@FindBy(how = How.LINK_TEXT, using = "Customer Holdings Module")
	WebElement customerHoldingModule;

	@FindBy(xpath = "//ul[2]/li[3]/a[@href='/home/staffModule']")
	WebElement staffModule;

	@FindBy(xpath = "//ul[2]/li[2]/a")
	WebElement logOut;

	@FindBy(xpath = "//ul/li[1]/a[@href='/home/productAdmin/pendingAction']")
	WebElement pendingActionHeader;

	@FindBy(xpath = "//ul/li[1]/a[@href='/home/customerHoldings/customerHoldingsEnquiry']")
	WebElement customerHoldingEnquiryHeader;

	@FindBy(how = How.XPATH, using = "//div[2]/div/p")
	WebElement dialogBoxPopUp;

	@FindBy(xpath = "//div[2]/div/p")
	WebElement defaultProductListingRecordsMessage;

	@FindBy(how = How.XPATH, using = "//cst-dialog-actions/button")
	WebElement defaultProductListingPopup_OkayButton;

	public void clickOnProductAdminModule() {
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(productAdminModule));
		productAdminModule.click();
	}
	
	public void verifyPendingAcitonPage() {
		
		/*try {
			if (Utils.wait(driver).until(ExpectedConditions.visibilityOf(dialogBoxPopUp)).isDisplayed()) {
				defaultProductListingPopup_OkayButton.click();

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		assertThat(pendingActionHeader.getText().contains("Pending Action"));
	}

	public void clickOncustomerHoldingsModule() {
		Utils.wait(driver).until(ExpectedConditions.visibilityOf(customerHoldingModule));
		customerHoldingModule.click();
	}
	
	public void verifyCustomerHoldingsPage() {
		assertThat(customerHoldingEnquiryHeader.getText().contains("Customer Holdings Enquiry"));
	}

	public void logoutFromApplication() {
		logOut.click();
	}

}
