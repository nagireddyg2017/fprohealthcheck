package com.dbs.bpds.helper;

import java.util.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.dbs.bpds.excelutility.ExcelHelperCommomUtils;

public class ProductAuditReportHelper extends AbstractCustomerProductReport {
	
	private static String reportFileName = "ProductAuditTrialReport";

	@Override
	public void operationMethodAllValidInputOnFilters() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery("select RECORD_STATUS, \n" +
                    "case MAINTENANCE_INDICATOR\n" +
                    "when '01' then 'Create'\n" +
                    "when '02' then 'Update'\n" +
                    "end as MAINTENANCE_INDICATOR, PRODUCT_NAME, PRODUCT_CODE, COMPONENT_CODE,INSURER_NAME, INSURER_CODE, \n" +
                    "case PLAN_TYPE\n" +
                    "when '00' then 'Basic'\n" +
                    "when '01' then 'Rider'\n" +
                    "when '02' then 'SubFund'\n" +
                    "end as PLAN_TYPE, null AS Choice_of_Cover, null AS Coverage_Period_travel, IBMB_TEMPLATE_NAME, \n" +
                    "CUSTOMER_SEGMENT_MM, CUSTOMER_SEGMENT_TR, CUSTOMER_SEGMENT_TPC, CUSTOMER_SEGMENT_PB, POLICY_CATEGORY,\n" +
                    "COVERAGE_TYPE, PRODUCT_GROUPING, REMARKS, LAST_UPDATED_BY,LAST_UPDATED_DATE_TIME, \n" +
                    "APPROVED_BY,APPROVED_DATE_TIME, RECORD_TIMESTAMP\n" +
                    "from bpds.dbs_li_product_history where PRODUCT_CODE = 'HRT5' and COMPONENT_CODE = 'HRT05' and INSURER_CODE = '005' and PRODUCT_NAME = 'HEIRLOOM (II)' and record_timestamp \n" +
                    "between '2018-11-01 00:00:00' and '2018-11-01 23:59:59';");

            List<ArrayList<String>> columnListReportsExcel = ExcelHelperCommomUtils.excelReports(reportFileName);

            System.out.println("Print Excel Data reports here");

            System.out.println(columnListReportsExcel);
            System.out.println("Excel Row Count => " + columnListReportsExcel.size());

            int matchRowCount = 0;
            int columnCount = resultSet.getMetaData().getColumnCount();


            System.out.println("columnCount=====>"+columnCount);

            ProductHistory compareExcelDBObj = new ProductHistory();
            ProductHistory compareExcelDBObj2 = new ProductHistory();

            List<ProductHistory> productHistoryListExcel = new ArrayList<>();
            List<ProductHistory> productHistoryListDB = new ArrayList<>();

            columnListReportsExcel.forEach(row -> {
                compareExcelDBObj.setRecordStatus(row.get(0));
                compareExcelDBObj.setMaintenanceStatus(row.get(1));
                compareExcelDBObj.setProductName(row.get(2));
                compareExcelDBObj.setProductCode(row.get(3));
                compareExcelDBObj.setInsurerComponentCode(row.get(4));
                compareExcelDBObj.setInsurerName(row.get(5));
                compareExcelDBObj.setInsurerCode(row.get(6));
                compareExcelDBObj.setPlanType(row.get(7));
                compareExcelDBObj.setChoiceofCover(row.get(8));
                compareExcelDBObj.setCoveragePeriodTravel(row.get(9));
                compareExcelDBObj.setTemplateName(row.get(10));
                compareExcelDBObj.setSegmentMM(row.get(11));
                compareExcelDBObj.setSegmentTR(row.get(12));
                compareExcelDBObj.setSegmentTPC(row.get(13));
                compareExcelDBObj.setSegmentPB(row.get(14));
                compareExcelDBObj.setPolicyCategory(row.get(15));
                compareExcelDBObj.setCoverageType(row.get(16));
                compareExcelDBObj.setProductCategory(row.get(17));
                compareExcelDBObj.setRemark(row.get(18));
                compareExcelDBObj.setLastUpdatedBy(row.get(19));
                compareExcelDBObj.setLastUpdatedDateTime(row.get(20));
                compareExcelDBObj.setLastApprovedBy(row.get(21));
                compareExcelDBObj.setLastApprovedDateTime(row.get(22));
                productHistoryListExcel.add(compareExcelDBObj);

            });


            while(resultSet.next()){

                compareExcelDBObj2.setRecordStatus(Objects.toString(resultSet.getString(1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(1));
                compareExcelDBObj2.setMaintenanceStatus(Objects.toString(resultSet.getString(2), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(2));
                compareExcelDBObj2.setProductName(Objects.toString(resultSet.getString(3), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(3));
                compareExcelDBObj2.setProductCode(Objects.toString(resultSet.getString(4), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(4));
                compareExcelDBObj2.setInsurerComponentCode(Objects.toString(resultSet.getString(5), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(5));
                compareExcelDBObj2.setInsurerName(Objects.toString(resultSet.getString(6), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(6));
                compareExcelDBObj2.setInsurerCode(Objects.toString(resultSet.getString(7), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(7));
                compareExcelDBObj2.setPlanType(Objects.toString(resultSet.getString(8), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(8));
                compareExcelDBObj2.setChoiceofCover(Objects.toString(resultSet.getString(9), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(9));
                compareExcelDBObj2.setCoveragePeriodTravel(Objects.toString(resultSet.getString(10), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(10));
                compareExcelDBObj2.setTemplateName(Objects.toString(resultSet.getString(11), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(11));
                compareExcelDBObj2.setSegmentMM(Objects.toString(resultSet.getString(12), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(12));
                compareExcelDBObj2.setSegmentTR(Objects.toString(resultSet.getString(13), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(13));
                compareExcelDBObj2.setSegmentTPC(Objects.toString(resultSet.getString(14), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(14));
                compareExcelDBObj2.setSegmentPB(Objects.toString(resultSet.getString(15), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(15));
                compareExcelDBObj2.setPolicyCategory(Objects.toString(resultSet.getString(16), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(16));
                compareExcelDBObj2.setCoverageType(Objects.toString(resultSet.getString(17), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(17));
                compareExcelDBObj2.setProductCategory(Objects.toString(resultSet.getString(18), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(18));
                compareExcelDBObj2.setRemark(Objects.toString(resultSet.getString(19), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(19));
                compareExcelDBObj2.setLastUpdatedBy(Objects.toString(resultSet.getString(20), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(20));
                compareExcelDBObj2.setLastUpdatedDateTime((Objects.toString(resultSet.getString(21), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(21).substring(0,19)));
                compareExcelDBObj2.setLastApprovedBy(Objects.toString(resultSet.getString(22), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(22));
                compareExcelDBObj2.setLastApprovedDateTime((Objects.toString(resultSet.getString(23), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(23).substring(0,19)));
                

                productHistoryListDB.add(compareExcelDBObj2);

            }
            Collections.sort(productHistoryListExcel, new ProductHistory.CustomComparator());
            Collections.sort(productHistoryListDB, new ProductHistory.CustomComparator());
            System.out.println(productHistoryListExcel.toString());
            System.out.println(productHistoryListDB.toString());

            boolean identical = true;
            for (int i=0; i<productHistoryListDB.size(); i++) {
                identical = productHistoryListDB.get(i).equals(productHistoryListExcel.get(i));
                assertThat(!identical).isFalse();
                if (!identical)                	
                    System.out.println("Data between Excel and Database are NOT matched");
                break;

            }
            System.out.println("Data between Excel and Database are matched");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodInsurerName() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery("select RECORD_STATUS, \n" +
                    "case MAINTENANCE_INDICATOR\n" +
                    "when '01' then 'Create'\n" +
                    "when '02' then 'Update'\n" +
                    "end as MAINTENANCE_INDICATOR, PRODUCT_NAME, PRODUCT_CODE, COMPONENT_CODE,INSURER_NAME, INSURER_CODE, \n" +
                    "case PLAN_TYPE\n" +
                    "when '00' then 'Basic'\n" +
                    "when '01' then 'Rider'\n" +
                    "when '02' then 'SubFund'\n" +
                    "end as PLAN_TYPE, null AS Choice_of_Cover, null AS Coverage_Period_travel, IBMB_TEMPLATE_NAME, \n" +
                    "CUSTOMER_SEGMENT_MM, CUSTOMER_SEGMENT_TR, CUSTOMER_SEGMENT_TPC, CUSTOMER_SEGMENT_PB, POLICY_CATEGORY,\n" +
                    "COVERAGE_TYPE, PRODUCT_GROUPING, REMARKS, LAST_UPDATED_BY,LAST_UPDATED_DATE_TIME, \n" +
                    "APPROVED_BY,APPROVED_DATE_TIME\n" +
                    "from bpds.dbs_li_product_history where INSURER_CODE = '005';");

            List<ArrayList<String>> columnListReportsExcel = ExcelHelperCommomUtils.excelReports(reportFileName);

            System.out.println("Print Excel Data reports here");

            System.out.println(columnListReportsExcel);
            System.out.println("Excel Row Count => " + columnListReportsExcel.size());

            int matchRowCount = 0;
            int columnCount = resultSet.getMetaData().getColumnCount();


            System.out.println("columnCount=====>"+columnCount);

            ProductHistory compareExcelDBObj = new ProductHistory();
            ProductHistory compareExcelDBObj2 = new ProductHistory();

            List<ProductHistory> productHistoryListExcel = new ArrayList<>();
            List<ProductHistory> productHistoryListDB = new ArrayList<>();

            columnListReportsExcel.forEach(row -> {
                compareExcelDBObj.setRecordStatus(row.get(0));
                compareExcelDBObj.setMaintenanceStatus(row.get(1));
                compareExcelDBObj.setProductName(row.get(2));
                compareExcelDBObj.setProductCode(row.get(3));
                compareExcelDBObj.setInsurerComponentCode(row.get(4));
                compareExcelDBObj.setInsurerName(row.get(5));
                compareExcelDBObj.setInsurerCode(row.get(6));
                compareExcelDBObj.setPlanType(row.get(7));
                compareExcelDBObj.setChoiceofCover(row.get(8));
                compareExcelDBObj.setCoveragePeriodTravel(row.get(9));
                compareExcelDBObj.setTemplateName(row.get(10));
                compareExcelDBObj.setSegmentMM(row.get(11));
                compareExcelDBObj.setSegmentTR(row.get(12));
                compareExcelDBObj.setSegmentTPC(row.get(13));
                compareExcelDBObj.setSegmentPB(row.get(14));
                compareExcelDBObj.setPolicyCategory(row.get(15));
                compareExcelDBObj.setCoverageType(row.get(16));
                compareExcelDBObj.setProductCategory(row.get(17));
                compareExcelDBObj.setRemark(row.get(18));
                compareExcelDBObj.setLastUpdatedBy(row.get(19));
                compareExcelDBObj.setLastUpdatedDateTime(row.get(20));
                compareExcelDBObj.setLastApprovedBy(row.get(21));
                compareExcelDBObj.setLastApprovedDateTime(row.get(22));
                productHistoryListExcel.add(compareExcelDBObj);

            });


            while(resultSet.next()){

                compareExcelDBObj2.setRecordStatus(Objects.toString(resultSet.getString(1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(1));
                compareExcelDBObj2.setMaintenanceStatus(Objects.toString(resultSet.getString(2), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(2));
                compareExcelDBObj2.setProductName(Objects.toString(resultSet.getString(3), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(3));
                compareExcelDBObj2.setProductCode(Objects.toString(resultSet.getString(4), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(4));
                compareExcelDBObj2.setInsurerComponentCode(Objects.toString(resultSet.getString(5), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(5));
                compareExcelDBObj2.setInsurerName(Objects.toString(resultSet.getString(6), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(6));
                compareExcelDBObj2.setInsurerCode(Objects.toString(resultSet.getString(7), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(7));
                compareExcelDBObj2.setPlanType(Objects.toString(resultSet.getString(8), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(8));
                compareExcelDBObj2.setChoiceofCover(Objects.toString(resultSet.getString(9), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(9));
                compareExcelDBObj2.setCoveragePeriodTravel(Objects.toString(resultSet.getString(10), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(10));
                compareExcelDBObj2.setTemplateName(Objects.toString(resultSet.getString(11), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(11));
                compareExcelDBObj2.setSegmentMM(Objects.toString(resultSet.getString(12), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(12));
                compareExcelDBObj2.setSegmentTR(Objects.toString(resultSet.getString(13), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(13));
                compareExcelDBObj2.setSegmentTPC(Objects.toString(resultSet.getString(14), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(14));
                compareExcelDBObj2.setSegmentPB(Objects.toString(resultSet.getString(15), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(15));
                compareExcelDBObj2.setPolicyCategory(Objects.toString(resultSet.getString(16), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(16));
                compareExcelDBObj2.setCoverageType(Objects.toString(resultSet.getString(17), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(17));
                compareExcelDBObj2.setProductCategory(Objects.toString(resultSet.getString(18), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(18));
                compareExcelDBObj2.setRemark(Objects.toString(resultSet.getString(19), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(19));
                compareExcelDBObj2.setLastUpdatedBy(Objects.toString(resultSet.getString(20), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(20));
                compareExcelDBObj2.setLastUpdatedDateTime((Objects.toString(resultSet.getString(21), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(21).substring(0,19)));
                compareExcelDBObj2.setLastApprovedBy(Objects.toString(resultSet.getString(22), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(22));
                compareExcelDBObj2.setLastApprovedDateTime((Objects.toString(resultSet.getString(23), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(23).substring(0,19)));
                

                productHistoryListDB.add(compareExcelDBObj2);

            }
            Collections.sort(productHistoryListExcel, new ProductHistory.CustomComparator());
            Collections.sort(productHistoryListDB, new ProductHistory.CustomComparator());
            System.out.println(productHistoryListExcel.toString());
            System.out.println(productHistoryListDB.toString());

            boolean identical = true;
            for (int i=0; i<productHistoryListDB.size(); i++) {
                identical = productHistoryListDB.get(i).equals(productHistoryListExcel.get(i));
                assertThat(!identical).isFalse();
                if (!identical)                	
                    System.out.println("Data between Excel and Database are NOT matched");
                break;

            }
            System.out.println("Data between Excel and Database are matched");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodProductCode() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery("select RECORD_STATUS, \n" +
                    "case MAINTENANCE_INDICATOR\n" +
                    "when '01' then 'Create'\n" +
                    "when '02' then 'Update'\n" +
                    "end as MAINTENANCE_INDICATOR, PRODUCT_NAME, PRODUCT_CODE, COMPONENT_CODE,INSURER_NAME, INSURER_CODE, \n" +
                    "case PLAN_TYPE\n" +
                    "when '00' then 'Basic'\n" +
                    "when '01' then 'Rider'\n" +
                    "when '02' then 'SubFund'\n" +
                    "end as PLAN_TYPE, null AS Choice_of_Cover, null AS Coverage_Period_travel, IBMB_TEMPLATE_NAME, \n" +
                    "CUSTOMER_SEGMENT_MM, CUSTOMER_SEGMENT_TR, CUSTOMER_SEGMENT_TPC, CUSTOMER_SEGMENT_PB, POLICY_CATEGORY,\n" +
                    "COVERAGE_TYPE, PRODUCT_GROUPING, REMARKS, LAST_UPDATED_BY,LAST_UPDATED_DATE_TIME, \n" +
                    "APPROVED_BY,APPROVED_DATE_TIME\n" +
                    "from bpds.dbs_li_product_history where PRODUCT_CODE = 'A501';");

            List<ArrayList<String>> columnListReportsExcel = ExcelHelperCommomUtils.excelReports(reportFileName);

            System.out.println("Print Excel Data reports here");

            System.out.println(columnListReportsExcel);
            System.out.println("Excel Row Count => " + columnListReportsExcel.size());

            int matchRowCount = 0;
            int columnCount = resultSet.getMetaData().getColumnCount();


            System.out.println("columnCount=====>"+columnCount);

            ProductHistory compareExcelDBObj = new ProductHistory();
            ProductHistory compareExcelDBObj2 = new ProductHistory();

            List<ProductHistory> productHistoryListExcel = new ArrayList<>();
            List<ProductHistory> productHistoryListDB = new ArrayList<>();

            columnListReportsExcel.forEach(row -> {
                compareExcelDBObj.setRecordStatus(row.get(0));
                compareExcelDBObj.setMaintenanceStatus(row.get(1));
                compareExcelDBObj.setProductName(row.get(2));
                compareExcelDBObj.setProductCode(row.get(3));
                compareExcelDBObj.setInsurerComponentCode(row.get(4));
                compareExcelDBObj.setInsurerName(row.get(5));
                compareExcelDBObj.setInsurerCode(row.get(6));
                compareExcelDBObj.setPlanType(row.get(7));
                compareExcelDBObj.setChoiceofCover(row.get(8));
                compareExcelDBObj.setCoveragePeriodTravel(row.get(9));
                compareExcelDBObj.setTemplateName(row.get(10));
                compareExcelDBObj.setSegmentMM(row.get(11));
                compareExcelDBObj.setSegmentTR(row.get(12));
                compareExcelDBObj.setSegmentTPC(row.get(13));
                compareExcelDBObj.setSegmentPB(row.get(14));
                compareExcelDBObj.setPolicyCategory(row.get(15));
                compareExcelDBObj.setCoverageType(row.get(16));
                compareExcelDBObj.setProductCategory(row.get(17));
                compareExcelDBObj.setRemark(row.get(18));
                compareExcelDBObj.setLastUpdatedBy(row.get(19));
                compareExcelDBObj.setLastUpdatedDateTime(row.get(20));
                compareExcelDBObj.setLastApprovedBy(row.get(21));
                compareExcelDBObj.setLastApprovedDateTime(row.get(22));
                productHistoryListExcel.add(compareExcelDBObj);

            });


            while(resultSet.next()){

                compareExcelDBObj2.setRecordStatus(Objects.toString(resultSet.getString(1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(1));
                compareExcelDBObj2.setMaintenanceStatus(Objects.toString(resultSet.getString(2), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(2));
                compareExcelDBObj2.setProductName(Objects.toString(resultSet.getString(3), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(3));
                compareExcelDBObj2.setProductCode(Objects.toString(resultSet.getString(4), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(4));
                compareExcelDBObj2.setInsurerComponentCode(Objects.toString(resultSet.getString(5), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(5));
                compareExcelDBObj2.setInsurerName(Objects.toString(resultSet.getString(6), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(6));
                compareExcelDBObj2.setInsurerCode(Objects.toString(resultSet.getString(7), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(7));
                compareExcelDBObj2.setPlanType(Objects.toString(resultSet.getString(8), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(8));
                compareExcelDBObj2.setChoiceofCover(Objects.toString(resultSet.getString(9), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(9));
                compareExcelDBObj2.setCoveragePeriodTravel(Objects.toString(resultSet.getString(10), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(10));
                compareExcelDBObj2.setTemplateName(Objects.toString(resultSet.getString(11), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(11));
                compareExcelDBObj2.setSegmentMM(Objects.toString(resultSet.getString(12), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(12));
                compareExcelDBObj2.setSegmentTR(Objects.toString(resultSet.getString(13), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(13));
                compareExcelDBObj2.setSegmentTPC(Objects.toString(resultSet.getString(14), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(14));
                compareExcelDBObj2.setSegmentPB(Objects.toString(resultSet.getString(15), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(15));
                compareExcelDBObj2.setPolicyCategory(Objects.toString(resultSet.getString(16), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(16));
                compareExcelDBObj2.setCoverageType(Objects.toString(resultSet.getString(17), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(17));
                compareExcelDBObj2.setProductCategory(Objects.toString(resultSet.getString(18), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(18));
                compareExcelDBObj2.setRemark(Objects.toString(resultSet.getString(19), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(19));
                compareExcelDBObj2.setLastUpdatedBy(Objects.toString(resultSet.getString(20), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(20));
                compareExcelDBObj2.setLastUpdatedDateTime((Objects.toString(resultSet.getString(21), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(21).substring(0,19)));
                compareExcelDBObj2.setLastApprovedBy(Objects.toString(resultSet.getString(22), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(22));
                compareExcelDBObj2.setLastApprovedDateTime((Objects.toString(resultSet.getString(23), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(23).substring(0,19)));
                

                productHistoryListDB.add(compareExcelDBObj2);

            }
            Collections.sort(productHistoryListExcel, new ProductHistory.CustomComparator());
            Collections.sort(productHistoryListDB, new ProductHistory.CustomComparator());
            System.out.println(productHistoryListExcel.toString());
            System.out.println(productHistoryListDB.toString());

            boolean identical = true;
            for (int i=0; i<productHistoryListDB.size(); i++) {
                identical = productHistoryListDB.get(i).equals(productHistoryListExcel.get(i));
                assertThat(!identical).isFalse();
                if (!identical)                	
                    System.out.println("Data between Excel and Database are NOT matched");
                break;

            }
            System.out.println("Data between Excel and Database are matched");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}
		
	

	@Override
	public void operationMethodInsurerComponentCode() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery("select RECORD_STATUS, \n" +
                    "case MAINTENANCE_INDICATOR\n" +
                    "when '01' then 'Create'\n" +
                    "when '02' then 'Update'\n" +
                    "end as MAINTENANCE_INDICATOR, PRODUCT_NAME, PRODUCT_CODE, COMPONENT_CODE,INSURER_NAME, INSURER_CODE, \n" +
                    "case PLAN_TYPE\n" +
                    "when '00' then 'Basic'\n" +
                    "when '01' then 'Rider'\n" +
                    "when '02' then 'SubFund'\n" +
                    "end as PLAN_TYPE, null AS Choice_of_Cover, null AS Coverage_Period_travel, IBMB_TEMPLATE_NAME, \n" +
                    "CUSTOMER_SEGMENT_MM, CUSTOMER_SEGMENT_TR, CUSTOMER_SEGMENT_TPC, CUSTOMER_SEGMENT_PB, POLICY_CATEGORY,\n" +
                    "COVERAGE_TYPE, PRODUCT_GROUPING, REMARKS, LAST_UPDATED_BY,LAST_UPDATED_DATE_TIME, \n" +
                    "APPROVED_BY,APPROVED_DATE_TIME\n" +
                    "from bpds.dbs_li_product_history where COMPONENT_CODE = 'A501S';");

            List<ArrayList<String>> columnListReportsExcel = ExcelHelperCommomUtils.excelReports(reportFileName);

            System.out.println("Print Excel Data reports here");

            System.out.println(columnListReportsExcel);
            System.out.println("Excel Row Count => " + columnListReportsExcel.size());

            int matchRowCount = 0;
            int columnCount = resultSet.getMetaData().getColumnCount();


            System.out.println("columnCount=====>"+columnCount);

            ProductHistory compareExcelDBObj = new ProductHistory();
            ProductHistory compareExcelDBObj2 = new ProductHistory();

            List<ProductHistory> productHistoryListExcel = new ArrayList<>();
            List<ProductHistory> productHistoryListDB = new ArrayList<>();

            columnListReportsExcel.forEach(row -> {
                compareExcelDBObj.setRecordStatus(row.get(0));
                compareExcelDBObj.setMaintenanceStatus(row.get(1));
                compareExcelDBObj.setProductName(row.get(2));
                compareExcelDBObj.setProductCode(row.get(3));
                compareExcelDBObj.setInsurerComponentCode(row.get(4));
                compareExcelDBObj.setInsurerName(row.get(5));
                compareExcelDBObj.setInsurerCode(row.get(6));
                compareExcelDBObj.setPlanType(row.get(7));
                compareExcelDBObj.setChoiceofCover(row.get(8));
                compareExcelDBObj.setCoveragePeriodTravel(row.get(9));
                compareExcelDBObj.setTemplateName(row.get(10));
                compareExcelDBObj.setSegmentMM(row.get(11));
                compareExcelDBObj.setSegmentTR(row.get(12));
                compareExcelDBObj.setSegmentTPC(row.get(13));
                compareExcelDBObj.setSegmentPB(row.get(14));
                compareExcelDBObj.setPolicyCategory(row.get(15));
                compareExcelDBObj.setCoverageType(row.get(16));
                compareExcelDBObj.setProductCategory(row.get(17));
                compareExcelDBObj.setRemark(row.get(18));
                compareExcelDBObj.setLastUpdatedBy(row.get(19));
                compareExcelDBObj.setLastUpdatedDateTime(row.get(20));
                compareExcelDBObj.setLastApprovedBy(row.get(21));
                compareExcelDBObj.setLastApprovedDateTime(row.get(22));
                productHistoryListExcel.add(compareExcelDBObj);

            });


            while(resultSet.next()){

                compareExcelDBObj2.setRecordStatus(Objects.toString(resultSet.getString(1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(1));
                compareExcelDBObj2.setMaintenanceStatus(Objects.toString(resultSet.getString(2), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(2));
                compareExcelDBObj2.setProductName(Objects.toString(resultSet.getString(3), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(3));
                compareExcelDBObj2.setProductCode(Objects.toString(resultSet.getString(4), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(4));
                compareExcelDBObj2.setInsurerComponentCode(Objects.toString(resultSet.getString(5), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(5));
                compareExcelDBObj2.setInsurerName(Objects.toString(resultSet.getString(6), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(6));
                compareExcelDBObj2.setInsurerCode(Objects.toString(resultSet.getString(7), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(7));
                compareExcelDBObj2.setPlanType(Objects.toString(resultSet.getString(8), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(8));
                compareExcelDBObj2.setChoiceofCover(Objects.toString(resultSet.getString(9), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(9));
                compareExcelDBObj2.setCoveragePeriodTravel(Objects.toString(resultSet.getString(10), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(10));
                compareExcelDBObj2.setTemplateName(Objects.toString(resultSet.getString(11), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(11));
                compareExcelDBObj2.setSegmentMM(Objects.toString(resultSet.getString(12), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(12));
                compareExcelDBObj2.setSegmentTR(Objects.toString(resultSet.getString(13), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(13));
                compareExcelDBObj2.setSegmentTPC(Objects.toString(resultSet.getString(14), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(14));
                compareExcelDBObj2.setSegmentPB(Objects.toString(resultSet.getString(15), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(15));
                compareExcelDBObj2.setPolicyCategory(Objects.toString(resultSet.getString(16), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(16));
                compareExcelDBObj2.setCoverageType(Objects.toString(resultSet.getString(17), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(17));
                compareExcelDBObj2.setProductCategory(Objects.toString(resultSet.getString(18), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(18));
                compareExcelDBObj2.setRemark(Objects.toString(resultSet.getString(19), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(19));
                compareExcelDBObj2.setLastUpdatedBy(Objects.toString(resultSet.getString(20), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(20));
                compareExcelDBObj2.setLastUpdatedDateTime((Objects.toString(resultSet.getString(21), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(21).substring(0,19)));
                compareExcelDBObj2.setLastApprovedBy(Objects.toString(resultSet.getString(22), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(22));
                compareExcelDBObj2.setLastApprovedDateTime((Objects.toString(resultSet.getString(23), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(23).substring(0,19)));
                

                productHistoryListDB.add(compareExcelDBObj2);

            }
            Collections.sort(productHistoryListExcel, new ProductHistory.CustomComparator());
            Collections.sort(productHistoryListDB, new ProductHistory.CustomComparator());
            System.out.println(productHistoryListExcel.toString());
            System.out.println(productHistoryListDB.toString());

            boolean identical = true;
            for (int i=0; i<productHistoryListDB.size(); i++) {
                identical = productHistoryListDB.get(i).equals(productHistoryListExcel.get(i));
                assertThat(!identical).isFalse();
                if (!identical)                	
                    System.out.println("Data between Excel and Database are NOT matched");
                break;

            }
            System.out.println("Data between Excel and Database are matched");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodProductName() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery("select RECORD_STATUS, \n" +
                    "case MAINTENANCE_INDICATOR\n" +
                    "when '01' then 'Create'\n" +
                    "when '02' then 'Update'\n" +
                    "end as MAINTENANCE_INDICATOR, PRODUCT_NAME, PRODUCT_CODE, COMPONENT_CODE,INSURER_NAME, INSURER_CODE, \n" +
                    "case PLAN_TYPE\n" +
                    "when '00' then 'Basic'\n" +
                    "when '01' then 'Rider'\n" +
                    "when '02' then 'SubFund'\n" +
                    "end as PLAN_TYPE, null AS Choice_of_Cover, null AS Coverage_Period_travel, IBMB_TEMPLATE_NAME, \n" +
                    "CUSTOMER_SEGMENT_MM, CUSTOMER_SEGMENT_TR, CUSTOMER_SEGMENT_TPC, CUSTOMER_SEGMENT_PB, POLICY_CATEGORY,\n" +
                    "COVERAGE_TYPE, PRODUCT_GROUPING, REMARKS, LAST_UPDATED_BY,LAST_UPDATED_DATE_TIME, \n" +
                    "APPROVED_BY,APPROVED_DATE_TIME\n" +
                    "from bpds.dbs_li_product_history where PRODUCT_NAME = 'HEIRLOOM (II)';");

            List<ArrayList<String>> columnListReportsExcel = ExcelHelperCommomUtils.excelReports(reportFileName);

            System.out.println("Print Excel Data reports here");

            System.out.println(columnListReportsExcel);
            System.out.println("Excel Row Count => " + columnListReportsExcel.size());

            int matchRowCount = 0;
            int columnCount = resultSet.getMetaData().getColumnCount();


            System.out.println("columnCount=====>"+columnCount);

            ProductHistory compareExcelDBObj = new ProductHistory();
            ProductHistory compareExcelDBObj2 = new ProductHistory();

            List<ProductHistory> productHistoryListExcel = new ArrayList<>();
            List<ProductHistory> productHistoryListDB = new ArrayList<>();

            columnListReportsExcel.forEach(row -> {
                compareExcelDBObj.setRecordStatus(row.get(0));
                compareExcelDBObj.setMaintenanceStatus(row.get(1));
                compareExcelDBObj.setProductName(row.get(2));
                compareExcelDBObj.setProductCode(row.get(3));
                compareExcelDBObj.setInsurerComponentCode(row.get(4));
                compareExcelDBObj.setInsurerName(row.get(5));
                compareExcelDBObj.setInsurerCode(row.get(6));
                compareExcelDBObj.setPlanType(row.get(7));
                compareExcelDBObj.setChoiceofCover(row.get(8));
                compareExcelDBObj.setCoveragePeriodTravel(row.get(9));
                compareExcelDBObj.setTemplateName(row.get(10));
                compareExcelDBObj.setSegmentMM(row.get(11));
                compareExcelDBObj.setSegmentTR(row.get(12));
                compareExcelDBObj.setSegmentTPC(row.get(13));
                compareExcelDBObj.setSegmentPB(row.get(14));
                compareExcelDBObj.setPolicyCategory(row.get(15));
                compareExcelDBObj.setCoverageType(row.get(16));
                compareExcelDBObj.setProductCategory(row.get(17));
                compareExcelDBObj.setRemark(row.get(18));
                compareExcelDBObj.setLastUpdatedBy(row.get(19));
                compareExcelDBObj.setLastUpdatedDateTime(row.get(20));
                compareExcelDBObj.setLastApprovedBy(row.get(21));
                compareExcelDBObj.setLastApprovedDateTime(row.get(22));
                productHistoryListExcel.add(compareExcelDBObj);

            });


            while(resultSet.next()){

                compareExcelDBObj2.setRecordStatus(Objects.toString(resultSet.getString(1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(1));
                compareExcelDBObj2.setMaintenanceStatus(Objects.toString(resultSet.getString(2), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(2));
                compareExcelDBObj2.setProductName(Objects.toString(resultSet.getString(3), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(3));
                compareExcelDBObj2.setProductCode(Objects.toString(resultSet.getString(4), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(4));
                compareExcelDBObj2.setInsurerComponentCode(Objects.toString(resultSet.getString(5), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(5));
                compareExcelDBObj2.setInsurerName(Objects.toString(resultSet.getString(6), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(6));
                compareExcelDBObj2.setInsurerCode(Objects.toString(resultSet.getString(7), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(7));
                compareExcelDBObj2.setPlanType(Objects.toString(resultSet.getString(8), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(8));
                compareExcelDBObj2.setChoiceofCover(Objects.toString(resultSet.getString(9), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(9));
                compareExcelDBObj2.setCoveragePeriodTravel(Objects.toString(resultSet.getString(10), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(10));
                compareExcelDBObj2.setTemplateName(Objects.toString(resultSet.getString(11), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(11));
                compareExcelDBObj2.setSegmentMM(Objects.toString(resultSet.getString(12), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(12));
                compareExcelDBObj2.setSegmentTR(Objects.toString(resultSet.getString(13), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(13));
                compareExcelDBObj2.setSegmentTPC(Objects.toString(resultSet.getString(14), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(14));
                compareExcelDBObj2.setSegmentPB(Objects.toString(resultSet.getString(15), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(15));
                compareExcelDBObj2.setPolicyCategory(Objects.toString(resultSet.getString(16), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(16));
                compareExcelDBObj2.setCoverageType(Objects.toString(resultSet.getString(17), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(17));
                compareExcelDBObj2.setProductCategory(Objects.toString(resultSet.getString(18), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(18));
                compareExcelDBObj2.setRemark(Objects.toString(resultSet.getString(19), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(19));
                compareExcelDBObj2.setLastUpdatedBy(Objects.toString(resultSet.getString(20), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(20));
                compareExcelDBObj2.setLastUpdatedDateTime((Objects.toString(resultSet.getString(21), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(21).substring(0,19)));
                compareExcelDBObj2.setLastApprovedBy(Objects.toString(resultSet.getString(22), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(22));
                compareExcelDBObj2.setLastApprovedDateTime((Objects.toString(resultSet.getString(23), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(23).substring(0,19)));
                

                productHistoryListDB.add(compareExcelDBObj2);

            }
            Collections.sort(productHistoryListExcel, new ProductHistory.CustomComparator());
            Collections.sort(productHistoryListDB, new ProductHistory.CustomComparator());
            System.out.println(productHistoryListExcel.toString());
            System.out.println(productHistoryListDB.toString());

            boolean identical = true;
            for (int i=0; i<productHistoryListDB.size(); i++) {
                identical = productHistoryListDB.get(i).equals(productHistoryListExcel.get(i));
                assertThat(!identical).isFalse();
                if (!identical)                	
                    System.out.println("Data between Excel and Database are NOT matched");
                break;

            }
            System.out.println("Data between Excel and Database are matched");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

	@Override
	public void operationMethodChannelID() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void operationMethodInsurerRecordDate() {
		try {
            // Execute a query
            stmt = conn.createStatement();
            resultSet = stmt.executeQuery("select RECORD_STATUS, \n" +
                            "case MAINTENANCE_INDICATOR\n" +
                            "when '01' then 'Create'\n" +
                            "when '02' then 'Update'\n" +
                            "end as MAINTENANCE_INDICATOR, PRODUCT_NAME, PRODUCT_CODE, COMPONENT_CODE,INSURER_NAME, INSURER_CODE, \n" +
                            "case PLAN_TYPE\n" +
                            "when '00' then 'Basic'\n" +
                            "when '01' then 'Rider'\n" +
                            "when '02' then 'SubFund'\n" +
                            "end as PLAN_TYPE, null AS Choice_of_Cover, null AS Coverage_Period_travel, IBMB_TEMPLATE_NAME, \n" +
                            "CUSTOMER_SEGMENT_MM, CUSTOMER_SEGMENT_TR, CUSTOMER_SEGMENT_TPC, CUSTOMER_SEGMENT_PB, POLICY_CATEGORY,\n" +
                            "COVERAGE_TYPE, PRODUCT_GROUPING, REMARKS, LAST_UPDATED_BY,LAST_UPDATED_DATE_TIME, \n" +
                            "APPROVED_BY,APPROVED_DATE_TIME\n" +
                            "from bpds.dbs_li_product_history where record_timestamp \n" +
                    "between '2017-09-09 00:00:00' and '2017-09-10 23:59:59';");

            List<ArrayList<String>> columnListReportsExcel = ExcelHelperCommomUtils.excelReports(reportFileName);

            System.out.println("Print Excel Data reports here");

            System.out.println(columnListReportsExcel);
            System.out.println("Excel Row Count => " + columnListReportsExcel.size());

            int matchRowCount = 0;
            int columnCount = resultSet.getMetaData().getColumnCount();


            System.out.println("columnCount=====>"+columnCount);

            ProductHistory compareExcelDBObj = new ProductHistory();
            ProductHistory compareExcelDBObj2 = new ProductHistory();

            List<ProductHistory> productHistoryListExcel = new ArrayList<>();
            List<ProductHistory> productHistoryListDB = new ArrayList<>();

            columnListReportsExcel.forEach(row -> {
                compareExcelDBObj.setRecordStatus(row.get(0));
                compareExcelDBObj.setMaintenanceStatus(row.get(1));
                compareExcelDBObj.setProductName(row.get(2));
                compareExcelDBObj.setProductCode(row.get(3));
                compareExcelDBObj.setInsurerComponentCode(row.get(4));
                compareExcelDBObj.setInsurerName(row.get(5));
                compareExcelDBObj.setInsurerCode(row.get(6));
                compareExcelDBObj.setPlanType(row.get(7));
                compareExcelDBObj.setChoiceofCover(row.get(8));
                compareExcelDBObj.setCoveragePeriodTravel(row.get(9));
                compareExcelDBObj.setTemplateName(row.get(10));
                compareExcelDBObj.setSegmentMM(row.get(11));
                compareExcelDBObj.setSegmentTR(row.get(12));
                compareExcelDBObj.setSegmentTPC(row.get(13));
                compareExcelDBObj.setSegmentPB(row.get(14));
                compareExcelDBObj.setPolicyCategory(row.get(15));
                compareExcelDBObj.setCoverageType(row.get(16));
                compareExcelDBObj.setProductCategory(row.get(17));
                compareExcelDBObj.setRemark(row.get(18));
                compareExcelDBObj.setLastUpdatedBy(row.get(19));
                compareExcelDBObj.setLastUpdatedDateTime(row.get(20));
                compareExcelDBObj.setLastApprovedBy(row.get(21));
                compareExcelDBObj.setLastApprovedDateTime(row.get(22));
                productHistoryListExcel.add(compareExcelDBObj);

            });


            while(resultSet.next()){

                compareExcelDBObj2.setRecordStatus(Objects.toString(resultSet.getString(1), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(1));
                compareExcelDBObj2.setMaintenanceStatus(Objects.toString(resultSet.getString(2), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(2));
                compareExcelDBObj2.setProductName(Objects.toString(resultSet.getString(3), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(3));
                compareExcelDBObj2.setProductCode(Objects.toString(resultSet.getString(4), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(4));
                compareExcelDBObj2.setInsurerComponentCode(Objects.toString(resultSet.getString(5), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(5));
                compareExcelDBObj2.setInsurerName(Objects.toString(resultSet.getString(6), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(6));
                compareExcelDBObj2.setInsurerCode(Objects.toString(resultSet.getString(7), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(7));
                compareExcelDBObj2.setPlanType(Objects.toString(resultSet.getString(8), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(8));
                compareExcelDBObj2.setChoiceofCover(Objects.toString(resultSet.getString(9), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(9));
                compareExcelDBObj2.setCoveragePeriodTravel(Objects.toString(resultSet.getString(10), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(10));
                compareExcelDBObj2.setTemplateName(Objects.toString(resultSet.getString(11), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(11));
                compareExcelDBObj2.setSegmentMM(Objects.toString(resultSet.getString(12), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(12));
                compareExcelDBObj2.setSegmentTR(Objects.toString(resultSet.getString(13), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(13));
                compareExcelDBObj2.setSegmentTPC(Objects.toString(resultSet.getString(14), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(14));
                compareExcelDBObj2.setSegmentPB(Objects.toString(resultSet.getString(15), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(15));
                compareExcelDBObj2.setPolicyCategory(Objects.toString(resultSet.getString(16), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(16));
                compareExcelDBObj2.setCoverageType(Objects.toString(resultSet.getString(17), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(17));
                compareExcelDBObj2.setProductCategory(Objects.toString(resultSet.getString(18), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(18));
                compareExcelDBObj2.setRemark(Objects.toString(resultSet.getString(19), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(19));
                compareExcelDBObj2.setLastUpdatedBy(Objects.toString(resultSet.getString(20), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(20));
                compareExcelDBObj2.setLastUpdatedDateTime((Objects.toString(resultSet.getString(21), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(21).substring(0,19)));
                compareExcelDBObj2.setLastApprovedBy(Objects.toString(resultSet.getString(22), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(22));
                compareExcelDBObj2.setLastApprovedDateTime((Objects.toString(resultSet.getString(23), "null").equalsIgnoreCase("null") ? "" : resultSet.getString(23).substring(0,19)));
                

                productHistoryListDB.add(compareExcelDBObj2);

            }
            Collections.sort(productHistoryListExcel, new ProductHistory.CustomComparator());
            Collections.sort(productHistoryListDB, new ProductHistory.CustomComparator());
            System.out.println(productHistoryListExcel.toString());
            System.out.println(productHistoryListDB.toString());

            boolean identical = true;
            for (int i=0; i<productHistoryListDB.size(); i++) {
                identical = productHistoryListDB.get(i).equals(productHistoryListExcel.get(i));
                assertThat(!identical).isFalse();
                if (!identical)                	
                    System.out.println("Data between Excel and Database are NOT matched");
                break;

            }
            System.out.println("Data between Excel and Database are matched");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
		
	}

}
