package tests;

import java.io.IOException;
import java.sql.SQLException;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;

import com.dbs.bpds.configs.Constants;
import com.dbs.bpds.configs.Utils;
import com.dbs.bpds.jira.ConnectToJIRAUserStories;
import com.dbs.bpds.pagefactory.PageStepFactory;
import com.dbs.bpds.steps.CinChangeUpdateReportPage_Steps;
import com.dbs.bpds.steps.CisProductUpdateReport_Steps;
import com.dbs.bpds.steps.InvalidCinExceptionReportPage_Step;
import com.dbs.bpds.steps.LandingPage_Steps;
import com.dbs.bpds.steps.LoginPage_Steps;
import com.dbs.bpds.steps.ProductApprovedPage_Steps;
import com.dbs.bpds.steps.ProductAuditTrailReportPage_Steps;
import com.dbs.bpds.steps.ProductCancelledPage_Steps;
import com.dbs.bpds.steps.ProductGroupExceptionReportPage_Steps;
import com.dbs.bpds.steps.CustomerHoldings_Enquiry_Page_Steps;

import net.thucydides.core.annotations.Steps;

public class BPDSTest extends ConnectToJIRAUserStories {

	@Steps
	private LoginPage_Steps loginPagesteps = PageStepFactory.getInstance().getLoginPageSteps();
	private LandingPage_Steps landingPageSteps = PageStepFactory.getInstance().getLandingPageSteps();
	private InvalidCinExceptionReportPage_Step invalidCinExceptionReportPageStep = PageStepFactory.getInstance().getInvalidCinExceptionReportPage();
	private CinChangeUpdateReportPage_Steps cinChangeUpdateReportSteps = PageStepFactory.getInstance().getCINChangeUpdateReportsPage();
	private CisProductUpdateReport_Steps cisProductUpdateReportSteps = PageStepFactory.getInstance().getCisProductUpdateReportSteps();
	private ProductGroupExceptionReportPage_Steps prdtGrpExceptReportSteps = PageStepFactory.getInstance().getPrdtGroupExceptionReportSteps();
	private ProductAuditTrailReportPage_Steps productAuditTrailReportSteps = PageStepFactory.getInstance().getProductAuditTrailReportPage_Steps();
	private CustomerHoldings_Enquiry_Page_Steps custHoldEnquiryPageSteps = PageStepFactory.getInstance().getCusotmerHoldingEnquiryPage();
	private ProductApprovedPage_Steps productApprovedPageSteps = PageStepFactory.getInstance().getProductApprovedPage();
	private ProductCancelledPage_Steps productCancelledPageSteps = PageStepFactory.getInstance().getProductCancelledPage();
			
	public String actual_message, username,password; 
	/*
	 * 
	 * 
	 * START OF BPDS-31
	 * 
	 * 
	 */
	
	@Given("Admin user is able to login to application successfully")
	public void givenAdminUserIsAbleToLoginToApplicationSuccessfully() throws Exception{
		loginPagesteps.launchApplication();
		loginPagesteps.login(Constants.USERNAME, Constants.PASSWORD);
	}
	
	@When("Admin user traverse for Invalid CIN report filter page")
	public void whenAdminUserTraverseForInvalidCINReportFilterPage() {
		landingPageSteps.verifyCustomerHoldingsModule_landingPage();		  
	}
	
	@Then("Admin user should land in Invalid CIN report filter page")
	public void thenAdminUserShouldLandInInvalidCINReportFilterPage() {
		invalidCinExceptionReportPageStep.chkInvalidCINReportPage();
	  
	}
	@Then("Verify static text displayed in the Invalid CIN report filter page")
	public void thenVerifyStaticTextDisplayedInTheInvalidCINReportFilterPage() {
		invalidCinExceptionReportPageStep.chkFillcriteriaStaticText();
	}
	@Given("Admin user on the Invalid CIN report filter page")
	public void givenAdminUserOnTheInvalidCINReportFilterPage() {
		invalidCinExceptionReportPageStep.resetInvalidCINReportPage();
	}

	@Then("Verify Export button is disabled by default in the Invalid CIN report filter page")
	public void thenVerifyExportButtonIsDisabledByDefaultInTheInvalidCINReportFilterPage() {
		invalidCinExceptionReportPageStep.chkExportBtnISDisabled();
	}

	@When("Insurer Name alone selected in the Invalid CIN report filter")
	public void whenInsurerNameAloneSelectedInTheInvalidCINReportFilter() {
		invalidCinExceptionReportPageStep.selectInvalidCinInsurerNameReports();
	}

	@Then("Verify Export button is enabled in the Invalid CIN report filter")
	public void thenVerifyExportButtonIsEnabledInTheInvalidCINReportFilter() {
		invalidCinExceptionReportPageStep.chkExportBtnISEnabled();
	}

	@Then("Download and verify the Invalid CIN report file name")
	public void thenDownloadAndVerifyTheInvalidCINReportFileName() throws InterruptedException {
		invalidCinExceptionReportPageStep.clickExportButtonReports();
		invalidCinExceptionReportPageStep.verifyDownloadInvalidCinReportFilename();
	}

	@Then("Validate excel reports against DataBase Results for insurer name entered in the Invalid CIN Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerNameEnteredInTheInvalidCINReportFilterPage() throws ClassNotFoundException, SQLException {
		invalidCinExceptionReportPageStep.validateExcelDBInValidCINReportsInsurerName();
	}	

	@When("<productName> alone selected in the Invalid CIN report filter")
	public void whenproductNameAloneSelectedInTheInvalidCINReportFilter(@Named("productName") String productName) {
		invalidCinExceptionReportPageStep.enterInvalidReportProductName(productName);
	}

	@Then("Validate excel reports against DataBase Results for product name entered in the Invalid CIN Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForProductNameEnteredInTheInvalidCINReportFilterPage() throws ClassNotFoundException, SQLException {
		invalidCinExceptionReportPageStep.validateExcelDBInValidCINReportsProductName();
	}	

	@When("<insurerOwnerCIN> alone selected in the Invalid CIN report filter")
	public void wheninsurerOwnerCINAloneSelectedInTheInvalidCINReportFilter(@Named("insurerOwnerCIN") String insurerOwnerCIN) {
		invalidCinExceptionReportPageStep.enterInvalidReportInsurerOwnerCIN(insurerOwnerCIN);
	}
	

	@Then("Validate excel reports against DataBase Results for Insurer Owner CIN entered in the Invalid CIN Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerOwnerCINEnteredInTheInvalidCINReportFilterPage() throws ClassNotFoundException, SQLException {
		invalidCinExceptionReportPageStep.validateExcelDBInValidCINReportsInsurerOwnerCIN();
	}
	

	@When("<insurerOwnerName> alone selected in the Invalid CIN report filter")
	public void wheninsurerOwnerNameAloneSelectedInTheInvalidCINReportFilter(@Named("insurerOwnerName") String insurerOwnerName) {
		invalidCinExceptionReportPageStep.enterInvalidReportInsurerOwnerName(insurerOwnerName);
	}
	

	@Then("Validate excel reports against DataBase Results for Insurer Owner Name entered in the Invalid CIN Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerOwnerNameEnteredInTheInvalidCINReportFilterPage() throws ClassNotFoundException, SQLException {
		invalidCinExceptionReportPageStep.validateExcelDBInValidCINReportsInsurerName();
	}


	@When("Channel ID alone selected in the Invalid CIN report filter")
	public void whenChannelIDAloneSelectedInTheInvalidCINReportFilter() throws InterruptedException {
		invalidCinExceptionReportPageStep.selectInvalidReportChannelId();
	}
	

	@Then("Validate excel reports against DataBase Results for Channel ID selected in the Invalid CIN Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForChannelIDSelectedInTheInvalidCINReportFilterPage() throws ClassNotFoundException, SQLException {
		invalidCinExceptionReportPageStep.validateExcelDBInValidCINReportsChannelID();
	}
	

	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> alone selected in the Invalid CIN report filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAloneSelectedInTheInvalidCINReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) throws IOException {
		invalidCinExceptionReportPageStep.selectInvalidReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}

	@Then("Validate excel reports against DataBase Results for Insurer Record Date entered in the Invalid CIN Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerRecordDateEnteredInTheInvalidCINReportFilterPage() throws ClassNotFoundException, SQLException {
		invalidCinExceptionReportPageStep.validateExcelDBInValidCINReportsInsurerRecordReceivedDate();
	}
	

	@When("Insurer Name is selected in the Invalid CIN report filter")
	public void whenInsurerNameIsSelectedInTheInvalidCINReportFilter() {
		invalidCinExceptionReportPageStep.selectInvalidCinInsurerNameReports();
	}

	@When("<productName> is entered in the Invalid CIN report filter")
	public void whenproductNameIsEnteredInTheInvalidCINReportFilter(@Named("productName") String productName) {
		invalidCinExceptionReportPageStep.enterInvalidReportProductName(productName);
	}

	@When("<insurerOwnerCIN> is entered in the Invalid CIN report filter")
	public void wheninsurerOwnerCINIsEnteredInTheInvalidCINReportFilter(@Named("insurerOwnerCIN") String insurerOwnerCIN) {
		invalidCinExceptionReportPageStep.enterInvalidReportInsurerOwnerCIN(insurerOwnerCIN);
	}

	@When("<insurerOwnerName> is entered in the Invalid CIN report filter")
	public void wheninsurerOwnerNameIsEnteredInTheInvalidCINReportFilter(@Named("insurerOwnerName") String insurerOwnerName) {
		invalidCinExceptionReportPageStep.enterInvalidReportInsurerOwnerName(insurerOwnerName);
	}

	@When("Channel ID is entered in the Invalid CIN report filter")
	public void whenChannelIDIsEnteredInTheInvalidCINReportFilter() throws InterruptedException {
		invalidCinExceptionReportPageStep.selectInvalidReportChannelId();
	}

	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are entered in the Invalid CIN report filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreEnteredInTheInvalidCINReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) throws IOException {
		invalidCinExceptionReportPageStep.selectInvalidReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	

	@Then("Validate excel reports against DataBase Results for all valid values entered in the Invalid CIN Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForAllValidValuesEnteredInTheInvalidCINReportFilterPage() throws ClassNotFoundException, SQLException {
		invalidCinExceptionReportPageStep.validateExcelDBInValidCINReportAllValidInput();
	}

	@When("Invalid <productName> is entered in the Invalid CIN report filter")
	public void whenInvalidproductNameIsEnteredInTheInvalidCINReportFilter(@Named("productName") String productName) {
		invalidCinExceptionReportPageStep.enterInvalidReportProductName(productName);
	}

	@When("Invalid <insurerOwnerCIN> is entered in the Invalid CIN report filter")
	public void whenInvalidinsurerOwnerCINIsEnteredInTheInvalidCINReportFilter(@Named("insurerOwnerCIN") String insurerOwnerCIN) {
		invalidCinExceptionReportPageStep.enterInvalidReportInsurerOwnerCIN(insurerOwnerCIN);
	}

	@When("Invalid <insurerOwnerName> is entered in the Invalid CIN report filter")
	public void whenInvalidinsurerOwnerNameIsEnteredInTheInvalidCINReportFilter(@Named("insurerOwnerName") String insurerOwnerName) {
		invalidCinExceptionReportPageStep.enterInvalidReportInsurerOwnerName(insurerOwnerName);
	}


	@When("Invalid <insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are entered in the Invalid CIN report filter")
	public void whenInvalidinsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreEnteredInTheInvalidCINReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) throws IOException {
		invalidCinExceptionReportPageStep.selectInvalidReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}

	@Then("Click on Export and verify error message is displayed in Invalid CIN report filter page")
	public void thenClickOnExportAndVerifyErrorMessageIsDisplayedInInvalidCINReportFilterPage() throws InterruptedException {
		invalidCinExceptionReportPageStep.clickExportButtonReports();
		invalidCinExceptionReportPageStep.verifyNoRecordFound();
		Utils.driver.quit();
	}
	
	/*
	 * 
	 * 
	 * END OF BPDS-31
	 * 
	 * 
	 */
	
	/*
	 * 
	 * 
	 * START OF BPDS-32
	 * 
	 * 
	 */
	
	@When("Admin user traverse to CIN Change Update report filter page")
	public void whenAdminUserTraverseToCINChangeUpdateReportFilterPage() {
		landingPageSteps.verifyCustomerHoldingsModule_landingPage();
				  
	}
	@Then("Admin user should land in CIN Change Update report filter page")
	public void thenAdminUserShouldLandInCINChangeUpdateReportFilterPage() {
		cinChangeUpdateReportSteps.launchCINChangeUpdateReportPage();		
	}
	
	@Then("Verify static text displayed in the cin change update report page")
	public void thenVerifyStaticTextDisplayedInTheCinChangeUpdateReportPage() {
		cinChangeUpdateReportSteps.chkFillcriteriaStaticText();
	}
	
	@Given("Admin user is on CIN Change Update report filter page")
	public void givenAdminUserIsOnCINChangeUpdateReportFilterPage() {
		cinChangeUpdateReportSteps.resetCINChangeUpdateReportPage();
	}
	
	@Then("Verify Export button is disabled by default in cin change filter page")
	public void thenVerifyExportButtonIsDisabledByDefaultInCinChangeFilterPage() {
		cinChangeUpdateReportSteps.chkExportBtnISDisabled();
	}	

	@When("Insurer Name alone selected in the cin update filter")
	public void whenInsurerNameAloneSelectedInTheCinUpdateFilter() {
		cinChangeUpdateReportSteps.selectCinUpdateReportInsurerName();
	}

	@Then("Verify Export button is enabled in cin change filter page")
	public void thenVerifyExportButtonIsEnabledInCinChangeFilterPage() {
		cinChangeUpdateReportSteps.chkExportBtnISEnabled();
	}
	
	@Then("Download and verify the CIN Change update report file name")
	public void thenDownloadAndVerifyTheCINChangeUpdateReportFileName() throws InterruptedException {
		cinChangeUpdateReportSteps.clickExportButtonReports();
		cinChangeUpdateReportSteps.verifyDownloadCINChangeUpdateReportFilename();
	}
	
	@Then("Validate excel reports against DataBase Results for insurer name entered in the cin change filter")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerNameEnteredInTheCinChangeFilter() throws ClassNotFoundException, SQLException {
		cinChangeUpdateReportSteps.validateExcelDBCinUpdateReportsInsurerName();
		
	}
	
	@When("<productName> alone entered in the cin update filter")
	public void whenproductNameAloneEnteredInTheCinUpdateFilter(@Named("productName") String productName) {
		cinChangeUpdateReportSteps.enterCinUpdateReportProductName(productName);
	}
	
	@Then("Validate excel reports against DataBase Results for product name entered in the cin change filter")
	public void thenValidateExcelReportsAgainstDataBaseResultsForProductNameEnteredInTheCinChangeFilter() throws ClassNotFoundException, SQLException {
		cinChangeUpdateReportSteps.validateExcelDBCinUpdateReportsProductName();
	}
	
	@When("<insurerOwnerCIN> alone entered in the cin update filter")
	public void wheninsurerOwnerCINAloneEnteredInTheCinUpdateFilter(@Named("insurerOwnerCIN") String insurerOwnerCIN) {
		cinChangeUpdateReportSteps.enterCinUpdateReportInsurerOwnerCIN(insurerOwnerCIN);
	}
	
	@Then("Validate excel reports against DataBase Results for Insurer Owner CIN entered in the cin change filter")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerOwnerCINEnteredInTheCinChangeFilter() throws ClassNotFoundException, SQLException {
		cinChangeUpdateReportSteps.validateExcelDBCinUpdateReportsInsurerOwnerCIN();
	}
	
	@When("<insurerOwnerName> alone entered in the cin update filter")
	public void wheninsurerOwnerNameAloneEnteredInTheCinUpdateFilter(@Named("insurerOwnerName") String insurerOwnerName) {
		cinChangeUpdateReportSteps.enterCinUpdateReportInsurerOwnerName(insurerOwnerName);
	}
	
	@Then("Validate excel reports against DataBase Results for Insurer Owner Name entered in the cin change filter")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerOwnerNameEnteredInTheCinChangeFilter() throws ClassNotFoundException, SQLException {
		cinChangeUpdateReportSteps.validateExcelDBCinUpdateReportsInsurerName();
	}
	
	@When("<dbsOwnerCin> alone entered in the cin update filter")
	public void whendbsOwnerCinAloneEnteredInTheCinUpdateFilter(@Named("dbsOwnerCin") String dbsOwnerCin) {
		cinChangeUpdateReportSteps.enterCinUpdateReportDBSOwnerCin(dbsOwnerCin);
	}
	
	@Then("Validate excel reports against DataBase Results for DBS Owner CIN entered in the cin change filter")
	public void thenValidateExcelReportsAgainstDataBaseResultsForDBSOwnerCINEnteredInTheCinChangeFilter() throws ClassNotFoundException, SQLException {
		cinChangeUpdateReportSteps.validateExcelDBCinUpdateReportsDBSOwnerCIN();
	}
	
	@When("Channel ID alone entered in the cin update filter")
	public void whenChannelIDAloneEnteredInTheCinUpdateFilter() {
		cinChangeUpdateReportSteps.selectCinUpdateReportChannelId();
	}

	@Then("Validate excel reports against DataBase Results for Channel ID entered in the cin change filter")
	public void thenValidateExcelReportsAgainstDataBaseResultsForChannelIDEnteredInTheCinChangeFilter() throws ClassNotFoundException, SQLException {
		cinChangeUpdateReportSteps.validateExcelDBCinUpdateReportsChannelID();
	}
	
	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> alone entered in the cin update filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAloneEnteredInTheCinUpdateFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) throws IOException {
		cinChangeUpdateReportSteps.selectCinUpdateReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	
	@Then("Validate excel reports against DataBase Results for Insurer Record Date entered in the cin change filter")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerRecordDateEnteredInTheCinChangeFilter() throws ClassNotFoundException, SQLException {
		cinChangeUpdateReportSteps.validateExcelDBCinUpdateReportsInsurerRecordDate();
	}
	
	@When("Insurer Name is selected in the cin update filter")
	public void whenInsurerNameIsSelectedInTheCinUpdateFilter() {
		cinChangeUpdateReportSteps.selectCinUpdateReportInsurerName();
	}

	@When("<productName> is entered in the cin update filter")
	public void whenproductNameIsEnteredInTheCinUpdateFilter(@Named("productName") String productName) {
		cinChangeUpdateReportSteps.enterCinUpdateReportProductName(productName);
	}

	@When("<insurerOwnerCIN> is entered in the cin update filter")
	public void wheninsurerOwnerCINIsEnteredInTheCinUpdateFilter(@Named("insurerOwnerCIN") String insurerOwnerCIN) {
		cinChangeUpdateReportSteps.enterCinUpdateReportInsurerOwnerCIN(insurerOwnerCIN);
	}

	@When("<insurerOwnerName> is entered in the cin update filter")
	public void wheninsurerOwnerNameIsEnteredInTheCinUpdateFilter(@Named("insurerOwnerName") String insurerOwnerName) {
		cinChangeUpdateReportSteps.enterCinUpdateReportInsurerOwnerName(insurerOwnerName);
	}

	@When("<dbsOwnerCin> is entered in the cin update filter")
	public void whendbsOwnerCinIsEnteredInTheCinUpdateFilter(@Named("dbsOwnerCin") String dbsOwnerCin) {
		cinChangeUpdateReportSteps.enterCinUpdateReportDBSOwnerCin(dbsOwnerCin);
	}

	@When("Channel ID is entered in the cin update filter")
	public void whenChannelIDIsEnteredInTheCinUpdateFilter() {
		cinChangeUpdateReportSteps.selectCinUpdateReportChannelId();
	}

	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are entered in the cin update filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreEnteredInTheCinUpdateFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) throws IOException {
		cinChangeUpdateReportSteps.selectCinUpdateReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	
	@Then("Validate excel reports against DataBase Results for all valid values entered in the cin change filter")
	public void thenValidateExcelReportsAgainstDataBaseResultsForAllValidValuesEnteredInTheCinChangeFilter() throws ClassNotFoundException, SQLException {
		cinChangeUpdateReportSteps.validateExcelDBCinUpdateReportsAllValidInput();
	}
	
	@When("Insurer Name is selected in the cin change filter")
	public void whenInsurerNameIsSelectedInTheCinChangeFilter() {
		cinChangeUpdateReportSteps.selectCinUpdateReportInsurerName();
	}

	@When("Invalid <productName> is entered in the cin change filter")
	public void whenInvalidproductNameIsEnteredInTheCinChangeFilter(@Named("productName") String productName) {
		cinChangeUpdateReportSteps.enterCinUpdateReportProductName(productName);
	}

	@When("Invalid <insurerOwnerCIN> is entered in the cin change filter")
	public void whenInvalidinsurerOwnerCINIsEnteredInTheCinChangeFilter(@Named("insurerOwnerCIN") String insurerOwnerCIN) {
		cinChangeUpdateReportSteps.enterCinUpdateReportInsurerOwnerCIN(insurerOwnerCIN);
	}

	@When("Invalid <insurerOwnerName> is entered in the cin change filter")
	public void whenInvalidinsurerOwnerNameIsEnteredInTheCinChangeFilter(@Named("insurerOwnerName") String insurerOwnerName) {
		cinChangeUpdateReportSteps.enterCinUpdateReportInsurerOwnerName(insurerOwnerName);
	}

	@When("Invalid <dbsOwnerCin> is entered in the cin change filter")
	public void whenInvaliddbsOwnerCinIsEnteredInTheCinChangeFilter(@Named("dbsOwnerCin") String dbsOwnerCin) {
		cinChangeUpdateReportSteps.enterCinUpdateReportDBSOwnerCin(dbsOwnerCin);
	}

	@When("Channel ID is entered in the cin change filter")
	public void whenChannelIDIsEnteredInTheCinChangeFilter() {
		cinChangeUpdateReportSteps.selectCinUpdateReportChannelId();
	}

	@When("Invalid <insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are entered in the cin change filter")
	public void whenInvalidinsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreEnteredInTheCinChangeFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) throws IOException {
		cinChangeUpdateReportSteps.selectCinUpdateReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	
	@Then("Click on Export and verify error message is displayed in CIN Change Update report filter page")
	public void thenClickOnExportAndVerifyErrorMessageIsDisplayedInCINChangeUpdateReportFilterPage() throws InterruptedException {
		cinChangeUpdateReportSteps.clickExportButtonReports();
		cinChangeUpdateReportSteps.verifyNoRecordFound();
		Utils.driver.quit();
	}
	
	/*
	 * 
	 * 
	 * END OF BPDS-32
	 * 
	 * 
	 */
	
	/*
	 * 
	 * START OF BPDS-33
	 * 
	 */
	
	@When("Admin user traverse for Product Grouping Exception report filter page")
	public void whenAdminUserTraverseForProductGroupingExceptionReportFilterPage() {
		landingPageSteps.verifyCustomerHoldingsModule_landingPage();
	}

	@Then("Admin user should land in Product Grouping Exception report filter page")
	public void thenAdminUserShouldLandInProductGroupingExceptionReportFilterPage() {
		prdtGrpExceptReportSteps.launchPrdtGroupExceptionReportPage();
	}

	@Then("Verify static text displayed in the Product Grouping Exception report filter page")
	public void thenVerifyStaticTextDisplayedInTheProductGroupingExceptionReportFilterPage() {
		prdtGrpExceptReportSteps.chkFillcriteriaStaticText();
	}
	
	@Given("Admin user on the Product Grouping Exception report filter page")
	public void givenAdminUserOnTheProductGroupingExceptionReportFilterPage() {
		prdtGrpExceptReportSteps.resetPrdtGroupExceptionReportPage();
	}

	@Then("Verify Export button is disabled by default in the Product Grouping Exception filter page")
	public void thenVerifyExportButtonIsDisabledByDefaultInTheProductGroupingExceptionFilterPage() {
		prdtGrpExceptReportSteps.chkExportBtnISDisabled();
	}

	@When("Insurer Name alone selected in the Product Grouping Exception report filter")
	public void whenInsurerNameAloneSelectedInTheProductGroupingExceptionReportFilter() {
		prdtGrpExceptReportSteps.selectPrdtGroupExceptionReportInsurerName();
	}

	@Then("Verify Export button is enabled in the Product Grouping Exception report filter")
	public void thenVerifyExportButtonIsEnabledInTheProductGroupingExceptionReportFilter() {
		prdtGrpExceptReportSteps.chkExportBtnISEnabled();
	}

	@Then("Download and verify the Product Grouping Exception report file name")
	public void thenDownloadAndVerifyTheProductGroupingExceptionReportFileName() throws InterruptedException {
		prdtGrpExceptReportSteps.clickExportButtonReports();
		prdtGrpExceptReportSteps.verifyDownloadPrdtGroupExceptionReportFilename();
	}

	@Then("Validate excel reports against DataBase Results for insurer name entered in the Product Grouping Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerNameEnteredInTheProductGroupingExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		prdtGrpExceptReportSteps.validateExcelDBPrdtGroupExceptionReportInsurerName();
	}
	

	@When("<productCode> alone selected in the Product Grouping Exception report filter")
	public void whenproductCodeAloneSelectedInTheProductGroupingExceptionReportFilter(@Named("productCode") String productCode) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportProductCode(productCode);
	}
	

	@Then("Validate excel reports against DataBase Results for product code entered in the Product Grouping Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForProductCodeEnteredInTheProductGroupingExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		prdtGrpExceptReportSteps.validateExcelDBPrdtGroupExceptionReportProductCode();
	}

	@When("<insurerComponentCode> alone selected in the Product Grouping Exception report filter")
	public void wheninsurerComponentCodeAloneSelectedInTheProductGroupingExceptionReportFilter(@Named("insurerComponentCode") String insurerComponentCode) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportInsurerComponentCode(insurerComponentCode);
	}
	

	@Then("Validate excel reports against DataBase Results for insurer component code entered in the Product Grouping Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerComponentCodeEnteredInTheProductGroupingExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		prdtGrpExceptReportSteps.validateExcelDBPrdtGroupExceptionReportInsurerComponentCode();
	}
	

	@When("<productName> alone selected in the Product Grouping Exception report filter")
	public void whenproductNameAloneSelectedInTheProductGroupingExceptionReportFilter(@Named("productName") String productName) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportProductName(productName);
	}

	@Then("Validate excel reports against DataBase Results for productName entered in the Product Grouping Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForProductNameEnteredInTheProductGroupingExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		prdtGrpExceptReportSteps.validateExcelDBPrdtGroupExceptionReportProductName();
	}
	

	@When("Channel Id alone selected in the Product Grouping Exception report filter")
	public void whenChannelIdAloneSelectedInTheProductGroupingExceptionReportFilter() throws InterruptedException {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportChannelId();
	}
	

	@Then("Validate excel reports against DataBase Results for channel id entered in the Product Grouping Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForChannelIdEnteredInTheProductGroupingExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		prdtGrpExceptReportSteps.validateExcelDBPrdtGroupExceptionReportChannelId();
	}
	

	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> alone selected in the Product Grouping Exception report filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAloneSelectedInTheProductGroupingExceptionReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	

	@Then("Validate excel reports against DataBase Results for Insurer Record Date entered in the Product Grouping Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerRecordDateEnteredInTheProductGroupingExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		prdtGrpExceptReportSteps.validateExcelDBPrdtGroupExceptionReportInsurerRecordDate();
	}
	

	@When("Insurer Name is selected in the Product Grouping Exception report filter")
	public void whenInsurerNameIsSelectedInTheProductGroupingExceptionReportFilter() {
		prdtGrpExceptReportSteps.selectPrdtGroupExceptionReportInsurerName();
	}

	@When("<productCode> is entered in the Product Grouping Exception report filter")
	public void whenproductCodeIsEnteredInTheProductGroupingExceptionReportFilter(@Named("productCode") String productCode) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportProductCode(productCode);
	}

	@When("<insurerComponentCode> is entered in the Product Grouping Exception report filter")
	public void wheninsurerComponentCodeIsEnteredInTheProductGroupingExceptionReportFilter(@Named("insurerComponentCode") String insurerComponentCode) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportInsurerComponentCode(insurerComponentCode);
	}

	@When("<productName> is entered in the Product Grouping Exception report filter")
	public void whenproductNameIsEnteredInTheProductGroupingExceptionReportFilter(@Named("productName") String productName) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportProductName(productName);
	}

	@When("Channel ID is entered in the Product Grouping Exception report filter")
	public void whenChannelIDIsEnteredInTheProductGroupingExceptionReportFilter() throws InterruptedException {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportChannelId();
	}

	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are entered in the Product Grouping Exception report filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreEnteredInTheProductGroupingExceptionReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	

	@Then("Validate excel reports against DataBase Results for all valid values entered in the Product Grouping Exception report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForAllValidValuesEnteredInTheProductGroupingExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		prdtGrpExceptReportSteps.validateExcelDBPrdtGroupExceptionReportAllValidInput();
	}
	

	@When("Invalid <productCode> is entered in the Product Grouping Exception report filter")
	public void whenInvalidproductCodeIsEnteredInTheProductGroupingExceptionReportFilter(@Named("productCode") String productCode) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportProductCode(productCode);
	}

	@When("Invalid <insurerComponentCode> is entered in the Product Grouping Exception report filter")
	public void whenInvalidinsurerComponentCodeIsEnteredInTheProductGroupingExceptionReportFilter(@Named("insurerComponentCode") String insurerComponentCode) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportInsurerComponentCode(insurerComponentCode);
	}

	@When("Invalid <productName> is entered in the Product Grouping Exception report filter")
	public void whenInvalidproductNameIsEnteredInTheProductGroupingExceptionReportFilter(@Named("productName") String productName) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportProductName(productName);
	}


	@When("Invalid <insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are entered in the Product Grouping Exception report filter")
	public void whenInvalidinsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreEnteredInTheProductGroupingExceptionReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) {
		prdtGrpExceptReportSteps.enterPrdtGroupExceptionReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}

	@Then("Click on Export and verify error message is displayed in Product Grouping Exception report filter page")
	public void thenClickOnExportAndVerifyErrorMessageIsDisplayedInProductGroupingExceptionReportFilterPage() throws InterruptedException {
		prdtGrpExceptReportSteps.clickExportButtonReports();
		prdtGrpExceptReportSteps.verifyNoRecordFound();
		Utils.driver.quit();
	}
	
	/*
	 * 
	 * 
	 * END OF BPDS-33
	 * 
	 * 
	 */
	
	
	
	/*
	 * 
	 * 
	 * START OF BPDS-34
	 * 
	 * 
	 */
	
	
	@When("Admin user traverse for CIS PRDT Update report filter page")
	public void whenAdminUserTraverseForCISPRDTUpdateReportFilterPage() {
		landingPageSteps.verifyCustomerHoldingsModule_landingPage();
	}

	@Then("Admin user should land in CIS PRDT Update Exception report filter page")
	public void thenAdminUserShouldLandInCISPRDTUpdateExceptionReportFilterPage() {
		cisProductUpdateReportSteps.launchCisPrdtUpdateReportPage();
	}

	@Then("Verify static text displayed in the CIS PRDT Update Exception report filter page")
	public void thenVerifyStaticTextDisplayedInTheCISPRDTUpdateExceptionReportFilterPage() {
		cisProductUpdateReportSteps.chkFillcriteriaStaticText();
	}
	
	@Then("Verify Export button is disabled by default in the CIS PRDT Update Exception filter page")
	public void thenVerifyExportButtonIsDisabledByDefaultInTheCISPRDTUpdateExceptionFilterPage() {
		cisProductUpdateReportSteps.chkExportBtnISDisabled();
	}
	
	@Given("Admin user on the CIS PRDT Update Exception report filter page")
	public void givenAdminUserOnTheCISPRDTUpdateExceptionReportFilterPage() {
		cisProductUpdateReportSteps.resetCisPrdtUpdateReportPage();
	}
	
	@When("Insurer Name alone selected in the CIS PRDT Update Exception report filter")
	public void whenInsurerNameAloneSelectedInTheCISPRDTUpdateExceptionReportFilter() {
		cisProductUpdateReportSteps.selectCisPrdtUpdateReportInsurerName();
	}

	@Then("Verify Export button is enabled in the CIS PRDT Update Exception report filter")
	public void thenVerifyExportButtonIsEnabledInTheCISPRDTUpdateExceptionReportFilter() {
		cisProductUpdateReportSteps.chkExportBtnISEnabled();
	}

	@Then("Download and verify the CIS PRDT Update Exception report file name")
	public void thenDownloadAndVerifyTheCISPRDTUpdateExceptionReportFileName() throws InterruptedException {
		cisProductUpdateReportSteps.clickExportButtonReports();
		cisProductUpdateReportSteps.verifyDownloadCisPrdtUpdateReportFilename();
	}
	
	@Then("Validate excel reports against DataBase Results for insurer name entered in the CIS PRDT Update Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerNameEnteredInTheCISPRDTUpdateExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		cisProductUpdateReportSteps.validateExcelDBCisPrdtUpdateReportInsurerName();
	}
	
	@When("<productCode> alone selected in the CIS PRDT Update Exception report filter")
	public void whenproductCodeAloneSelectedInTheCISPRDTUpdateExceptionReportFilter(@Named("productCode") String productCode) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportProductCode(productCode);
	}
	
	@Then("Validate excel reports against DataBase Results for product code entered in the CIS PRDT Update Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForProductCodeEnteredInTheCISPRDTUpdateExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		cisProductUpdateReportSteps.validateExcelDBCisPrdtUpdateReportProductCode();
	}
	
	@When("<insurerComponentCode> alone selected in the CIS PRDT Update Exception report filter")
	public void wheninsurerComponentCodeAloneSelectedInTheCISPRDTUpdateExceptionReportFilter(@Named("insurerComponentCode") String insurerComponentCode) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportInsurerComponentCode(insurerComponentCode);
	}
	
	@Then("Validate excel reports against DataBase Results for insurer component code entered in the CIS PRDT Update Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerComponentCodeEnteredInTheCISPRDTUpdateExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		cisProductUpdateReportSteps.validateExcelDBCisPrdtUpdateReportInsurerComponentCode();
	}
	
	@When("<productName> alone selected in the CIS PRDT Update Exception report filter")
	public void whenproductNameAloneSelectedInTheCISPRDTUpdateExceptionReportFilter(@Named("productName") String productName) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportProductName(productName);
	}
	
	@Then("Validate excel reports against DataBase Results for product name entered in the CIS PRDT Update Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForProductNameEnteredInTheCISPRDTUpdateExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		cisProductUpdateReportSteps.validateExcelDBCisPrdtUpdateReportProductName();
	}
	
	@When("Channel Id alone selected in the CIS PRDT Update Exception report filter")
	public void whenChannelIdAloneSelectedInTheCISPRDTUpdateExceptionReportFilter() throws InterruptedException {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportChannelId();
	}
	
	@Then("Validate excel reports against DataBase Results for channel id entered in the CIS PRDT Update Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForChannelIdEnteredInTheCISPRDTUpdateExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		cisProductUpdateReportSteps.validateExcelDBCisPrdtUpdateReportChannelId();
	}

	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> alone selected in the CIS PRDT Update Exception report filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAloneSelectedInTheCISPRDTUpdateExceptionReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	
	@Then("Validate excel reports against DataBase Results for Insurer Record Date entered in the CIS PRDT Update Exception Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerRecordDateEnteredInTheCISPRDTUpdateExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		cisProductUpdateReportSteps.validateExcelDBCisPrdtUpdateReportInsurerRecordDate();
	}
	
	@When("Insurer Name is selected in the CIS PRDT Update Exception report filter")
	public void whenInsurerNameIsSelectedInTheCISPRDTUpdateExceptionReportFilter() {
		cisProductUpdateReportSteps.selectCisPrdtUpdateReportInsurerName();
	}
	
	@When("<productCode> is entered in the CIS PRDT Update Exception report filter")
	public void whenproductCodeIsEnteredInTheCISPRDTUpdateExceptionReportFilter(@Named("productCode") String productCode) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportProductCode(productCode);
	}
	
	@When("<insurerComponentCode> is entered in the CIS PRDT Update Exception report filter")
	public void wheninsurerComponentCodeIsEnteredInTheCISPRDTUpdateExceptionReportFilter(@Named("insurerComponentCode") String insurerComponentCode) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportInsurerComponentCode(insurerComponentCode);
	}
	
	@When("<productName> is entered in the CIS PRDT Update Exception report filter")
	public void whenproductNameIsEnteredInTheCISPRDTUpdateExceptionReportFilter(@Named("productName") String productName) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportProductName(productName);
	}
	
	@When("Channel ID is entered in the CIS PRDT Update Exception report filter")
	public void whenChannelIDIsEnteredInTheCISPRDTUpdateExceptionReportFilter() throws InterruptedException {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportChannelId();
	}
	
	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are entered in the CIS PRDT Update Exception report filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreEnteredInTheCISPRDTUpdateExceptionReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	
	@Then("Validate excel reports against DataBase Results for all valid values entered in the CIS PRDT Update Exception report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForAllValidValuesEnteredInTheCISPRDTUpdateExceptionReportFilterPage() throws ClassNotFoundException, SQLException {
		cisProductUpdateReportSteps.validateExcelDBCisPrdtUpdateReportAllValidInput();
	}
	
	@When("Invalid <productCode> is entered in the CIS PRDT Update Exception report filter")
	public void whenInvalidproductCodeIsEnteredInTheCISPRDTUpdateExceptionReportFilter(@Named("productCode") String productCode) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportProductCode(productCode);
	}
	
	@When("Invalid <insurerComponentCode> is entered in the CIS PRDT Update Exception report filter")
	public void whenInvalidinsurerComponentCodeIsEnteredInTheCISPRDTUpdateExceptionReportFilter(@Named("insurerComponentCode") String insurerComponentCode) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportInsurerComponentCode(insurerComponentCode);
	}
	
	@When("Invalid <productName> is entered in the CIS PRDT Update Exception report filter")
	public void whenInvalidproductNameIsEnteredInTheCISPRDTUpdateExceptionReportFilter(@Named("productName") String productName) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportProductName(productName);
	}
	
	@When("Invalid <insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are entered in the CIS PRDT Update Exception report filter")
	public void whenInvalidinsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreEnteredInTheCISPRDTUpdateExceptionReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) {
		cisProductUpdateReportSteps.enterCisPrdtUpdateReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
		
	@Then("Click on Export and verify error message is displayed in CIS PRDT Update Exception report filter page")
	public void thenClickOnExportAndVerifyErrorMessageIsDisplayedInCISPRDTUpdateExceptionReportFilterPage() throws InterruptedException {
		cisProductUpdateReportSteps.clickExportButtonReports();
		cisProductUpdateReportSteps.verifyNoRecordFound();
		Utils.driver.quit();
	}
	
	/* 
	 * 
	 * END of BPDS-34 
	 * 
	 */
	

	/*
	 * 
	 * START OF BPDS-17
	 * 
	 * 
	 */
	
	@When("Admin user traverse for Product Audit Trail Report Page")
	public void whenAdminUserTraverseForProductAuditTrailReportPage() {
		landingPageSteps.verifyProductModule_landingPage();
	}

	@Then("Admin user should land in Product Audit Trail Report filter page")
	public void thenAdminUserShouldLandInProductAuditTrailReportFilterPage() {
		productAuditTrailReportSteps.launchProductAuditTrailReportPage();
	}

	@Then("Verify static text displayed in the Product Audit Trail Report filter page")
	public void thenVerifyStaticTextDisplayedInTheProductAuditTrailReportFilterPage() {
		productAuditTrailReportSteps.chkFillcriteriaStaticText();
	}
	
	@Given("Admin user on the Product Audit Trail Report filter page")
	public void givenAdminUserOnTheProductAuditTrailReportFilterPage() {
		productAuditTrailReportSteps.resetProductAuditTrailReportPage();
	}

	@Then("Verify Export button is disabled by default in the Product Audit Trail Report filter page")
	public void thenVerifyExportButtonIsDisabledByDefaultInTheProductAuditTrailReportFilterPage() {
		productAuditTrailReportSteps.chkExportBtnISDisabled();
	}
	
	@When("<productCode> alone selected in the Product Audit Trail Report filter")
	public void whenproductCodeAloneSelectedInTheProductAuditTrailReportFilter(@Named("productCode") String productCode) {
		productAuditTrailReportSteps.enterProductAuditTrailReportProductCode(productCode);
	}

	@Then("Verify Export button is enabled in the Product Audit Trail Report filter")
	public void thenVerifyExportButtonIsEnabledInTheProductAuditTrailReportFilter() {
		productAuditTrailReportSteps.chkExportBtnISEnabled();
	}

	@Then("Download and verify the Product Audit Trail Report file name")
	public void thenDownloadAndVerifyTheProductAuditTrailReportFileName() throws InterruptedException {
		productAuditTrailReportSteps.clickExportButtonReports();
		productAuditTrailReportSteps.verifyDownloadPrdtGroupExceptionReportFilename();
	}
	

	@Then("Validate excel reports against DataBase Results for Product Code entered in the Product Audit Trail Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForProductCodeEnteredInTheProductAuditTrailReportFilterPage() throws ClassNotFoundException, SQLException {
		productAuditTrailReportSteps.validateExcelDBProductAuditTrailReportProductCode();
	}
	

	@When("<insurerComponentCode> alone selected in the Product Audit Trail Report filter")
	public void wheninsurerComponentCodeAloneSelectedInTheProductAuditTrailReportFilter(@Named("insurerComponentCode") String insurerComponentCode) {
		productAuditTrailReportSteps.enterProductAuditTrailReportInsurerComponentCode(insurerComponentCode);
	}
	

	@Then("Validate excel reports against DataBase Results for Insurer Component Code entered in the Product Audit Trail Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerComponentCodeEnteredInTheProductAuditTrailReportFilterPage() throws ClassNotFoundException, SQLException {
		productAuditTrailReportSteps.validateExcelDBProductAuditTrailReportInsurerComponentCode();
	}
	

	@When("Insurer Name alone selected in the Product Audit Trail Report filter")
	public void whenInsurerNameAloneSelectedInTheProductAuditTrailReportFilter() {
		productAuditTrailReportSteps.selectProductAuditTrailReportInsurerName();
	}


	@Then("Validate excel reports against DataBase Results for insurer name entered in the Product Audit Trail Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerNameEnteredInTheProductAuditTrailReportFilterPage() throws ClassNotFoundException, SQLException {
		productAuditTrailReportSteps.validateExcelDBProductAuditTrailReportInsurerName();
	}
	

	@When("<productName> alone selected in the Product Audit Trail Report filter")
	public void whenproductNameAloneSelectedInTheProductAuditTrailReportFilter(@Named("productName") String productName) {
		productAuditTrailReportSteps.enterProductAuditTrailReportProductName(productName);
	}
	

	@Then("Validate excel reports against DataBase Results for Product Name entered in the Product Audit Trail Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForProductNameEnteredInTheProductAuditTrailReportFilterPage() throws ClassNotFoundException, SQLException {
		productAuditTrailReportSteps.validateExcelDBProductAuditTrailReportProductName();
	}
	

	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> alone selected in the Product Audit Trail Report filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAloneSelectedInTheProductAuditTrailReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) {
		productAuditTrailReportSteps.enterProductAuditTrailReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	

	@Then("Validate excel reports against DataBase Results for Insurer Record Date entered in the Product Audit Trail Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForInsurerRecordDateEnteredInTheProductAuditTrailReportFilterPage() throws ClassNotFoundException, SQLException {
		productAuditTrailReportSteps.validateExcelDBProductAuditTrailReportInsurerRecordDate();
	}
	
	

	@When("<productCode> is selected in the Product Audit Trail Report filter")
	public void whenproductCodeIsSelectedInTheProductAuditTrailReportFilter(@Named("productCode") String productCode) {
		productAuditTrailReportSteps.enterProductAuditTrailReportProductCode(productCode);
	}
	
	@When("<insurerComponentCode> is selected in the Product Audit Trail Report filter")
	public void wheninsurerComponentCodeIsSelectedInTheProductAuditTrailReportFilter(@Named("insurerComponentCode") String insurerComponentCode) {
		productAuditTrailReportSteps.enterProductAuditTrailReportInsurerComponentCode(insurerComponentCode);
	}

	@When("Insurer Name is selected in the Product Audit Trail Report filter")
	public void whenInsurerNameIsSelectedInTheProductAuditTrailReportFilter() {
		productAuditTrailReportSteps.selectProductAuditTrailReportInsurerName();
	}

	

	@When("<productName> is selected in the Product Audit Trail Report filter")
	public void whenproductNameIsSelectedInTheProductAuditTrailReportFilter(@Named("productName") String productName) {
		productAuditTrailReportSteps.enterProductAuditTrailReportProductName(productName);
	}

	@When("<insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are selected in the Product Audit Trail Report filter")
	public void wheninsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreSelectedInTheProductAuditTrailReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) {
		productAuditTrailReportSteps.enterProductAuditTrailReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	

	@Then("Validate excel reports against DataBase Results for all valid values entered in the Product Audit Trail Report filter page")
	public void thenValidateExcelReportsAgainstDataBaseResultsForAllValidValuesEnteredInTheProductAuditTrailReportFilterPage() throws ClassNotFoundException, SQLException {
		productAuditTrailReportSteps.validateExcelDBProductAuditTrailReportAllValidInput();
	}
	


	@When("Invalid <productCode> is entered in the Product Audit Trail Report filter")
	public void whenInvalidproductCodeIsEnteredInTheProductAuditTrailReportFilter(@Named("productCode") String productCode) {
		productAuditTrailReportSteps.enterProductAuditTrailReportProductCode(productCode);
	}

	@When("Invalid <insurerComponentCode> is entered in the Product Audit Trail Report filter")
	public void whenInvalidinsurerComponentCodeIsEnteredInTheProductAuditTrailReportFilter(@Named("insurerComponentCode") String insurerComponentCode) {
		productAuditTrailReportSteps.enterProductAuditTrailReportInsurerComponentCode(insurerComponentCode);
	}

	@When("Invalid <productName> is entered  in the Product Audit Trail Report filter")
	public void whenInvalidproductNameIsEnteredInTheProductAuditTrailReportFilter(@Named("productName") String productName) {
		productAuditTrailReportSteps.enterProductAuditTrailReportProductName(productName);
	}

	@When("Invalid <insurerRecordReceivedDateFrom> and <insurerRecordReceivedDateTo> are selected in the Product Audit Trail Report filter")
	public void whenInvalidinsurerRecordReceivedDateFromAndinsurerRecordReceivedDateToAreSelectedInTheProductAuditTrailReportFilter(@Named("insurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("insurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) {
		productAuditTrailReportSteps.enterProductAuditTrailReportInsurerRecordDate(insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}


	@Then("Click on Export and verify error message is displayed in Product Audit Trail Report file name")
	public void thenClickOnExportAndVerifyErrorMessageIsDisplayedInProductAuditTrailReportFileName() {
		productAuditTrailReportSteps.clickExportButtonReports();
		productAuditTrailReportSteps.verifyNoRecordFound();
		Utils.driver.quit();
	}	

	/* 
	 * 
	 * START of BPDS-9 
	 * 
	 */
	
	@Given("Admin UI application is opened")
	public void givenAdminUIApplicationIsOpened() throws Exception {
		loginPagesteps.launchApplication();
	}

	@When("User enters valid username and valid password and click on login button")
	public void whenUserEntersValidUsernameAndValidPasswordAndClickOnLoginButton() throws Exception {
		loginPagesteps.login(Constants.USERNAME, Constants.PASSWORD);
	}

	@Then("User should be able to see landing page")
	public void thenUserShouldBeAbleToSeeLandingPage() {
		loginPagesteps.verifyLandingPage();
	}

	@Then("User should logout and close the application")
	public void thenUserLogoutAndCloseTheApplication() {
		loginPagesteps.logOutFromApplication();
		loginPagesteps.closeApplication();
	}
	
	@When("User enters valid username <userName> and invalid password <invalidPassWord> and click on login button")
	public void whenUserEntersValidUsernameAndInvalidPasswordAndClickOnLoginButton(@Named("userName") String username, @Named("invalidPassWord") String password) throws Exception {
		loginPagesteps.login(username,password);
	}
	
	@Then("User should be able to see error message <errorMessage>")
	public void thenUserShouldBeAbleToSeeErrorMessageerrorMessage(@Named("errorMessage")String expectedMessage) 
	{
		actual_message = loginPagesteps.getErrorMessageText();
		Utils.verifyErrorMessage(actual_message, expectedMessage);
	}
	
	@When("User enters invalid username <invalidUserName> and valid password <passWord> and click on login button")
	public void whenUserEntersInvalidUsernameAndValidPasswordAndClickOnLoginButton(@Named("invalidUserName") String username, @Named("passWord") String password) throws Exception {
		loginPagesteps.login(username, password);
	}
	
	@When("User enters username <userName> as blank and valid password <passWord> and click on login button")
	public void whenUserEntersUsernameAsBlankAndValidPasswordAndCliclOnLoginButton(@Named("userName") String username, @Named("passWord") String password) throws Exception {
		if ((username.trim()).equalsIgnoreCase("blank"))
		{
			username = "";
		}
		else if ((password.trim()).equalsIgnoreCase("blank"))
		{
			password = "";
		}
		loginPagesteps.login(username, password);
	}
	
	@When("User enters valid username <userName> and password <passWord> as blank and click on login button")
	public void WhenUserEntersValidUsernameAndPasswordAsBlankAndClickOnLoginButton(@Named("userName") String username, @Named("passWord") String password) throws Exception {
		if ((username.trim()).equalsIgnoreCase("blank"))
		{
			username = "";
		}
		else if ((password.trim()).equalsIgnoreCase("blank"))
		{
			password = "";
		}
		loginPagesteps.login(username,password);
	}
	
	@When("User enters username <userName> and password <passWord> as blank and click on login button")
	public void WhenUserEntersUserNameAndPasswordAsBlankAndClickOnLoginButton(@Named("userName") String username, @Named("passWord") String password) throws Exception {
		if ((username.trim()).equalsIgnoreCase("blank"))
		{
			username = "";
		}
		else if ((password.trim()).equalsIgnoreCase("blank"))
		{
			password = "";
		}
		loginPagesteps.login(username,password);
	}
	
	@Then("close the application")
	public void thenCloseTheApplication() {
		loginPagesteps.closeApplication();
	}
	
	@When("User logged in as a LI product admin")
	public void whenUserLoggedInAsALIProductAdmin() throws Exception {
		loginPagesteps.login(Constants.USERNAME, Constants.PASSWORD);
	}

	@When("User logged in as a customer holding enquirer")
	public void whenUserLoggedInAsACustomerHoldingEnquirer() throws Exception   {
		loginPagesteps.login(Constants.USERNAME, Constants.PASSWORD);
	}
	
	@Then("User should be able to see the cusotmer holdings enquiry page on clicking Customer Holdings Inquiry tab")
	public void thenUserShouldBeAbleToSeeTheCustomerHoldingsEnquiryPageOnClickingCustomerHoldingsInquiryTab() {
		landingPageSteps.verifyCustomerHoldingsModule_landingPage();
	}
	
	@When("User logged in as a GI product admin")
	public void whenUserLoggedInAsAGIProductAdmin() throws Exception {
		loginPagesteps.login(Constants.USERNAME, Constants.PASSWORD);
	}
	
	@Then("User should be able to see the pending action page on clicking Product Admin")
	public void thenUserShouldBeAbleToSeeThePendingActionPageOnClickingProductAdmin() throws InterruptedException {
		landingPageSteps.verifyProductModule_landingPage();
	}
	
	/* 
	 * 
	 * END of BPDS-9
	 * 
	 */
	
	/*
	 * 
	 * 
	 * START OF BPDS-41
	 * 
	 * 
	 */
	
	@Given("Staff user is able to login to application successfully")
	public void givenStaffUserIsAbleToLoginToApplicationSuccessfully() throws Exception {
		loginPagesteps.launchApplication();
		loginPagesteps.login(Constants.USERNAME, Constants.PASSWORD);
	}

	@When("Staff user click on Customer Holdings tab user should be able to see Customer Holdings page")
	public void whenStaffUserClickOnCustomerHoldingsTabUserShouldBeAbleToSeeCustomerHoldingsPage() {
		landingPageSteps.verifyCustomerHoldingsModule_landingPage();
	}

	@Then("Verify static text displayed in the Customer Holdings Inquiry page")
	public void thenVerifyStaticTextDisplayedInTheCustomerHoldingsInquiryPage() throws Exception {
		custHoldEnquiryPageSteps.chkFillcriteriaStaticText();
	}

	@Then("Verify Search button is disabled by default in the Customer Holdings Inquiry page")
	public void thenVerifySearchButtonIsDisabledByDefaultInTheCustomerHoldingsInquiryPage() throws Exception {
		custHoldEnquiryPageSteps.verifySearchButtonDisabled();
	}
	
	@Given("Staff user is on the Customer Holdings Inquiry page")
	public void givenAdminUserIsOnTheCustomerHoldingsInquiryPage() {
		custHoldEnquiryPageSteps.resetCustomerHoldingsEnquiryPage();
		landingPageSteps.verifyCustomerHoldingsModule_landingPage();
	}

	@Then("user should be able to see all the Search filters they can use for search")
	public void thenUserShouldBeAbleToSeeAllTheSearchFiltersTheyCanUseForSearch() throws Exception {
		custHoldEnquiryPageSteps.verifySearchFiltersPresent();
	}

	@When("user selected Insurer name <InsurerName> and click on Search")
	public void whenUserSelectedInsurerNameInsurerNameAndClickOnSearch(@Named("InsurerName") String InsurerName) throws Exception {
		custHoldEnquiryPageSteps.selectInsurerNameFromDropdown(InsurerName);
	}
	
	@When("user entered Insurer component code <InsurerComponentCode> and click on Search")
	public void whenUserEnteredInsurerComponentCodeInsurerComponentCodeAndClickOnSearch(@Named("InsurerComponentCode") String InsurerComponentCode) throws Exception {
		custHoldEnquiryPageSteps.enterInsurerComponentCode(InsurerComponentCode);
	}
	
	@When("user entered Insurer Component code <ProductCode> and click on Search")
	public void whenUserEnteredProductCodeProductCodeAndClickOnSearch(@Named("ProductCode") String ProductCode) throws Exception {
		custHoldEnquiryPageSteps.enterProductCode(ProductCode);
	}
	
	@When("user selected Plan Type <PlanType> and click on Search")
	public void whenUserSelectedPlanTypePlanTypeAndClickOnSearch(@Named("PlanType") String PlanType) throws Exception {
		custHoldEnquiryPageSteps.selectPlanType(PlanType);
	}
	
	@When("user selected Channel Ref Number <ChannelRefNumber> and click on Search")
	public void whenUserSelectedChannelRefNumberChannelRefNumberAndClickOnSearch(@Named("ChannelRefNumber") String ChannelRefNumber) throws Exception {
		custHoldEnquiryPageSteps.enterChannelRefNumber(ChannelRefNumber);
	}
	
	@When("user selected Product Name <PolicyNumber> and click on Search")
	public void whenUserSelectedPolicyNumberPolicyNumberAndClickOnSearch(@Named("PolicyNumber") String PolicyNumber) throws Exception {
		custHoldEnquiryPageSteps.enterPolicyNumber(PolicyNumber);
	}
	
	@When("user selected Product Name <PolicyCommencementDate> and click on Search")
	public void whenUserSelectedPolicyCommencementDatePolicyCommencementDateAndClickOnSearch(@Named("PolicyCommencementDate") String PolicyCommencementDate) throws Exception {
		custHoldEnquiryPageSteps.enterPolicyCommencementDate(PolicyCommencementDate);
	}
	
	@When("user selected InsurerRecordReceivedDateFrom <InsurerRecordReceivedDateFrom> and click on Search")
	public void whenUserSelectedInsurerRecordReceivedDateFromInsurerRecordReceivedDateFromAndClickOnSearch(@Named("InsurerRecordReceivedDateFrom") String InsurerRecordReceivedDateFrom) throws Exception {
		custHoldEnquiryPageSteps.enterInsurerRecordReceivedDateFrom(InsurerRecordReceivedDateFrom);
	}
	
	@When("user selected InsurerRecordReceivedDateTo <InsurerRecordReceivedDateTo> and click on Search")
	public void whenUserSelectedInsurerRecordReceivedDateToInsurerRecordReceivedDateToAndClickOnSearch(@Named("InsurerRecordReceivedDateTo") String InsurerRecordReceivedDateTo) throws Exception {
		custHoldEnquiryPageSteps.enterInsurerRecordReceivedDateTo(InsurerRecordReceivedDateTo);
	}
	
	@When("user inputs all fields <InsurerName> <ProductCode> <InsurerComponentCode> <PlanType> <ChannelRefNumber> <ProductName> <PolicyNumber> <PolicyCommencementDate> <DBSOwnerCIN> <ChannelID> <InsurerRecordReceivedDateFrom> <InsurerRecordReceivedDateTo> and click on Search")
	public void userInputsAllFieldsInsurerNameInsurerNameProductCodeProductCodeInsurerComponentCodeInsurerComponentCodePlanTypePlanTypeChannelRefNumberChannelRefNumberProductNameProductNamePolicyNumberPolicyNumberPolicyCommencementDatePolicyCommencementDatePolicyDBSOwnerCINDBSOwnerCINChannelIDChannelIDInsurerRecordReceivedDateFromInsurerRecordReceivedDateFromInsurerRecordReceivedDateToInsurerRecordReceivedDateToAndClickOnSearch(@Named("InsurerName") String InsurerName,@Named("ProductCode") String ProductCode,@Named("InsurerComponentCode") String InsurerComponentCode,@Named("PlanType") String PlanType,@Named("ChannelRefNumber") String ChannelRefNumber,@Named("ProductName") String ProductName,@Named("PolicyNumber") String PolicyNumber,@Named("PolicyCommencementDate") String PolicyCommencementDate,@Named("DBSOwnerCIN") String DBSOwnerCIN,@Named("ChannelID") String ChannelID,@Named("InsurerRecordReceivedDateFrom") String InsurerRecordReceivedDateFrom,@Named("InsurerRecordReceivedDateTo") String InsurerRecordReceivedDateTo) throws Exception {
		custHoldEnquiryPageSteps.enterAllInputValues(InsurerName, ProductCode, InsurerComponentCode, PlanType, ChannelRefNumber, ProductName, PolicyNumber, PolicyCommencementDate, DBSOwnerCIN, ChannelID, InsurerRecordReceivedDateFrom, InsurerRecordReceivedDateTo);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <InsurerName>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValueInsurerName(@Named("InsurerName") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <ProductCode>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValueProductCode(@Named("ProductCode") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <InsurerComponentCode>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValueInsurerComponentCode(@Named("InsurerComponentCode") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <PlanType>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValuePlanType(@Named("PlanType") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <ChannelRefNumber>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValueChannelRefNumber(@Named("ChannelRefNumber") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <ProductName>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValueProductName(@Named("ProductName") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <PolicyNumber>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValuePolicyNumber(@Named("PolicyNumber") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <PolicyCommencementDate>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValuePolicyCommencementDate(@Named("PolicyCommencementDate") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <ChannelID>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValueChannelID(@Named("ChannelID") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> value <DBSOwnerCIN>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValueDBSOwnerCIN(@Named("DBSOwnerCIN") String fieldValue, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue);
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> values <InsurerRecordReceivedDateFrom> <InsurerRecordReceivedDateTo>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaValueInsurerRecordReceivedDateTo(@Named("InsurerRecordReceivedDateFrom") String fieldValue,@Named("InsurerRecordReceivedDateTo") String fieldValue1, @Named("SearchCriteria") String filterCriteria) throws Exception {
		custHoldEnquiryPageSteps.verifySearchResultsAsPerSearchCriteria(filterCriteria, fieldValue,fieldValue1);
	}
	
	@When("user selected Product code <ProductCode> and click on Search")
	public void whenUserSelectedProductCodeAndClickOnSearch(@Named("ProductCode") String productCode) throws Exception {
		custHoldEnquiryPageSteps.enterProductCode(productCode);
	}

	@When("user selected Insurer component code <InsurerComponentCode> and click on Search")
	public void whenUserSelectedInsurerComponentCodeInsurerComponentCodeAndClickOnSearch(@Named("InsurerComponentCode") String insurerComponentCode) throws Exception {
		custHoldEnquiryPageSteps.enterInsurerComponentCode(insurerComponentCode);
	}

	@When("user selected Plan type <PlanType> and click on Search")
	public void whenUserSelectedPlanTypeAndClickOnSearch(@Named("PlanType") String planType) throws Exception {
		custHoldEnquiryPageSteps.selectPlanType(planType);
	}
	
	@When("user selected Product name <ProductName> and click on Search")
	public void whenUserSelectedProductNameAndClickOnSearch(@Named("ProductName") String productName) throws Exception {
		custHoldEnquiryPageSteps.enterProductName(productName);
	}

	@When("user selected Policy number <PolicyNumber> and click on Search")
	public void whenUserSelectedPolicyNumberAndClickOnSearch(@Named("PolicyNumber") String policyNumber) throws Exception {
		custHoldEnquiryPageSteps.enterPolicyNumber(policyNumber);
	}

	@When("user selected Policy commencement date <PolicyCommencementDate> and click on Search")
	public void whenUserSelectedPolicyCommencementDateAndClickOnSearch(@Named("PolicyCommencementDate") String policyCommencementDate) throws Exception {
		custHoldEnquiryPageSteps.enterPolicyCommencementDate(policyCommencementDate);
	}

	@When("user selected DBS Owner CIN <DBSOwnerCIN> and click on Search")
	public void whenUserSelectedDBSOwnerCINDBSOwnerCINAndClickOnSearch(@Named("DBSOwnerCIN") String dbsOwnerCIN) throws Exception {
		custHoldEnquiryPageSteps.enterDBSOwnerCIN(dbsOwnerCIN);
	}

	@When("user selected Channel ID <ChannelID> and click on Search")
	public void whenUserSelectedChannelIDChannelIDAndClickOnSearch(@Named("ChannelID") String channelID) throws Exception {
		custHoldEnquiryPageSteps.selectChannelID(channelID);
	}

	@When("user selected Insurer Record Received Date From <InsurerRecordReceivedDateFrom>")
	public void whenUserSelectedInsurerRecordReceivedDateFromInsurerRecordReceivedDateFrom(@Named("InsurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom) throws Exception {
		custHoldEnquiryPageSteps.enterInsurerRecordReceivedDateFrom(insurerRecordReceivedDateFrom);
	}

	@Then("search button should be disabled")
	public void thenSearchButtonShouldBeDisabled() throws Exception {
		custHoldEnquiryPageSteps.checkSearchButtonDisabled();
	}
	
	@When("user selected Insurer Record Received Date To <InsurerRecordReceivedDateTo>")
	public void whenUserSelectedInsurerRecordReceivedDateToInsurerRecordReceivedDateTo(@Named("InsurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) throws Exception {
		custHoldEnquiryPageSteps.enterInsurerRecordReceivedDateTo(insurerRecordReceivedDateTo);
	}
	
	@Then("verify whether user is able to click on policy number to download policy details in xlsx and verify exported file name format")
	public void thenVerifyWhetherUserIsAbleToClickOnPolicyNumberToDownloadPolicyDetailsInInXlsxAndVerifyExportedFilkeNameFormat() throws Exception {
		custHoldEnquiryPageSteps.verifyFileDownloadedWithExpectedFileName(1);
	}
	
	@When("user selected Insurer Record Received Date From <InsurerRecordReceivedDateFrom> & Insurer Record Received Date To <InsurerRecordReceivedDateTo> and click on Search")
	public void whenUserSelectedInsurerRecordReceivedDateFromInsurerRecordReceivedDateFromInsurerRecordReceivedDateToInsurerRecordReceivedDateToAndClickOnSearch(@Named("InsurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom, @Named("InsurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) throws Exception {
		custHoldEnquiryPageSteps.enterInsurerRecordReceivedDateFrom(insurerRecordReceivedDateFrom);
		custHoldEnquiryPageSteps.enterInsurerRecordReceivedDateTo(insurerRecordReceivedDateTo);
		custHoldEnquiryPageSteps.clickOnSearchButton();
	}
	
	@Then("user should be able to see the search results as per the search criteria <SearchCriteria> and values <InsurerName> <ProductCode> <InsurerComponentCode> <PlanType> <ChannelRefNumber> <ProductName> <PolicyNumber> <PolicyCommencementDate> <DBSOwnerCIN> <ChannelID> <InsurerRecordReceivedDateFrom> <InsurerRecordReceivedDateTo>")
	public void thenUserShouldBeAbleToSeeTheSearchResultsAsPerTheSearchCriteriaSearchCriteriaAndValuesInsurerNameProductCodeInsurerComponentCodePlanTypeChannelRefNumberProductNamePolicyNumberPolicyCommencementDateDBSOwnerCINChannelIDInsurerRecordReceivedDateFromInsurerRecordReceivedDateTo(@Named("SearchCriteria") String filterField,@Named("InsurerName") String insurerName, @Named("ProductCode") String productCode,@Named("InsurerComponentCode") String insurerComponentCode,@Named("PlanType") String planType,@Named("ChannelRefNumber") String channelRefNumber,@Named("ProductName") String productName, @Named("PolicyNumber") String policyNumber,@Named("PolicyCommencementDate") String policyCommencementDate, @Named("DBSOwnerCIN") String dbsOwnerCIN,@Named("ChannelID") String channelID,@Named("InsurerRecordReceivedDateFrom") String insurerRecordReceivedDateFrom,@Named("InsurerRecordReceivedDateTo") String insurerRecordReceivedDateTo) throws Exception {
		custHoldEnquiryPageSteps.verifyAllValuesFromSearchResults(filterField, insurerName, productCode, insurerComponentCode, planType, channelRefNumber,productName , policyNumber, policyCommencementDate, dbsOwnerCIN, channelID, insurerRecordReceivedDateFrom, insurerRecordReceivedDateTo);
	}
	
	@When("Staff user click on logout link he should be able to logout from the application")
	public void whenStaffUserClickOnLogoutLinkHeShouldBeAbleToLogoutFromTheApplication() {
		loginPagesteps.logOutFromApplication();
		loginPagesteps.closeApplication();
	}
	
	/* 
	 * 
	 * END of BPDS-41 
	 * 
	 */
	
	/* 
	 * 
	 * START of BPDS-14 
	 * 
	 */
	
	@When("Admin user traverse for Approved Page")
	public void whenAdminUserTraverseForApprovedPage() {
		landingPageSteps.verifyProductModule_landingPage();
	}

	@Then("Admin user should land in Approved page")
	public void thenAdminUserShouldLandInApprovedPage() throws InterruptedException {
		productApprovedPageSteps.launchProductApprovedPage();
	}

	@Then("Verify static text displayed in the Approved page")
	public void thenVerifyStaticTextDisplayedInTheApprovedPage() {
		productApprovedPageSteps.chkFillcriteriaStaticText();		
	}	

	@Given("Admin user should be on Approved page")
	public void givenAdminUserShouldBeOnApprovedPage() throws InterruptedException {
		productApprovedPageSteps.chkUserOnProductApprovedPage();
	}

	@Then("Verify Search button is disabled by default on Approved page")
	public void thenVerifySearchButtonIsDisabledByDefaultOnApprovedPage() throws Exception {
		productApprovedPageSteps.verifySearchButtonDisabled();
	}
	
	@Then("Verify static text of all filter labels")
	public void thenVerifyStaticTextOfAllFilterLabels() {
		productApprovedPageSteps.verifySearchFilterLabels();
	}
	
	@Then("Verify that user country code is SG")
	public void thenVerifyThatUserCountryCodeIsSG() throws Exception {
		productApprovedPageSteps.verifyUserCountryCode();
	}
	
	@When("Select Insurer name <InsurerName> and click on search")
	public void whenSelectInsurerNameInsurerNameAndClickOnSearch(@Named ("InsurerName") String InsurerName) throws Exception {
		productApprovedPageSteps.selectInsurerNameFromDropdown(InsurerName);
	}
	
	@Then("Verify text on popup and click OK")
	public void thenVerifyTextOnPopupAndClickOK() {
		productApprovedPageSteps.chkPopUpDisplayed();
	}

	@Then("Verify whether popup closed")
	public void thenVerifyWhetherPopupClosed() throws InterruptedException {
		productApprovedPageSteps.chkUserOnProductApprovedPage();
	}
	
	@When("Enter Product Code <ProductCode>")
	public void whenEnterProductCodeProductCode(@Named ("ProductCode") String ProductCode) {
		productApprovedPageSteps.enterProductCodeInApprovedPage(ProductCode);
	}

	@Then("Select Insurer name <InsurerName> and click on search")
	public void thenSelectInsurerNameInsurerNameAndClickOnSearch(@Named ("InsurerName") String InsurerName) throws Exception {
		productApprovedPageSteps.selectInsurerNameFromDropdown(InsurerName);
	}

	@Then("Verify displayed records based on <ProductCode> and Record status should be Approved")
	public void thenVerifyDisplayedRecordsBasedOnProductCodeAndRecordStatusShouldBeApproved(@Named ("ProductCode") String ProductCode) throws Exception {
		//productApprovedPageSteps.VerifyRecordStatus_ProdCode(ProductCode);
		productApprovedPageSteps.VerifyRecordStatus(ProductCode, "Product Code" );
	}
	
	@Given("Reset the page and Admin user should be on Approved page")	
	public void givenResetThePageAndAdminUserShouldBeOnApprovedPage() throws InterruptedException {
		productApprovedPageSteps.resetProductApprovedPage();
	}

	@When("Enter Insurer Component Code <InsurerComponentCode>"	)
	public void whenEnterInsurerComponentCodeInsurerComponentCode(@Named ("InsurerComponentCode") String InsurerComponentCode) {
		productApprovedPageSteps.enterInsurerComponentCodeInApprovedPage(InsurerComponentCode);
	}

	@Then("Verify displayed records based on <InsurerComponentCode> and Record status should be Approved")	
	public void thenVerifyDisplayedRecordsBasedOnInsurerComponentCodeAndRecordStatusShouldBeApproved(@Named ("InsurerComponentCode") String InsurerComponentCode) throws Exception {
		productApprovedPageSteps.VerifyRecordStatus(InsurerComponentCode,"Insurer Component Code");
	}
	
	@When("Enter Product Name <ProductName>")
	public void whenEnterProductNameProductName(@Named ("ProductName") String ProductName){
		productApprovedPageSteps.enterProductNameInApprovedPage(ProductName);
	}

	@Then("Verify displayed records based on <ProductName> and Record status should be Approved")
	public void thenVerifyDisplayedRecordsBasedOnProductNameAndRecordStatusShouldBeApproved(@Named ("ProductName") String ProductName) throws Exception {
		productApprovedPageSteps.VerifyRecordStatus(ProductName,"Product Name");
	}
	
	@Then("Verify displayed records based on <ProductName>")
	public void thenVerifyDisplayedRecordsBasedOnProductName(@Named ("ProductName") String ProductName) throws Exception {
		productApprovedPageSteps.VerifyWildCardSearchForProdName(ProductName, "Product Name");
	}
	
	@When("Enter Approved By <ApprovedBy>")
	public void whenEnterApprovedByApprovedBy(@Named ("ApprovedBy") String ApprovedBy) {
		productApprovedPageSteps.enterApprovedByInApprovedPage(ApprovedBy);
	}

	@Then("Verify displayed records based on <ApprovedBy> and Record status should be Approved")
	public void thenVerifyDisplayedRecordsBasedOnApprovedByAndRecordStatusShouldBeApproved(@Named ("ApprovedBy") String ApprovedBy) throws Exception {
		productApprovedPageSteps.VerifyRecordStatus(ApprovedBy, "Last Approved By");
	}	

	@Then("Verify Approved Date To field is disabled by default on Approved page")
	public void thenVerifyApprovedDateToFieldIsDisabledByDefaultOnApprovedPage() throws Exception {
		productApprovedPageSteps.verifyToDateDisabled();
	}
		
	@Then("Verify Column Labels are as expected by default")
	public void thenVerifyColumnLabelsAreAsExpectedByDefault() throws InterruptedException {
		productApprovedPageSteps.verifyColumnLabelsByDefault();
	}

	@Then("Verify records are showing and Record status is Approved")
	public void thenVerifyRecordsAreShowingAndRecordStatusIsApproved() throws Exception {
		productApprovedPageSteps.verifyRecordStatusByDefault();
	}

	@Then("Records should be displayed in descending Last Approved Date.")
	public void thenRecordsShouldBeDisplayedInDescendingLastApprovedDate() throws Exception {		
		productApprovedPageSteps.verifyLastApprovedDateTimeByDefaultInDescending();
	}
	
	@When("Enter Approved Date From <ApprovedDateFrom> and Approve Date To <ApprovedDateTo>")
	public void whenEnterApprovedDateFromApprovedDateFromAndApproveDateToApprovedDateTo(@Named ("ApprovedDateFrom") String ApprovedDateFrom, @Named ("ApprovedDateTo") String ApprovedDateTo){
		productApprovedPageSteps.enterApprovedDateFromAndToInApprovedPage(ApprovedDateFrom,ApprovedDateTo );
	}

	@Then("Verify displayed records based on entered Dates")
	public void thenVerifyDisplayedRecordsBasedOnEnteredDates(@Named ("ApprovedDateFrom") String ApprovedDateFrom, @Named ("ApprovedDateTo") String ApprovedDateTo) throws Exception{
		productApprovedPageSteps.verifyLastApprovedDateTimeForSpecifiedDates(ApprovedDateFrom, ApprovedDateTo);
	}

	
	/* 
	 * 
	 * END of BPDS-14 
	 * 
	 */
	
	/* 
	 * 
	 * START of BPDS-15 
	 * 
	 */
	
	@When("Admin user traverse for Cancelled Page")
	public void whenAdminUserTraverseForCancelledPage() {		
		landingPageSteps.verifyProductModule_landingPage();
	}

	@Then("Admin user should land in Cancelled page")
	public void thenAdminUserShouldLandInCancelledPage() throws InterruptedException {
		productCancelledPageSteps.launchProductCancelledPage();
	}

	@Then("Verify static text displayed in the Cancelled page")
	public void thenVerifyStaticTextDisplayedInTheCancelledPage() {
		productCancelledPageSteps.chkFillcriteriaStaticText();
	}
	
	@Given("Admin user should be on Cancelled page")
	public void givenAdminUserShouldBeOnCancelledPage() throws InterruptedException {
		productCancelledPageSteps.chkUserOnProductCancelledPage();
	}

	@Then("Verify Search button is disabled by default on Cancelled page")
	public void thenVerifySearchButtonIsDisabledByDefaultOnCancelledPage() throws Exception {
		productCancelledPageSteps.verifySearchButtonDisabled();
	}

	@Then("Verify static text of all filter labels on Cancelled Page")
	public void thenVerifyStaticTextOfAllFilterLabelsOnCancelledPage() {
		productCancelledPageSteps.verifySearchFilterLabels();
	}
	@Then("Verify Column Labels are as expected by default on Cancelled page")
	public void thenVerifyColumnLabelsAreAsExpectedByDefaultOnCancelledPage() throws InterruptedException {
		productCancelledPageSteps.verifyColumnLabelsByDefault();
	}

	@Then("Verify records are showing and Record status is Cancelled")
	public void thenVerifyRecordsAreShowingAndRecordStatusIsCancelled() throws Exception {
		productCancelledPageSteps.verifyRecordStatusByDefaultOnCancelledPage();
	}
	@Then("Records should be displayed in descending Last Approved Date on Cancelled page")
	public void thenRecordsShouldBeDisplayedInDescendingLastApprovedDateOnCancelledPage() throws Exception {
		productCancelledPageSteps.verifyLastApprovedDateTimeByDefaultInDescendingOnCancelledPage();
	}
	@Then("Verify whether popup closed and user should be on Cancelled page")
	public void thenVerifyWhetherPopupClosedAndUserShouldBeOnCancelledPage() throws InterruptedException {
		productCancelledPageSteps.chkUserOnProductCancelledPage();
	}
	@Then("Verify displayed records based on <ProductCode> and Record status should be Cancelled")
	public void thenVerifyDisplayedRecordsBasedOnProductCodeAndRecordStatusShouldBeCancelled(@Named ("ProductCode") String ProductCode) throws Exception {
		productCancelledPageSteps.VerifyRecordStatusBasedonSearchText(ProductCode, "Product Code");
	}
	@Given("Reset the page and Admin user should be on Cancelled page")	
	public void givenResetThePageAndAdminUserShouldBeOnCancelledPage() throws InterruptedException {
		productCancelledPageSteps.resetProductCancelledPage();
	}

	@Then("Verify displayed records based on <InsurerComponentCode> and Record status should be Cancelled")
	public void thenVerifyDisplayedRecordsBasedOnInsurerComponentCodeAndRecordStatusShouldBeCancelled (@Named ("InsurerComponentCode") String InsurerComponentCode) throws Exception {
		productCancelledPageSteps.VerifyRecordStatusBasedonSearchText(InsurerComponentCode, "Insurer Component Code");
	}
	
	@Then("Verify displayed records based on <ProductName> and Record status should be Cancelled")
	public void thenVerifyDisplayedRecordsBasedOnProductNameAndRecordStatusShouldBeCancelled(@Named ("ProductName") String ProductName) throws Exception {
		productCancelledPageSteps.VerifyRecordStatusBasedonSearchText(ProductName, "Product Name");
	}
	
	@Then("Verify displayed records based on <ApprovedBy> and Record status should be Cancelled")
	public void thenVerifyDisplayedRecordsBasedOnApprovedByAndRecordStatusShouldBeCancelled(@Named ("ApprovedBy") String ApprovedBy) throws Exception {
		productCancelledPageSteps.VerifyRecordStatusBasedonSearchText(ApprovedBy, "Last Approved By");
	}
	
	@Then("Verify displayed records based on entered Dates on Cancelled page")
	public void thenVerifyDisplayedRecordsBasedOnEnteredDatesOnCancelledPage(@Named ("ApprovedDateFrom") String ApprovedDateFrom, @Named ("ApprovedDateTo") String ApprovedDateTo) throws Exception{
		productCancelledPageSteps.verifyLastApprovedDateTimeForSpecifiedDates(ApprovedDateFrom, ApprovedDateTo);
	}
	
	@Then("Verify Approved Date To field is disabled by default on Cancelled page")
	public void thenVerifyApprovedDateToFieldIsDisabledByDefaultOnCancelledPage() throws Exception {
		productCancelledPageSteps.verifyToDateDisabled();
	}
}


