package com.dbs.bpds.jira;

import static org.jbehave.core.reporters.Format.CONSOLE;
import static org.jbehave.core.reporters.Format.HTML;
import static org.jbehave.core.reporters.Format.XML;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import com.jbehaveforjira.javaclient.JiraStoryReporter;
import net.serenitybdd.jbehave.SerenityReporter;
import org.jbehave.core.Embeddable;
import org.jbehave.core.configuration.Configuration;
import org.jbehave.core.configuration.Keywords;
import org.jbehave.core.configuration.MostUsefulConfiguration;
import org.jbehave.core.io.CodeLocations;
import org.jbehave.core.reporters.*;
import org.jbehave.core.steps.InjectableStepsFactory;
import org.jbehave.core.steps.PrintStreamStepMonitor;
import org.jbehave.core.steps.ScanningStepsFactory;

import com.dbs.bpds.configs.Constants;
import com.jbehaveforjira.javaclient.JiraStepDocReporter;
import com.jbehaveforjira.javaclient.JiraStoryLoader;
import com.jbehaveforjira.javaclient.JiraStoryPathsFinder;

import net.serenitybdd.jbehave.SerenityJBehave;
import net.serenitybdd.jbehave.SerenityStories;
import net.thucydides.core.guice.Injectors;
import net.thucydides.core.util.EnvironmentVariables;

public class ConnectToJIRAUserStories extends SerenityStories {

	private static final CrossReference xref = new CrossReference();
	private Configuration configuration;
	private net.thucydides.core.webdriver.Configuration systemConfiguration;
	private EnvironmentVariables environmentVariables;
	private List<Format> formats = Arrays.asList(CONSOLE, HTML, XML);
	static {
		System.setProperty("javax.net.ssl.trustStore", "resources/cacerts");
		System.setProperty("javax.net.ssl.trustStorePassword", "changeit");
	}

	@Override
	public Configuration configuration() {

		if (configuration == null) {
			net.thucydides.core.webdriver.Configuration thucydidesConfiguration = getSystemConfiguration();
			if (environmentVariables != null) {
				thucydidesConfiguration = thucydidesConfiguration.withEnvironmentVariables(environmentVariables);
			}
			configuration = SerenityJBehave.defaultConfiguration(thucydidesConfiguration, formats, this);
			Class<? extends Embeddable> embeddableClass = this.getClass();
			Properties viewResources = new Properties();
			viewResources.put("decorateNonHtml", "true");
			// To get HTML output in Jira
			configuration.useStoryReporterBuilder(new StoryReporterBuilder() {
				public StoryReporter reporterFor(String storyPath, org.jbehave.core.reporters.Format format) {
					if (format.equals(org.jbehave.core.reporters.Format.HTML)) {
						Keywords keywords = keywords();
						return new JiraStoryReporter(new File("target", "story_report.xml"), keywords,
								Constants.JIRA_URL, Constants.JIRA_PROJECT, Constants.JIRA_USER,
								Constants.JIRA_PASSWORD, "Report");
					} else {
						return super.reporterFor(storyPath, format);
					}
				}
			}

					.withDefaultFormats().withFormats((Format[]) formats.toArray()).withCrossReference(xref)
					.withCodeLocation(CodeLocations.codeLocationFromClass(embeddableClass))
					.withViewResources(viewResources)
					.withPathResolver(new FilePrintStreamFactory.ResolveToPackagedName()).withFailureTrace(true)
					.withFailureTraceCompression(true).withReporters(new SerenityReporter(systemConfiguration))
					.withFailureTrace(true)

			);

			// set Jira story loader
			JiraStoryLoader jiraLoader = new JiraStoryLoader(Constants.JIRA_URL, Constants.JIRA_PROJECT,
					Constants.JIRA_USER, Constants.JIRA_PASSWORD, "src/test/resources", true);
			configuration.useStoryLoader(jiraLoader);

			// set Jira step doc reporter
			JiraStepDocReporter stepDocReporter = new JiraStepDocReporter(Constants.JIRA_URL, Constants.JIRA_PROJECT,
					Constants.JIRA_USER, Constants.JIRA_PASSWORD);
			stepDocReporter.includeStepJavaDocs(true);
			configuration.useStepdocReporter(stepDocReporter);
		}
		return configuration;

	}

	public InjectableStepsFactory stepsFactory() {
		Configuration con = new MostUsefulConfiguration().useStepMonitor(new PrintStreamStepMonitor()) // default
																										// is
																										// SilentStepMonitor()
				.doDryRun(true);
		return new ScanningStepsFactory(configuration(), "tests");
	}

	public net.thucydides.core.webdriver.Configuration getSystemConfiguration() {
		if (systemConfiguration == null) {
			systemConfiguration = Injectors.getInjector()
					.getInstance(net.thucydides.core.webdriver.Configuration.class);
		}
		return systemConfiguration;
	}

	public List<String> storyPaths() {

		JiraStoryPathsFinder storyFinder = new JiraStoryPathsFinder(Constants.JIRA_URL, Constants.JIRA_PROJECT,
				Constants.JIRA_USER, Constants.JIRA_PASSWORD);

		// set additional filtering parameters here if required
		// storyFinder.setIssueFieldFilterParam(JiraStoryPathsFinder.IssueFilterParam.TYPE,
		// "Task");

		List<String> paths = storyFinder.findPaths();
		return paths;
	}

}
